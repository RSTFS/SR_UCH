// 关卡工具页（侧栏「关卡」第 2 页）：重载关卡 / 重载模式 / 保分补分 / 快照后处理补丁。
// 本命名空间内 Level 会遮蔽游戏自带的 global::Level，跨类型引用须写 global::。
using System;
using System.Collections;
using System.Collections.Generic;
using System.Reflection;
using System.Text;
using BepInEx;
using BepInEx.Configuration;
using HarmonyLib;
using UnityEngine;
using UnityEngine.Networking;
using UnityEngine.SceneManagement;
namespace SR_UCH.Tweaks {
public partial class Level {
    private static ConfigEntry<ReloadMode> _reloadMode;


    public static void RenderTools() {
        SRApi.Ctl.SectionTitle(SRApi.Tid("e86dac38fe", "关卡工具", "Level tools"));
        GUILayout.BeginHorizontal();
        if (SRApi.Ctl.HotkeyButton("level.reload", SRApi.Tid("bc08efc166", "重载关卡", "Reload level"),
            SRApi.Tid("976f787e67", "房主把当前看到的方块都写进关卡快照, 然后真的重载一次当前关卡, 全员一起重新加载.\n重载完按快照把方块重建出来并广播, 玩家放的方块和能动的道具都不会丢.\n要不要顺手把分数补回来, 看下面那个重载模式.\n 只在派对和创意模式的对局里生效, 而且只有房主能用.", "Host writes the current blocks into the snapshot and really reloads the level scene, so everyone reloads.\nBlocks are rebuilt from the snapshot and nothing is lost.\nWhether the score is filled back depends on the Reload mode below.\n Party/Creative matches only, host only."),
            () => Level.ReloadLevel(), SRApi.Ctl.Sc(170), SRApi.Ctl.Sc(30))) {
            Level.ReloadLevel();
        }
        ConfigEntryBase rlm = SRApi.Ctl.FindEntry("Level", "Reload Mode");
        SRApi.Ctl.RestoreLabel(new GUIContent(SRApi.Tid("7601b32380", "重载模式", "Reload mode"),
            SRApi.Tid("083c994f01", "重载关卡模式：\n保留方块和分数（允许补分）= 重载后当前方块保留；房主按原类型分块给全员广播补分，下一回合结算时全员得分板显示与重载前一致的分数和类型。\n仅保留方块（跳过补分）= 重载后当前方块保留，分数重置。", "Reload level mode:\nKeep blocks & score (allow fill) = blocks kept; the host fills scores so everyone sees the same score/types next tally.\nKeep blocks only (skip fill) = blocks kept, score resets.")),
            rlm, SRApi.Ctl.Sc(140), SRApi.Ctl.Sc(52));
        if (rlm != null) SRApi.Ctl.RenderControl(rlm);
        GUILayout.FlexibleSpace();
        GUILayout.EndHorizontal();
        GUILayout.Space(SRApi.Ctl.Sc(4));
    }

        // 重载模式：保留方块与分数 / 仅保留方块（分数重置）。
        public enum ReloadMode {
            KeepScore,
            KeepBlocksOnly
        }

    public static void MarkPreserveScores() {
        _preserveScoresOnReload = true;
        _preserveMarkedAt = Time.unscaledTime;
    }

    [HarmonyPatch(typeof(GameControl), "handleEvent")]
    [HarmonyPrefix]
    static void OnPrepareReloadMessage(GameEvent.GameEvent e) {
        try {
            // 只重置补分保护、不置补分标志：否则外部工具发起的重载会再补一份导致翻倍。
            if (e is GameEvent.NetworkMessageReceivedEvent nm && nm.Message.msgType == NetMsgTypes.PrepareToReloadScene) {
                _refillPending = false;
                _refillAt = -1f;
                BackupHandicaps();
            }
        } catch (Exception __ex) { SRApi.Guard.Log("处理 PrepareToReloadScene", __ex); }
    }

    // 备份全员 handicap（从 LobbyPlayer 读服务器权威值）。
    private static void BackupHandicaps() {
        try {
            _handicapBackup = new Dictionary<int, int>();
            LobbyManager lm = LobbyManager.instance;
            if (lm == null || lm.PlayerTracker == null) return;
            for (int i = 0; i < lm.PlayerTracker.NumPlayers; i++) {
                try {
                    NetworkPlayerTracker.NetPlayerInfo info = lm.PlayerTracker.GetPlayerInfoByIndex(i);
                    LobbyPlayer lp = lm.PlayerTracker.GetLobbyPlayer(info.NetworkNumber);
                    if (lp == null) continue;
                    _handicapBackup[info.NetworkNumber] = lp.Networkhandicap;
                } catch (Exception __ex) { SRApi.Guard.Log("读取玩家 handicap", __ex); }
            }
            if (_handicapBackup.Count > 0) {
                SRApi.LogInfo("[折扣] 重载前备份 " + _handicapBackup.Count + " 名玩家 handicap");
            }
        } catch (Exception __ex) { SRApi.Guard.Log("备份 handicap", __ex); }
    }

    // 重载后房主写回 handicap（SyncVar，服务器赋值自动广播）。
    private static void RestoreHandicapsIfAny() {
        if (_handicapBackup == null || _handicapBackup.Count == 0) return;
        Dictionary<int, int> backup = _handicapBackup;
        _handicapBackup = null;
        try {
            if (!SRApi.HasServer) return; // 仅房主可写 SyncVar
            LobbyManager lm = LobbyManager.instance;
            if (lm == null || lm.PlayerTracker == null) return;
            foreach (KeyValuePair<int, int> kv in backup) {
                try {
                    LobbyPlayer lp = lm.PlayerTracker.GetLobbyPlayer(kv.Key);
                    if (lp != null) lp.Networkhandicap = kv.Value;
                } catch (Exception __ex) { SRApi.Guard.Log("恢复 LobbyPlayer handicap", __ex); }
                try {
                    GamePlayer gp = lm.PlayerTracker.GetGamePlayer(kv.Key);
                    if (gp != null) gp.NetworkHandicap = kv.Value;
                } catch (Exception __ex) { SRApi.Guard.Log("恢复 GamePlayer handicap", __ex); }
            }
            SRApi.LogInfo("[折扣] 重载后恢复 " + backup.Count + " 名玩家 handicap");
        } catch (Exception __ex) { SRApi.Guard.Log("恢复 handicap", __ex); }
    }

    // 补分重放后跳过清除；正常结算只缓存外部加分分块，原生未 tally 的不缓存以免多计分。
    [HarmonyPatch(typeof(ScoreKeeper), "ClearNewPointBlocks")]
    [HarmonyPrefix]
    static bool ClearNewPointBlocksPrefix(ScoreKeeper __instance) {
        try {
            // 自愈：补分标志未被消费会一直跳过清除，导致分块累积、下次重载备份翻倍；超时按普通结算处理。
            if (_refillPending && _refillAt >= 0f && Time.unscaledTime - _refillAt > PreserveStaleAfter) {
                SRApi.LogWarn("[保分] 补分标志超过 " + (int)PreserveStaleAfter + " 秒未被消费，强制按普通结算处理");
                _refillPending = false;
                _refillAt = -1f;
            }
            if (_refillPending) {
                // 跳过清除时同样要缓存（去重合并），否则同一批分块会被补回两次。
                try {
                    if (__instance != null && __instance.newPointBlocks != null) {
                        for (int i = 0; i < __instance.newPointBlocks.Count; i++) {
                            PointBlock pb = __instance.newPointBlocks[i];
                            if (pb == null) continue;
                            int k = Key(pb);
                            bool dup = false;
                            for (int j = 0; j < _clearedExternBlocks.Count; j++) {
                                KeyValuePair<int, PointBlock.pointBlockType> it = _clearedExternBlocks[j];
                                if (Key(it.Key, it.Value) == k) { dup = true; break; }
                            }
                            if (!dup) _clearedExternBlocks.Add(new KeyValuePair<int, PointBlock.pointBlockType>(pb.playerNumber, pb.type));
                        }
                    }
                } catch (Exception __cex) { SRApi.Guard.Log("缓存补分分块", __cex); }
                return false;
            }
            if (__instance == null || __instance.newPointBlocks == null) return true;
            for (int i = 0; i < __instance.newPointBlocks.Count; i++) {
                PointBlock pb = __instance.newPointBlocks[i];
                if (pb == null) continue;
                if (!pb.AlwaysAward && _externAwardedKeys.Contains(Key(pb))) {
                    // 外部加分的非 AlwaysAward 分块：缓存待补回，按 (玩家, 类型) 去重，不可用对象引用。
                    int __k = Key(pb);
                    bool __dup = false;
                    for (int __j = 0; __j < _clearedExternBlocks.Count; __j++) {
                        KeyValuePair<int, PointBlock.pointBlockType> __it = _clearedExternBlocks[__j];
                        if (Key(__it.Key, __it.Value) == __k) { __dup = true; break; }
                    }
                    if (!__dup) _clearedExternBlocks.Add(new KeyValuePair<int, PointBlock.pointBlockType>(pb.playerNumber, pb.type));
                }
            }
            if (_clearedExternBlocks.Count > 500) {
                _clearedExternBlocks.RemoveRange(0, _clearedExternBlocks.Count - 500);
            }
        } catch (Exception __ex) { SRApi.Guard.Log("缓存被清除的外部加分分块", __ex); }
        return true;
    }

    // 去重键 = playerNumber*1024 + type，两段互不重叠。
    private static int Key(PointBlock pb) { return (pb.playerNumber * 1024) + (int)pb.type; }
    private static int Key(int playerNumber, PointBlock.pointBlockType type) { return (playerNumber * 1024) + (int)type; }

    // 标记外部加分分块：AlwaysAward=true 的加分来自外部模块或补分重放。
    [HarmonyPatch(typeof(ScoreKeeper), "handleEvent")]
    [HarmonyPrefix]
    static void OnPointAwardedMessage(ScoreKeeper __instance, global::GameEvent.GameEvent e) {
        try {
            if (e == null || e.GetType() != typeof(GameEvent.NetworkMessageReceivedEvent)) return;
            GameEvent.NetworkMessageReceivedEvent nm = e as GameEvent.NetworkMessageReceivedEvent;
            if (nm == null || nm.Message == null || nm.Message.msgType != NetMsgTypes.PointAwarded) return;
            // reader 已被 GameState.distributeMessage 消费，ReadMessage 会越界，只能用已反序列化字段。
            MsgPointAwarded msg = nm.ReadMessage as MsgPointAwarded;
            if (msg != null && msg.AlwaysAward) {
                _externAwardedKeys.Add(Key(msg.PlayerNumber, msg.PointType));
            }
        } catch (Exception __ex) { SRApi.Guard.Log("标记外部加分分块", __ex); }
    }

    // tally 后清标志与外部加分标记，恢复正常清除。
    [HarmonyPatch(typeof(ScoreKeeper), "TallyPointBlockAllPlayers")]
    [HarmonyPostfix]
    static void TallyPostfix() {
        try {
                _refillPending = false;
                _externAwardedKeys.Clear();
                _clearedExternBlocks.Clear();
        } catch (Exception __ex) { SRApi.Guard.Log("结算收尾", __ex); }
    }

    [HarmonyPatch(typeof(ScoreKeeper), "Setup")]
    [HarmonyPrefix]
    static void ScoreSetupPrefix(ScoreKeeper __instance) {
        if (!_preserveScoresOnReload) return;
        try {
            // 备份 historyPointBlocks（已 tally）+ newPointBlocks（本回合未结算）。
            List<PointBlock> blocks = new List<PointBlock>();
            try {
                FieldInfo hf = SRApi.Ref.Field(typeof(ScoreKeeper), "historyPointBlocks", "重载保分（历史分块）");
                List<PointBlock> hist = hf != null ? hf.GetValue(__instance) as List<PointBlock> : null;
                if (hist != null) blocks.AddRange(hist);
            } catch (Exception ex) {
                SRApi.LogWarn("[保分] 备份 historyPointBlocks 失败: " + ex.Message);
            }
            try {
                List<PointBlock> npb = __instance.newPointBlocks; // public 字段
                if (npb != null) blocks.AddRange(npb);
            } catch (Exception ex) {
                SRApi.LogWarn("[保分] 备份 newPointBlocks 失败: " + ex.Message);
            }
            if (_clearedExternBlocks != null && _clearedExternBlocks.Count > 0) {
                // 用值快照重建被清除的外部加分分块后合并进备份。
                for (int __bi = 0; __bi < _clearedExternBlocks.Count; __bi++) {
                    KeyValuePair<int, PointBlock.pointBlockType> it = _clearedExternBlocks[__bi];
                    blocks.Add(new PointBlock(it.Value, it.Key));
                }
                SRApi.LogInfo("[保分] 合并被清除的外部加分分块 " + _clearedExternBlocks.Count + " 条");
                _clearedExternBlocks.Clear();
            }
            if (blocks.Count == 0) {
                SRApi.LogWarn("[保分] 重载时无可备份的分块（history+new+外部加分均为空）");
                return;
            }
            _scoreBackupBlocks = new Dictionary<int, List<PointBlock.pointBlockType>>();
            foreach (PointBlock pb in blocks) {
                if (pb == null) continue;
                List<PointBlock.pointBlockType> list;
                if (!_scoreBackupBlocks.TryGetValue(pb.playerNumber, out list)) {
                    list = new List<PointBlock.pointBlockType>();
                    _scoreBackupBlocks[pb.playerNumber] = list;
                }
                list.Add(pb.type);   // 只存类型快照
            }
            SRApi.LogInfo("[保分] 重载备份分块 " + blocks.Count + " 条，涉及 " + _scoreBackupBlocks.Count + " 名玩家");
        } catch (Exception ex) {
            SRApi.LogWarn("[保分] 备份分块失败: " + ex.Message);
        }
    }

    [HarmonyPatch(typeof(ScoreKeeper), "Setup")]
    [HarmonyPostfix]
    static void ScoreSetupPostfix(ScoreKeeper __instance) {
        try {
                // 下次结算跳过清除；超时未消费的保分标志按普通开局处理，避免补回陈旧分块。
                bool fresh = _preserveScoresOnReload && _preserveMarkedAt >= 0f
                    && (Time.unscaledTime - _preserveMarkedAt) <= PreserveStaleAfter;
                if (_preserveScoresOnReload && !fresh) {
                    SRApi.LogWarn("[保分] 保分标志已过期（" + ((int)(Time.unscaledTime - _preserveMarkedAt))
                        + " 秒没被结算），本次按普通开局处理");
                }
                _refillPending = fresh;
                _refillAt = fresh ? Time.unscaledTime : -1f;
                // 只清标志，分块由 FillScoresIfPending 的补分广播恢复。
                _preserveScoresOnReload = false;
                _preserveMarkedAt = -1f;
        } catch (Exception __ex) { SRApi.Guard.Log("保分标志复位", __ex); }
    }

    // 重载后广播补分：房主按备份类型逐个发 PointAwarded（AlwaysAward=true），下回合 tally 进 playerTotal。
    // 防网络风暴：上限 FillTotalCap 条，每帧 FillPerFrame 条。
    private const int FillPerFrame = 30;
    private const int FillTotalCap = 300;
    private static void FillScoresIfPending() {
        if (_scoreBackupBlocks == null || _scoreBackupBlocks.Count == 0) return;
        // 只以服务器权威把关，不看 UI 总开关：否则关掉总开关分数补不回来。
        if (!SRApi.HasServer) return;
        Dictionary<int, List<PointBlock.pointBlockType>> backup = _scoreBackupBlocks;
        _scoreBackupBlocks = null;
        try {
            // 必须走 NetworkServer.SendToAll（服务器→全员）；client.Send 方向相反，房客收不到。
            LobbyManager lm = LobbyManager.instance;
            if (lm == null || lm.client == null || !lm.client.isConnected) return;
            List<KeyValuePair<int, PointBlock.pointBlockType>> queue = new List<KeyValuePair<int, PointBlock.pointBlockType>>();
            // 备份含跨回合累积的 historyPointBlocks，长局易超上限；截断时必须告警丢了多少。
            int total = 0;
            foreach (KeyValuePair<int, List<PointBlock.pointBlockType>> kv in backup) {
                if (kv.Value != null) total += kv.Value.Count;
            }
            bool capped = false;
            foreach (KeyValuePair<int, List<PointBlock.pointBlockType>> kv in backup) {
                List<PointBlock.pointBlockType> list = kv.Value;
                if (list == null || list.Count == 0) continue;
                for (int i = 0; i < list.Count; i++) {
                    if (queue.Count >= FillTotalCap) { capped = true; break; } // 全局上限
                    queue.Add(new KeyValuePair<int, PointBlock.pointBlockType>(kv.Key, list[i]));
                }
                if (capped) break; // 已达上限
            }
            if (capped) {
                SRApi.LogWarn("[补分] 备份分块 " + total + " 条超过上限 " + FillTotalCap
                    + "，仅补回前 " + queue.Count + " 条（" + (total - queue.Count) + " 条被丢弃，重载后分数会偏少）");
            }
            if (queue.Count == 0) return;
            // 宿主必须不随场景销毁：重载切场景会掐断协程，备份已置空而标志仍真会致分数翻倍。
            FillHost host = FillHost.Ensure();
            if (host != null) host.StartCoroutine(FillScoresCoroutine(queue));
            else lm.StartCoroutine(FillScoresCoroutine(queue));
            SRApi.LogInfo("[补分] 队列 " + queue.Count + " 条，分帧发送（每帧 " + FillPerFrame + " 条）");
        } catch (Exception ex) {
            SRApi.LogWarn("[补分] 初始化失败: " + ex.Message);
        }
    }

    private static System.Collections.IEnumerator FillScoresCoroutine(List<KeyValuePair<int, PointBlock.pointBlockType>> queue) {
        int sent = 0;
        try {
        while (sent < queue.Count) {
            int batch = Mathf.Min(FillPerFrame, queue.Count - sent);
            for (int i = 0; i < batch; i++) {
                try {
                    if (!NetworkServer.active) { SRApi.LogWarn("[补分] 已非服务器权威，中止补分"); yield break; }
                    NetworkServer.SendToAll(NetMsgTypes.PointAwarded, new MsgPointAwarded {
                        PlayerNumber = queue[sent].Key, PointType = queue[sent].Value, AlwaysAward = true
                    });
                } catch (Exception ex) {
                    // 中途失败必须中止：继续发会让计分板一半新一半旧；日志记已发/共多少便于核对。
                    SRApi.LogWarn("[补分] 发送失败，已中止：已发 " + sent + "/" + queue.Count + " 条，" + ex.Message);
                    yield break;
                }
                sent++;
            }
            yield return null; // 每帧一批
        }
        } finally {
            // 未发完（场景被切走 / 异常）须把剩余写回备份，绝不留下“已消费但没补”的状态。
            if (sent < queue.Count) {
                try {
                    Dictionary<int, List<PointBlock.pointBlockType>> rest = new Dictionary<int, List<PointBlock.pointBlockType>>();
                    for (int i = sent; i < queue.Count; i++) {
                        List<PointBlock.pointBlockType> list;
                        if (!rest.TryGetValue(queue[i].Key, out list)) { list = new List<PointBlock.pointBlockType>(); rest[queue[i].Key] = list; }
                        list.Add(queue[i].Value);
                    }
                    _scoreBackupBlocks = rest;
                    SRApi.LogWarn("[补分] 发送中断，已把剩余 " + (queue.Count - sent) + " 条写回备份，下回合续补");
                } catch (Exception __rq) { SRApi.Guard.Log("补分/回写剩余", __rq); }
            }
        }
    }

    // 持久宿主：DontDestroyOnLoad 的空对象，承载不被场景切换掐断的协程。
    private sealed class FillHost : UnityEngine.MonoBehaviour {
        private static FillHost _inst;
        internal static FillHost Ensure() {
            try {
                if (_inst != null) return _inst;
                GameObject go = new GameObject("SR_UCH.CoroutineHost");
                UnityEngine.Object.DontDestroyOnLoad(go);
                _inst = go.AddComponent<FillHost>();
                return _inst;
            } catch (Exception __hx) { SRApi.Guard.Log("补分/创建持久宿主", __hx); return null; }
        }
    }
}
}