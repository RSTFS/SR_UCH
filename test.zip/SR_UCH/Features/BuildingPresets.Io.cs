// 布局预设 · 存储与导入导出：保存 / 导入 / 导出 / 删除 / 重命名、快照获取、索引读写、本地关卡扫描。
using System;
using System.Collections;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Text;
using System.Xml;
using BepInEx;
using BepInEx.Configuration;
using UnityEngine;
using UnityEngine.Networking;
using UnityEngine.SceneManagement;

namespace SR_UCH.Tweaks {

    public partial class BuildingPresets {






        private static void ImportFromClipboard() {
            try {
                if (!ActionAllowed()) return;
                string xml = null;
                try { xml = GUIUtility.systemCopyBuffer; } catch (Exception __ex) { SRApi.Guard.Log("布局预设/读取剪贴板", __ex); }
                if (string.IsNullOrEmpty(xml) || xml.Trim().Length == 0) {
                    SRApi.NotifyT("剪贴板是空的", "The clipboard is empty");
                    return;
                }
                ImportXmlText(xml, null, SRApi.Tid("9df9f16f4f", "剪贴板", "clipboard"));
            } catch (Exception __ex) {
                SRApi.Guard.Log("布局预设/导入(剪贴板)", __ex);
            }
        }

        private static void ImportFromPath() {
            try {
                if (!ActionAllowed()) return;
                string input = (_importPath ?? "").Trim();
                if (input.Length >= 2 && input[0] == '"' && input[input.Length - 1] == '"') input = input.Substring(1, input.Length - 2).Trim();
                if (input.Length == 0) {
                    SRApi.NotifyT("请先填写 XML 文件路径", "Enter the XML file path first");
                    return;
                }
                string path = ResolveImportPath(input);
                if (!string.IsNullOrEmpty(path)) {
                    string ext = Path.GetExtension(path) ?? "";
                    if (!ext.Equals(".xml", StringComparison.OrdinalIgnoreCase)
                        && !ext.Equals(".snapshot", StringComparison.OrdinalIgnoreCase)) {
                        SRApi.NotifyT("只能导入 .xml 或 .snapshot 文件", "Only .xml or .snapshot files can be imported");
                        return;
                    }
                }
                if (string.IsNullOrEmpty(path)) {
                    SRApi.NotifyT("找不到 XML 文件：{0}", "XML file not found: {0}", input);
                    return;
                }
                long length = 0;
                try { length = new FileInfo(path).Length; }
                catch (Exception __ex) { SRApi.Guard.Log("布局预设/读取文件大小", __ex); }
                if (length > MaxImportChars) {
                    SRApi.NotifyT("XML 文件过大，已拒绝导入", "The XML file is too large; import rejected");
                    return;
                }
                string xml = null;
                try { xml = File.ReadAllText(path, Encoding.UTF8); }
                catch (Exception __ex) { SRApi.Guard.Log("布局预设/读取路径文件", __ex); }
                if (string.IsNullOrEmpty(xml)) {
                    SRApi.NotifyT("读取 XML 文件失败", "Failed to read the XML file");
                    return;
                }
                string defaultName = null;
                try { defaultName = Path.GetFileNameWithoutExtension(path); } catch { /* 静默：非关键路径，失败可直接忽略 */ }
                ImportXmlText(xml, defaultName, SRApi.Tid("36686a9054", "文件", "file"));
            } catch (Exception __ex) {
                SRApi.Guard.Log("布局预设/导入(路径)", __ex);
            }
        }

        private static void ImportXmlText(string xml, string defaultBaseName, string sourceLabel) {
            try {
                if (string.IsNullOrEmpty(xml) || xml.Trim().Length == 0) {
                    SRApi.NotifyT("导入内容为空", "The import content is empty");
                    return;
                }
                xml = xml.Trim();
                if (xml.Length > MaxImportChars) {
                    SRApi.NotifyT("导入内容过大，已拒绝（上限 {0} 千字符）",
                        "Import content is too large; rejected (limit {0}k characters)", MaxImportChars / 1000);
                    return;
                }
                XmlDocument doc = null;
                try {
                    doc = ParseXmlSafe(xml);
                } catch (Exception __ex) {
                    SRApi.Guard.Log("布局预设/解析导入 XML", __ex);
                }
                if (doc == null || doc.DocumentElement == null || doc.DocumentElement.Name != "scene") {
                    SRApi.NotifyT("导入内容不是关卡布局 XML（根节点必须是 scene）", "The import content is not level layout XML (root node must be scene)");
                    return;
                }
                int blocks = CountBlocks(doc);
                if (blocks <= 0) {
                    SRApi.NotifyT("导入 XML 里没有方块", "The imported XML contains no blocks");
                    return;
                }
                if (blocks > MaxImportBlocks) {
                    SRApi.NotifyT("方块数超过导入上限 {0}", "Block count exceeds the import limit {0}", MaxImportBlocks
                        + SRApi.Tid("7f58569572", "，已拒绝导入", "; import rejected"));
                    return;
                }
                string level = LevelFromDoc(doc);
                if (string.IsNullOrEmpty(level)) {
                    SRApi.NotifyT("XML 缺少 levelSceneName，无法确定属于哪个关卡", "The XML has no levelSceneName, so its level cannot be determined");
                    return;
                }
                StripDestroyed(doc);
                string name = (_newName ?? "").Trim();
                if (name.Length == 0 && !string.IsNullOrEmpty(defaultBaseName)) name = defaultBaseName.Trim();
                if (name.Length == 0) name = SRApi.Tid("5e33269504", "导入 ", "Imported ") + DateTime.Now.ToString("yyyyMMdd-HHmmss-fff", CultureInfo.InvariantCulture);
                if (name.Length > 40) name = name.Substring(0, 40);
                string mode = "IMPORTED";
                try {
                    GameSettings st = GameSettings.GetInstance();
                    if (st != null) mode = st.GameMode.ToString();
                } catch (Exception __ex) { SRApi.Guard.Log("布局预设/读取模式(导入)", __ex); }
                SRApi.LogInfo("[布局预设] 从" + sourceLabel + "导入：" + name + "（" + blocks + " 块，关卡 " + level + "）");
                SaveXml(doc.OuterXml, name, mode, blocks, level, LevelDisplayNameForScene(level), LevelCodeFromDoc(doc));
            } catch (Exception __ex) {
                SRApi.Guard.Log("布局预设/导入XML", __ex);
            }
        }

        // 路径解析：绝对路径直接用；相对路径依次尝试 当前目录 / BepInEx 根目录 / 配置目录 / 预设目录（前缀比较须带尾部分隔符）。
        private static bool IsUnderRoot(string full, string root) {
            try {
                if (string.IsNullOrEmpty(full) || string.IsNullOrEmpty(root)) return false;
                string r = root.TrimEnd('/', '\\');
                if (string.Equals(full, r, StringComparison.OrdinalIgnoreCase)) return true;
                if (full.StartsWith(r + Path.DirectorySeparatorChar, StringComparison.OrdinalIgnoreCase)) return true;
                if (full.StartsWith(r + Path.AltDirectorySeparatorChar, StringComparison.OrdinalIgnoreCase)) return true;
                return false;
            } catch { return false; }
        }

        private static string ResolveImportPath(string input) {
            try {
                if (string.IsNullOrEmpty(input)) return null;
                // 绝对路径通道必须做根校验，否则任意存在的路径都能被导入（任意文件读）。
                try {
                    if (File.Exists(input)) {
                        string full0 = Path.GetFullPath(input);
                        if (IsUnderRoot(full0, Path.GetFullPath(PresetsRoot()))) return full0;
                        SRApi.LogWarn("[布局预设] 拒绝导入预设根目录之外的文件: " + full0);
                        return null;
                    }
                } catch { /* 静默：非关键路径，失败可直接忽略 */ }
                // 相对路径通道同样必须做根校验：`..\..\x.xml` 能跳出预设根。
                string root0 = Path.GetFullPath(PresetsRoot());
                string p = null;
                try {
                    p = Path.Combine(Paths.BepInExRootPath, input);
                    string f1 = File.Exists(p) ? Path.GetFullPath(p) : null;
                    if (f1 != null) {
                        if (IsUnderRoot(f1, root0)) return f1;
                        SRApi.LogWarn("[布局预设] 拒绝导入预设根目录之外的文件: " + f1);
                    }
                } catch { /* 静默：非关键路径，失败可直接忽略 */ }
                try {
                    p = Path.Combine(Paths.ConfigPath, input);
                    string f2 = File.Exists(p) ? Path.GetFullPath(p) : null;
                    if (f2 != null) {
                        if (IsUnderRoot(f2, root0)) return f2;
                        SRApi.LogWarn("[布局预设] 拒绝导入预设根目录之外的文件: " + f2);
                    }
                } catch { /* 静默：非关键路径，失败可直接忽略 */ }
                try {
                // 先净化文件名，再取全路径并确认仍在预设根目录内（防目录穿越）。
                string safe = SafeFileName(input);
                string root2 = Path.GetFullPath(PresetsRoot());
                string full = Path.GetFullPath(Path.Combine(root2, safe));
                if (IsUnderRoot(full, root2) && File.Exists(full)) return full;
            } catch { /* 静默：非关键路径，失败可直接忽略 */ }
            } catch (Exception __ex) {
                SRApi.Guard.Log("布局预设/解析导入路径", __ex);
            }
            return null;
        }





        // 启动/刷新时清理残留 .tmp（原子写中途退出留下），只清 24 小时前的。
        private static void SweepStaleTemp() {
            try {
                string root = PresetsRoot();
                if (!Directory.Exists(root)) return;
                foreach (string f in Directory.GetFiles(root, "*.tmp")) {
                    try { if ((DateTime.UtcNow - File.GetLastWriteTimeUtc(f)).TotalHours >= 24) File.Delete(f); }
                    catch (Exception __sd) { SRApi.Guard.Log("布局预设/清理残留临时文件", __sd); }
                }
            } catch (Exception __sw) { SRApi.Guard.Log("布局预设/扫描残留临时文件", __sw); }
        }

        private static void DeletePreset(PresetInfo p) {
            try {
                if (p == null) return;
                if (p.IsLocal) return; // 游戏本地存档不允许从这里删除
                if (!ActionAllowed()) return;
                // 先删文件再同步内存列表与索引；只删文件的话下次扫描会从 index.json 复活它。
                bool existed = false;
                try { existed = File.Exists(p.FilePath); } catch (Exception __fe) { SRApi.Guard.Log("布局预设/删除前检查", __fe); }
                if (existed) {
                    try { File.Delete(p.FilePath); }
                    catch (Exception __df) {
                        SRApi.Guard.Log("布局预设/删除文件", __df);
                        SRApi.NotifyT("删除失败：文件被占用？", "Delete failed: file in use?");
                        return;   // 文件没删掉就不要动索引
                    }
                    // 顺手清理同名残留（原子写临时文件 / 覆盖前备份）。
                    try { if (File.Exists(p.FilePath + ".tmp")) File.Delete(p.FilePath + ".tmp"); } catch (Exception __ct) { SRApi.Guard.Log("布局预设/清理临时文件", __ct); }
                    try { if (File.Exists(p.FilePath + ".bak")) File.Delete(p.FilePath + ".bak"); } catch (Exception __cb) { SRApi.Guard.Log("布局预设/清理备份", __cb); }
                }
                for (int i = _presets.Count - 1; i >= 0; i--) {
                    PresetInfo it = _presets[i];
                    if (it == null) { _presets.RemoveAt(i); continue; }
                    if (ReferenceEquals(it, p) || it.Key == p.Key) _presets.RemoveAt(i);
                }
                _visibleCache = null;
                SaveIndex();
                _status = SRApi.Tid("da8f170ccf", "已删除预设：", "Deleted preset: ") + (p.Name ?? "");
                SRApi.Notify(_status);
                SRApi.LogInfo("[布局预设] " + _status);
            } catch (Exception __ex) {
                SRApi.Guard.Log("布局预设/删除", __ex);
            }
        }

        private static void CommitRename(PresetInfo p) {
            try {
                if (p == null) return;
                if (p.IsLocal) return; // 本地关卡名来自游戏存档，不在这里改名
                if (!ActionAllowed()) return;
                string name = (_renameText ?? "").Trim();
                if (name.Length == 0) {
                    SRApi.NotifyT("名称不能为空", "The name cannot be empty");
                    return;
                }
                if (name.Length > 40) name = name.Substring(0, 40);
                string oldName = p.Name;
                p.Name = name;
                // 回写 XML 的 srName：XML 是权威数据源，只改索引会让重扫时名字退回旧的。
                bool written = false;
                try {
                    string xmlPath = p.FilePath;
                    if (!string.IsNullOrEmpty(xmlPath) && File.Exists(xmlPath)) {
                        string text = File.ReadAllText(xmlPath);
                        XmlDocument doc = ParseXmlSafe(text);
                        if (doc != null && doc.DocumentElement != null) {
                            doc.DocumentElement.SetAttribute("srName", name);
                            WriteFileAtomic(xmlPath, doc.OuterXml);
                            // XML 才是权威源；写不进去时不能只改索引，否则下次扫描会回填旧名。
                            try {
                                XmlDocument verify = ParseXmlSafe(File.ReadAllText(xmlPath));
                                written = verify != null && verify.DocumentElement != null
                                    && verify.DocumentElement.GetAttribute("srName") == name;
                            } catch (Exception __vf) { SRApi.Guard.Log("布局预设/重命名校验", __vf); }
                        }
                    }
                } catch (Exception __wx) { SRApi.Guard.Log("布局预设/重命名回写XML", __wx); }
                if (!written) {
                    p.Name = oldName;
                    _renameKey = null;
                    _renameText = null;
                    SRApi.NotifyT("重命名失败：预设文件写不进去（只读或被占用）", "Rename failed: the preset file could not be written");
                    return;
                }
                _renameKey = null;
                _renameText = null;
                SaveIndex();
                _status = SRApi.Tid("4eeab35a10", "已重命名预设：", "Renamed preset: ") + name;
                SRApi.LogInfo("[布局预设] " + _status);
            } catch (Exception __ex) {
                SRApi.Guard.Log("布局预设/重命名", __ex);
            }
        }





        // 取本机当前看到的布局快照（保存是本地行为，不做房主门控）。
        private static bool TryGetCurrentSnapshot(out XmlDocument doc, out string mode) {
            doc = null;
            mode = "UNKNOWN";
            if (!SRApi.GateMaster) {
                SRApi.Notify(SRApi.MsgMasterOff);
                return false;
            }
            LobbyManager lm = LobbyManager.instance;
            if (lm == null) {
                SRApi.NotifyT("当前不在对局中", "Not in a match");
                return false;
            }
            GameControl gc = lm.CurrentGameController as GameControl;
            if (gc == null) {
                SRApi.NotifyT("未进入有效对局", "No active match");
                return false;
            }
            QuickSaver qs = gc.GetComponent<QuickSaver>();
            if (qs == null) {
                SRApi.NotifyT("当前对局不支持保存布局", "Saving layouts is not supported in this match");
                return false;
            }
            doc = qs.GetCurrentXmlSnapshot(false);
            if (doc == null || doc.DocumentElement == null) {
                SRApi.NotifyT("布局快照生成失败", "Failed to generate the layout snapshot");
                doc = null;
                return false;
            }
            try {
                GameSettings st = GameSettings.GetInstance();
                if (st != null) mode = st.GameMode.ToString();
            } catch (Exception __ex) {
                SRApi.Guard.Log("布局预设/读取当前模式", __ex);
            }
            return true;
        }


        private static string PresetsRoot() {
            if (!string.IsNullOrEmpty(_rootDir)) return _rootDir;
            try {
                _rootDir = Path.Combine(Paths.ConfigPath, "SR_UCH", "presets");
            } catch (Exception __ex) {
                SRApi.Guard.Log("布局预设/定位存储目录", __ex);
                // 极端情况下 BepInEx.Paths 不可用：退回临时目录，至少不让功能崩掉。
                _rootDir = Path.Combine(Path.GetTempPath(), "SR_UCH_presets");
            }
            return _rootDir;
        }

        private static void EnsureLoaded() {
            if (_loaded) return;
            SweepStaleTemp();
            LoadFromDisk(false);
        }

        // 扫描磁盘重建列表：index.json 只提供展示元数据，XML 才是权威数据；索引损坏时按 XML 重读并回写自愈。
        private static void LoadFromDisk(bool revalidate) {
            _loaded = true;
            _presets.Clear();
            bool upgraded = false; // 旧索引缺字段 / 新文件 / 重校验结果变化：扫完回写一次
            try {
                string root = PresetsRoot();
                if (!Directory.Exists(root)) {
                    LoadLocalSnapshots();
                    SortPresets();
                    return;
                }
                Dictionary<string, PresetInfo> byKey = new Dictionary<string, PresetInfo>(StringComparer.OrdinalIgnoreCase);
                Dictionary<string, bool> completeIdx = new Dictionary<string, bool>(StringComparer.OrdinalIgnoreCase);
                string index = Path.Combine(root, IndexFileName);
                if (File.Exists(index)) {
                    try {
                        string[] lines = File.ReadAllLines(index, Encoding.UTF8);
                        for (int i = 0; i < lines.Length; i++) {
                            string line = lines[i];
                            if (line == null || line.IndexOf("\"file\"", StringComparison.Ordinal) < 0) continue;
                            string file = JsonStr(line, "file");
                            string mode = JsonStr(line, "mode");
                            if (string.IsNullOrEmpty(file) || string.IsNullOrEmpty(mode)) continue;
                            PresetInfo pi = new PresetInfo();
                            pi.File = file;
                            pi.Mode = mode;
                            pi.Name = JsonStr(line, "name");
                            if (string.IsNullOrEmpty(pi.Name)) pi.Name = Path.GetFileNameWithoutExtension(file);
                            pi.Blocks = JsonInt(line, "blocks");
                            pi.TimeUtc = ParseTime(JsonStr(line, "time"));
                            pi.Level = JsonStr(line, "level");
                            if (pi.Level == null) pi.Level = "";
                            pi.LevelName = JsonStr(line, "levelName");
                            if (pi.LevelName == null) pi.LevelName = "";
                            pi.LevelCode = JsonStr(line, "levelCode");
                            if (pi.LevelCode == null) pi.LevelCode = "";
                            pi.Ok = JsonBool(line, "ok");
                            pi.ModsMode = JsonStr(line, "modsMode") ?? "";
                            pi.ApplyRules = JsonBool(line, "applyRules");
                            pi.ApplyPoints = JsonBool(line, "applyPoints");
                            pi.ApplyBlocks = JsonBool(line, "applyBlocks");
                            ParseModsVals(pi, JsonStr(line, "modsVals"));
                            // 老索引没有 level / levelName / levelCode / ok，扫描时自愈。
                            bool complete = line.IndexOf("\"level\":", StringComparison.Ordinal) >= 0
                                && line.IndexOf("\"levelName\":", StringComparison.Ordinal) >= 0
                                && line.IndexOf("\"levelCode\":", StringComparison.Ordinal) >= 0
                                && line.IndexOf("\"ok\":", StringComparison.Ordinal) >= 0;
                            completeIdx[mode + "/" + file] = complete;
                            if (!complete) upgraded = true;
                            byKey[mode + "/" + file] = pi;
                        }
                    } catch (Exception __ex) {
                            // 索引坏了就当它不存在：改名为 .bad 留证，继续用 XML 扫描重建。
                            try {
                                string bad = index + ".bad-" + DateTime.Now.ToString("yyyyMMdd-HHmmss", CultureInfo.InvariantCulture);
                                File.Move(index, bad);
                                SRApi.LogWarn("[布局预设] index.json 解析失败，已隔离为 " + Path.GetFileName(bad) + " 并从 XML 重建索引");
                            } catch (Exception __mv) { SRApi.Guard.Log("布局预设/隔离坏索引", __mv); }
                            upgraded = true;
                        SRApi.Guard.Log("布局预设/读索引", __ex);
                    }
                }
                string[] dirs = Directory.GetDirectories(root);
                for (int i = 0; i < dirs.Length; i++) {
                    string dir = dirs[i];
                    string mode = Path.GetFileName(dir);
                    // rulesets 是规则/积分/模块概率的侧车目录，不是预设。
                    if (string.Equals(mode, "rulesets", StringComparison.OrdinalIgnoreCase)) continue;
                    if (string.Equals(mode, "exports", StringComparison.OrdinalIgnoreCase)) continue;
                    string[] files = Directory.GetFiles(dir, "*.xml");
                    for (int j = 0; j < files.Length; j++) {
                        string fp = files[j];
                        string file = Path.GetFileName(fp);
                        if (file.EndsWith(".ruleset.xml", StringComparison.OrdinalIgnoreCase)) continue;   // 旧版侧车
                        string key = mode + "/" + file;
                        PresetInfo pi;
                        bool complete = false;
                        if (!byKey.TryGetValue(key, out pi)) {
                            pi = new PresetInfo();
                            pi.Mode = mode;
                            pi.File = file;
                            pi.Name = Path.GetFileNameWithoutExtension(file);
                            upgraded = true; // 索引里没有这个文件：扫完回写登记
                        } else {
                            complete = completeIdx.ContainsKey(key) && completeIdx[key];
                        }
                        pi.Mode = mode;
                        pi.File = file;
                        pi.FilePath = fp;
                        // 索引缺元数据（老索引 / 无索引 / 强制重校验）：流式读一次 XML 根节点与方块数。
                        if (revalidate || !complete || string.IsNullOrEmpty(pi.Level) || !pi.Ok || pi.Blocks < 0) {
                            bool oldOk = pi.Ok;
                            string oldLevel = pi.Level ?? "";
                            int oldBlocks = pi.Blocks;
                            string lv;
                            int blocks;
                            string metaName;
                            string metaCode;
                            string metaPreset = "";
                            bool xmlOk = TryReadPresetMeta(fp, out lv, out blocks, out metaName, out metaCode, out metaPreset);
                            pi.Level = lv ?? "";
                            if (!string.IsNullOrEmpty(metaPreset) && (string.IsNullOrEmpty(pi.Name) || pi.Name == Path.GetFileNameWithoutExtension(pi.File)))
                                pi.Name = metaPreset;   // 索引丢失时优先用 XML 里保存的显示名
                            if (string.IsNullOrEmpty(pi.LevelName) && !string.IsNullOrEmpty(metaName)) {
                                pi.LevelName = metaName;
                                upgraded = true;
                            }
                            if (string.IsNullOrEmpty(pi.LevelCode) && !string.IsNullOrEmpty(metaCode)) {
                                pi.LevelCode = metaCode;
                                upgraded = true;
                            }
                            pi.Blocks = xmlOk ? blocks : Mathf.Max(0, pi.Blocks);
                            pi.Ok = xmlOk && blocks > 0;
                            if (!complete) upgraded = true;
                            if (revalidate && (oldOk != pi.Ok || !string.Equals(oldLevel, pi.Level, StringComparison.Ordinal) || oldBlocks != pi.Blocks)) upgraded = true;
                        }
                        if (pi.TimeUtc == DateTime.MinValue) {
                            try { pi.TimeUtc = File.GetLastWriteTimeUtc(fp); } catch (Exception __ex) { SRApi.Guard.Log("布局预设/读文件时间", __ex); }
                        }
                        byKey[key] = pi;
                    }
                }
                foreach (KeyValuePair<string, PresetInfo> kv in byKey) {
                    PresetInfo pi = kv.Value;
                    if (string.IsNullOrEmpty(pi.FilePath)) continue; // 索引里有、磁盘上已删的条目直接丢弃
                    try { if (!File.Exists(pi.FilePath)) continue; } catch { continue; }
                    _presets.Add(pi);
                }
                LoadLocalSnapshots(); // 游戏本地保存的自定义关卡（只读，不写 index.json）
                SortPresets();
                if (upgraded) SaveIndex(); // 自愈结果立刻落盘
            } catch (Exception __ex) {
                SRApi.Guard.Log("布局预设/扫描目录", __ex);
            }
        }


        // 游戏快照目录：优先用 QuickSaver.LocalSavesFolder，取不到时退回 persistentDataPath。只读。
        private static string LocalSnapshotsFolder() {
            try {
                string f = QuickSaver.LocalSavesFolder;
                if (!string.IsNullOrEmpty(f)) return f;
            } catch (Exception __ex) { SRApi.Guard.Log("布局预设/本地快照目录(游戏)", __ex); }
            try { return Path.Combine(Application.persistentDataPath, "snapshots"); } catch { return null; }
        }

        // 本地快照是 SevenZipHelper 压缩的 UTF8 XML：校验压缩/解压大小、字符数、方块数后解析。
        private static string ReadLocalSnapshotXml(string path, out XmlDocument doc, out int blocks) {
            doc = null;
            blocks = 0;
            try {
                if (string.IsNullOrEmpty(path) || !File.Exists(path)) return null;
                FileInfo fi = new FileInfo(path);
                if (fi.Length <= 0 || fi.Length > MaxSnapshotBytes) {
                    SRApi.LogWarn("[布局预设] 本地关卡文件大小异常，已跳过: " + path + " (" + fi.Length + "B)");
                    return null;
                }
                byte[] bytes = File.ReadAllBytes(path);
                // 7z/LZMA 头：前 5 字节是编码属性，随后 8 字节是解压后字节数；先按声明大小拦截解压炸弹。
                if (bytes.Length >= 13) {
                    long declared = 0L;
                    for (int i = 0; i < 8; i++) declared |= (long)bytes[5 + i] << (8 * i);
                    if (declared > MaxLocalXmlBytes) {
                        SRApi.LogWarn("[布局预设] 本地关卡解压后过大，已跳过: " + path + " (" + declared + "B)");
                        return null;
                    }
                }
                byte[] raw = SevenZip.Compression.LZMA.SevenZipHelper.Decompress(bytes);
                if (raw == null || raw.Length == 0 || raw.Length > MaxLocalXmlBytes) return null;
                string xml = Encoding.UTF8.GetString(raw);
                if (string.IsNullOrEmpty(xml) || xml.Length > MaxImportChars) return null;
                doc = ParseXmlSafe(xml);
                if (doc == null || doc.DocumentElement == null || doc.DocumentElement.Name != "scene") return null;
                blocks = CountBlocks(doc);
                if (blocks > MaxImportBlocks) {
                    SRApi.LogWarn("[布局预设] 本地关卡方块数超限，已跳过: " + path + " (" + blocks + ")");
                    return null;
                }
                return xml;
            } catch (Exception __ex) {
                SRApi.Guard.Log("布局预设/读取本地关卡快照", __ex);
                return null;
            }
        }

        // 本地关卡展示名：文件名去掉 .snapshot 与 .c/.v 后缀，空名回退文件名。
        private static string LocalLevelName(string fileName) {
            try {
                string n = fileName ?? "";
                if (n.EndsWith(".snapshot", StringComparison.OrdinalIgnoreCase)) n = n.Substring(0, n.Length - 9);
                if (n.EndsWith(".c", StringComparison.OrdinalIgnoreCase) || n.EndsWith(".v", StringComparison.OrdinalIgnoreCase))
                    n = n.Substring(0, n.Length - 2);
                return string.IsNullOrEmpty(n) ? (fileName ?? "") : n;
            } catch { return fileName ?? ""; }
        }

        // 扫描 snapshots 目录，把本地自定义关卡追加进 _presets（IsLocal=true，key="local:"+文件名）。
        private static void LoadLocalSnapshots() {
            try {
                string folder = LocalSnapshotsFolder();
                if (string.IsNullOrEmpty(folder) || !Directory.Exists(folder)) return;
                string[] files = Directory.GetFiles(folder, "*.snapshot");
                for (int i = 0; i < files.Length; i++) {
                    string fp = files[i];
                    string fn = Path.GetFileName(fp);
                    try {
                        XmlDocument doc;
                        int blocks;
                        string xml = ReadLocalSnapshotXml(fp, out doc, out blocks);
                        if (string.IsNullOrEmpty(xml) || doc == null || doc.DocumentElement == null) continue;
                        PresetInfo li = new PresetInfo();
                        li.IsLocal = true;
                        li.LocalRelative = fn;
                        li.File = fn;
                        li.FilePath = fp;
                        li.Name = LocalLevelName(fn);
                        // 快照里带 snapshotName/levelName 时优先用它，否则按文件名回退。
                        string snapName = doc.DocumentElement.GetAttribute("snapshotName");
                        if (string.IsNullOrEmpty(snapName)) snapName = doc.DocumentElement.GetAttribute("levelName");
                        if (!string.IsNullOrEmpty(snapName)) li.Name = snapName;
                        li.Mode = "";   // 本地快照不存 GameMode：留空表示跟随加载模式
                        li.Blocks = blocks;
                        li.Ok = blocks > 0;
                        li.TimeUtc = File.GetLastWriteTimeUtc(fp);
                        li.Level = doc.DocumentElement.GetAttribute("levelSceneName") ?? "";
                        // 自定义关卡（BlankLevel）用文件名作为关卡名；内置关卡走本地化场景名。
                        if (string.Equals(li.Level, "BlankLevel", StringComparison.OrdinalIgnoreCase)) li.LevelName = li.Name;
                        string code = doc.DocumentElement.GetAttribute("snapshotCode");
                        if (string.IsNullOrEmpty(code)) code = doc.DocumentElement.GetAttribute("levelCode");
                        li.LevelCode = code ?? "";
                        _presets.Add(li);
                    } catch (Exception __ex) {
                        SRApi.Guard.Log("布局预设/扫描本地关卡单项", __ex);
                    }
                }
            } catch (Exception __ex) {
                SRApi.Guard.Log("布局预设/扫描本地关卡", __ex);
            }
        }

        // 统一读取入口：预设读 .xml；本地关卡解压 .snapshot（同一套大小/方块上限）；加载前按修改器策略改写 <mods>。
        private static string ReadPresetXml(PresetInfo p) {
            string xml = ReadPresetXmlRaw(p);
            return string.IsNullOrEmpty(xml) ? xml : ApplyModsPolicy(xml, p);
        }

        // 原样读取（不带修改器策略）：编辑器打开时用它读取预设自带的修改器值做草稿。
        private static string ReadPresetXmlRaw(PresetInfo p) {
            try {
                if (p == null) return null;
                if (!p.IsLocal) return ReadAllText(p.FilePath);
                XmlDocument doc;
                int blocks;
                return ReadLocalSnapshotXml(p.FilePath, out doc, out blocks);
            } catch (Exception __ex) {
                SRApi.Guard.Log("布局预设/读取预设XML", __ex);
                return null;
            }
        }

        private static int CountPresetEntries() {
            try {
                int n = 0;
                for (int i = 0; i < _presets.Count; i++) {
                    if (_presets[i] != null && !_presets[i].IsLocal) n++;
                }
                return n;
            } catch { return 0; }
        }



        private static PresetInfo FindPreset(string key) {
            try {
                if (string.IsNullOrEmpty(key)) return null;
                for (int i = 0; i < _presets.Count; i++) {
                    if (string.Equals(_presets[i].Key, key, StringComparison.OrdinalIgnoreCase)) return _presets[i];
                }
            } catch { /* 静默：非关键路径，失败可直接忽略 */ }
            return null;
        }







        // 读取预设 XML：加载与导入共用同一套上限（超大/畸形文件直接拒绝，避免卡顿或 OOM）。
        private static string ReadAllText(string path) {
            try {
                if (string.IsNullOrEmpty(path) || !File.Exists(path)) return null;
                long len = new FileInfo(path).Length;
                if (len > MaxImportChars) {
                    SRApi.NotifyT("预设文件过大，已拒绝加载（上限约 2MB）", "Preset file is too large and was not loaded (limit about 2MB)");
                    SRApi.LogWarn("[布局预设] 预设文件过大，已拒绝加载: " + path + " (" + len + " bytes)");
                    return null;
                }
                string xml = null;
                try { xml = File.ReadAllText(path, Encoding.UTF8); }
                catch (Exception __rx) { SRApi.Guard.Log("布局预设/读取主文件", __rx); }
                if (string.IsNullOrEmpty(xml)) {
                    // 主文件读不出来（写坏/被占用/截断）时回退到覆盖前的 .bak。
                    try {
                        string bak = path + ".bak";
                        if (File.Exists(bak)) {
                            xml = File.ReadAllText(bak, Encoding.UTF8);
                            if (!string.IsNullOrEmpty(xml)) SRApi.LogWarn("[布局预设] 主预设读取失败，已回退备份: " + bak);
                        }
                    } catch (Exception __rb) { SRApi.Guard.Log("布局预设/读取备份", __rb); }
                }
                if (string.IsNullOrEmpty(xml)) return null;
                if (!string.IsNullOrEmpty(xml) && xml.Length > MaxImportChars) {
                    SRApi.NotifyT("预设文件过大，已拒绝加载（上限约 2MB）", "Preset file is too large and was not loaded (limit about 2MB)");
                    return null;
                }
                // 方块数上限：与导入路径的 MaxImportBlocks 一致。
                int blocks = 0;
                int at = 0;
                while (true) {
                    at = xml.IndexOf("<block", at, StringComparison.Ordinal);
                    if (at < 0) break;
                    int after = at + 6;
                    // 只认 <block ... / <block> / <block/>，避免把 <blocked> 误计成方块。
                    if (after < xml.Length) {
                        char ch = xml[after];
                        if (ch == ' ' || ch == '\t' || ch == '\r' || ch == '\n' || ch == '>' || ch == '/') blocks++;
                    }
                    if (blocks > MaxImportBlocks) {
                        SRApi.NotifyT("预设方块数量超限，已拒绝加载", "The preset has too many blocks and was not loaded");
                        SRApi.LogWarn("[布局预设] 预设方块数超限，已拒绝加载: " + path);
                        return null;
                    }
                    at = after;
                }
                return xml;
            } catch (Exception __ex) {
                SRApi.Guard.Log("布局预设/读取预设文件", __ex);
                return null;
            }
        }


    }
}
