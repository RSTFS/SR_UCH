// 自由模式 · 自身状态：无敌 / 完美无敌 / 飞天 / 无视碰撞，只对本地自己生效。
using System;
using System.Collections.Generic;
using BepInEx.Configuration;
using HarmonyLib;
using SR_UCH.Tweaks;
using UnityEngine;

namespace SR_UCH {
    [SrFeature("sr.freeplay.self", "SelfState", "1.0", Modes = (int)(SRApi.ModeMask.Freeplay))]
    public class SelfState : ITweak {
        private const string Sec = "自由模式";

        private static ConfigEntry<bool> _invincible, _godMode, _fly, _ignoreCollision;
        private static ConfigEntry<KeyCode> _invincibleKey, _godModeKey, _flyKey, _ignoreCollisionKey;

        // 统一门控：GateMaster（设置页 All Enabled）+ 模式豁免；非自由模式下开关可开但无效。
        private static bool On(ConfigEntry<bool> e) {
            return e != null && e.Value && SRApi.GateMaster && SRApi.FeatureAllowed(typeof(SelfState));
        }

        // 分区：无敌 / 完美无敌
        private static System.Reflection.FieldInfo _invTimerField;
        private static bool _invWasOn;
        private static int _deathBypass;          // 深渊自调用放行深度（用计数，避免嵌套把标志提前清掉）
        private const string CauseFalling = "Falling";

        // 分区：飞天
        private static readonly Dictionary<int, Rigidbody2D> _rbCache = new Dictionary<int, Rigidbody2D>();

        public void Initialize(IFeatureHost plugin) {
            try {
                SelfReg();
                _invincible = plugin.Config.Bind(Sec, "Invincible", false, "无敌：免疫所有非强制死亡（陷阱/子弹/掉坑/拳击等）。");
                _godMode = plugin.Config.Bind(Sec, "God Mode", false, "完美无敌：在无敌之上再拦强制死亡（深坑、掉出判死线）。");
                _fly = plugin.Config.Bind(Sec, "Fly", false, "飞天：方向键自由飞行（上/下升降，左/右平移，按住 Shift 加速）。");
                _ignoreCollision = plugin.Config.Bind(Sec, "Ignore Collision", false, "无视碰撞：自己穿过所有实体碰撞（道具 + 场景/地面/墙体）。");
                _invincibleKey = plugin.Config.Bind(Sec, "Invincible Key", KeyCode.None, "无敌的快捷键（EX 页右键按钮可绑）。");
                _godModeKey = plugin.Config.Bind(Sec, "God Mode Key", KeyCode.None, "完美无敌的快捷键。");
                _flyKey = plugin.Config.Bind(Sec, "Fly Key", KeyCode.None, "飞天的快捷键。");
                _ignoreCollisionKey = plugin.Config.Bind(Sec, "Ignore Collision Key", KeyCode.None, "无视碰撞的快捷键。");

                SRApi.RegisterKey("自身状态-无敌", _invincibleKey, "press", delegate { SelfKey(_invincible, "无敌", "Invincible"); }, typeof(SelfState));
                SRApi.RegisterKey("自身状态-完美无敌", _godModeKey, "press", delegate { SelfKey(_godMode, "完美无敌", "God mode"); }, typeof(SelfState));
                SRApi.RegisterKey("自身状态-飞天", _flyKey, "press", delegate { SelfKey(_fly, "飞天", "Fly"); }, typeof(SelfState));
                SRApi.RegisterKey("自身状态-无视碰撞", _ignoreCollisionKey, "press", delegate { SelfKey(_ignoreCollision, "无视碰撞", "Ignore collision"); }, typeof(SelfState));

                SRApi.RegisterTick("自身状态-穿模", TickIgnore);
                SRApi.RegisterSceneHook(OnSceneChanged);
                // 三个补丁类独立注册：一个目标不存在只丢那一条。
                try { SRApi.RegisterPatch(typeof(KillPatch)); }
                catch (Exception __h1) { SRApi.LogWarn("自身状态/死亡拦截补丁跳过: " + __h1.Message); }
                try { SRApi.RegisterPatch(typeof(SetupDeathPatch)); }
                catch (Exception __h2) { SRApi.LogWarn("自身状态/广播死亡补丁跳过: " + __h2.Message); }
                try { SRApi.RegisterPatch(typeof(FixedPatch)); }
                catch (Exception __h3) { SRApi.LogWarn("自身状态/物理帧补丁跳过: " + __h3.Message); }
            } catch (Exception __ex) { SRApi.Guard.Log("自身状态/初始化", __ex); }
        }

        private static void SelfReg() {
            SRApi.Ref.Override("Character.KillCharacter", "自身状态：拦截死亡");
            SRApi.Ref.Override("Character.setupDeath", "自身状态：拦截广播死亡");
            SRApi.Ref.Override("Character.invincibleTimer", "自身状态：无敌计时器");
            SRApi.Ref.Override("Character.crouchingDown", "自身状态：蹲移");
            SRApi.LocKey(Sec, "Invincible", "无敌", "Invincible");
            SRApi.LocDesc(Sec, "Invincible", "无敌\n免疫非强制死亡（陷阱/子弹/掉坑/拳击）\n只对本机生效", "Invincible\nimmune to non-forced deaths (traps, bullets, pits, punches)\nlocal only");
            SRApi.LocKey(Sec, "God Mode", "完美无敌", "God mode");
            SRApi.LocDesc(Sec, "God Mode", "完美无敌\n在无敌之上再拦强制死亡（深坑、判死线）\n完全没有死亡反馈，不适合正常玩", "God mode\ninvincible plus forced deaths (pits, death line)\nno death feedback at all; not for normal play");
            SRApi.LocKey(Sec, "Fly", "飞天", "Fly");
            SRApi.LocDesc(Sec, "Fly", "飞天\n方向键自由飞行，Shift 加速\n不按键则悬停在空中", "Fly\nfly freely with the arrow keys; hold Shift to speed up\nstays hovering when no key is held");
            SRApi.LocKey(Sec, "Ignore Collision", "无视碰撞", "Ignore collision");
            SRApi.LocDesc(Sec, "Ignore Collision", "无视碰撞\n自己穿过所有实体碰撞\n可能掉出地图", "Ignore collision\npass through every solid collider\nmay fall out of the map");
        }

        // 分区：快捷键
        private static void SelfKey(ConfigEntry<bool> e, string zh, string en) {
            try {
                if (!SRApi.GateMaster) return;
                if (SRApi.Typing) return;
                Toggle(e, zh, en);
            } catch (Exception __ex) { SRApi.Guard.Log("自身状态/快捷键", __ex); }
        }

        // 直接写 ConfigEntry.Value 不会自动落盘，必须显式标记脏文件。
        internal static void MarkDirty(ConfigEntryBase e) {
            try { if (e != null) SRApi.Ctl.MarkConfigDirty(e.ConfigFile); } catch { /* 静默：保存失败不影响功能 */ }
        }

        private static void Toggle(ConfigEntry<bool> e, string zh, string en) {
            if (e == null) return;
            e.Value = !e.Value;
            MarkDirty(e);
            bool inMode = true;
            try { inMode = SRApi.FeatureAllowed(typeof(SelfState)); } catch { inMode = true; }
            if (!inMode) return;
            SRApi.NotifyT(zh + (e.Value ? "：开" : "：关"), en + (e.Value ? ": on" : ": off"));
        }

        // 分区：死亡拦截
        // 本地 KillCharacter 与房主广播的 setupDeath 两条路径都要拦，否则只挡一半。
        [HarmonyPatch(typeof(Character), "KillCharacter")]
        internal static class KillPatch {
            [HarmonyPrefix]
            private static bool Prefix(Character __instance, string cause, bool deathFreezeOn, int causedByPlayerNumber, bool force) {
                try {
                    if (__instance == null || !__instance.hasAuthority) return true;
                    if (On(_godMode)) return false;                       // 完美无敌：连强制死亡一起拦
                    if (force) return true;                               // 原版语义：强制死亡生效
                    if (_deathBypass > 0) return true;
                    bool ignoreMode = On(_ignoreCollision);
                    if (!On(_invincible) && !ignoreMode) return true;
                    if (cause == CauseFalling) {
                        // 深渊：普通无敌不拦；用计数放行一次 force 死亡以免递归。
                        _deathBypass++;
                        try { __instance.KillCharacter(cause, deathFreezeOn, causedByPlayerNumber, true); }
                        finally { if (_deathBypass > 0) _deathBypass--; }
                        return false;
                    }
                    return false;                                          // 普通死亡：拦下
                } catch { return true; /* 静默：拦截失败就放行，宁可多死一次也不卡死死亡流程 */ }
            }
        }

        [HarmonyPatch(typeof(Character), "setupDeath")]
        internal static class SetupDeathPatch {
            [HarmonyPrefix]
            private static bool Prefix(Character __instance, string cause) {
                try {
                    if (__instance == null || !__instance.hasAuthority) return true;
                    if (_deathBypass > 0) return true;
                    if (On(_godMode)) return false;
                    bool ignoreMode = On(_ignoreCollision);
                    if (!On(_invincible) && !ignoreMode) return true;
                    if (cause == CauseFalling) return true;                 // 深渊允许死亡（与上面一致）
                    return false;
                } catch { return true; /* 静默：同上，拦截失败即放行 */ }
            }
        }

        // 飞天与无敌续期合并到一个 FixedUpdate 后缀，减少每物理帧 Harmony 调用。
        [HarmonyPatch(typeof(Character), "FixedUpdate")]
        internal static class FixedPatch {
            [HarmonyPostfix]
            private static void Postfix(Character __instance) {
                try {
                    ApplyFly(__instance);
                    KeepInvincible(__instance);
                } catch (Exception __ex) { SRApi.Guard.Log("自身状态/物理帧", __ex); }
            }
        }

        private static Rigidbody2D Rb(Character c) {
            try {
                if (c == null) return null;
                int id = c.GetInstanceID();
                Rigidbody2D rb;
                if (_rbCache.TryGetValue(id, out rb) && rb != null) return rb;
                rb = c.GetComponent<Rigidbody2D>();
                if (_rbCache.Count > 64) _rbCache.Clear();
                _rbCache[id] = rb;
                return rb;
            } catch { return null; /* 静默：取不到刚体就当没有，下一物理帧再取 */ }
        }

        private static void ApplyFly(Character c) {
            try {
                if (!On(_fly)) return;
                if (c == null || !c.hasAuthority || c.Success) return;
                Rigidbody2D rb = Rb(c);
                if (rb == null) return;
                float mul = (Input.GetKey(KeyCode.LeftShift) || Input.GetKey(KeyCode.RightShift)) ? 2f : 1f;
                float vx = 0f, vy = 0f;
                if (Input.GetKey(KeyCode.UpArrow)) vy = 9f * mul;
                else if (Input.GetKey(KeyCode.DownArrow)) vy = -9f * mul;
                if (Input.GetKey(KeyCode.LeftArrow)) vx = -7f * mul;
                else if (Input.GetKey(KeyCode.RightArrow)) vx = 7f * mul;
                rb.velocity = new Vector2(vx, vy);
            } catch { /* 静默：物理帧高频路径，失败下帧重试，不写日志 */ }
        }

        // 共用游戏的重生无敌计时器续期；关闭时只清我们拉高的那份。
        private static void KeepInvincible(Character c) {
            try {
                if (c == null || !c.hasAuthority) return;
                if (_invTimerField == null) _invTimerField = SRApi.Ref.Field(typeof(Character), "invincibleTimer", "自身状态：无敌计时器");
                bool want = On(_godMode) || On(_invincible);
                if (want) {
                    _invWasOn = true;
                    float t = 0f;
                    if (_invTimerField != null) { try { t = (float)_invTimerField.GetValue(c); } catch { t = 0f; } }
                    if (t < 500f) c.StartInvincibleTimer(999f);
                } else if (_invWasOn) {
                    _invWasOn = false;
                    if (_invTimerField != null) {
                        try { if ((float)_invTimerField.GetValue(c) >= 500f) _invTimerField.SetValue(c, 0f); } catch { /* 静默：字段写入失败不影响死亡流程 */ }
                    }
                }
            } catch { /* 静默：物理帧高频路径，读不到计时器就下帧再续 */ }
        }


        // 分区：无视对象 / 无视碰撞
        private class IgnoreTarget {
            public Collider2D col;
            public bool wasEnabled;
            public bool noDisable;   // 其他角色身上的碰撞体：只关碰撞对，不禁用碰撞体
        }
        private static readonly List<IgnoreTarget> _ignored = new List<IgnoreTarget>();
        private static readonly List<Collider2D> _ignoredMine = new List<Collider2D>();
        private static Collider2D[] _pressCache = new Collider2D[0];
        private static float _ignoreRefreshAt;
        private static Character _ignoreChar;

        private static void OnSceneChanged() {
            try { RestoreIgnored(); } catch { /* 静默：换场景时旧碰撞体已销毁，无需恢复 */ }
            try { _ignoreChar = null; _rbCache.Clear(); } catch { /* 静默：缓存清理失败无副作用 */ }
        }

        private static Character LocalCharacter() {
            try {
                Character[] all = UnityEngine.Object.FindObjectsOfType<Character>();
                for (int i = 0; i < all.Length; i++) { if (all[i] != null && all[i].hasAuthority) return all[i]; }
            } catch { /* 静默：场景切换中取不到角色，下次 Tick 再取 */ }
            return null;
        }

        private static void TickIgnore() {
            try {
                bool wantCollision = On(_ignoreCollision);
                if (!wantCollision) { RestoreIgnored(); return; }
                if (_ignoreChar == null || !_ignoreChar.hasAuthority) _ignoreChar = LocalCharacter();
                Character c = _ignoreChar;
                if (c == null) return;
                if (Time.unscaledTime - _ignoreRefreshAt > 0.5f) {
                    _ignoreRefreshAt = Time.unscaledTime;
                    RestoreIgnored();
                    Rebuild(c, wantCollision);
                }
                PressIgnored();
                ClearHazards(c);
            } catch (Exception __ex) { SRApi.Guard.Log("自身状态/穿模", __ex); }
        }

        private static void PressIgnored() {
            Collider2D[] arr = _pressCache;
            for (int i = 0; i < arr.Length; i++) {
                Collider2D col = arr[i];
                if (col != null && col.enabled) { try { col.enabled = false; } catch { /* 静默：碰撞体销毁中，跳过 */ } }
            }
        }

        private static void ClearHazards(Character c) {
            try {
                ClearHazard(c.FeetPhysicsCollider);
                ClearHazard(c.LowerBodyCollider);
                ClearHazard(c.UpperBodyCollider);
            } catch { /* 静默：角色碰撞体在销毁中，跳过 */ }
        }

        private static void ClearHazard(CheckCollidingPlayer cc) {
            if (cc == null) return;
            try {
                if (cc.Hazard) cc.Hazard = false;
                if (cc.HazardType != null) cc.HazardType = null;
                if (cc.DeathPit) cc.DeathPit = false;
                if (cc.HazardPlacedByPlayer != 0) cc.HazardPlacedByPlayer = 0;
            } catch { /* 静默：属性写入失败不致命，下一帧再清 */ }
        }

        private static void RestoreIgnored() {
            for (int i = 0; i < _ignored.Count; i++) {
                IgnoreTarget t = _ignored[i];
                if (t == null || t.col == null) continue;
                for (int k = 0; k < _ignoredMine.Count; k++) {
                    Collider2D m = _ignoredMine[k];
                    if (m == null) continue;
                    try { Physics2D.IgnoreCollision(m, t.col, false); } catch { /* 静默：恢复碰撞对失败不致命 */ }
                }
                if (t.wasEnabled) { try { t.col.enabled = true; } catch { /* 静默：恢复碰撞体失败不致命 */ } }
            }
            _ignored.Clear();
            _ignoredMine.Clear();
            if (_pressCache.Length != 0) _pressCache = new Collider2D[0];
        }

        private static void Rebuild(Character c, bool wantCollision) {
            Collider2D[] mine = c.GetComponentsInChildren<Collider2D>(true);
            HashSet<int> mineIds = new HashSet<int>();
            for (int i = 0; i < mine.Length; i++) if (mine[i] != null) mineIds.Add(mine[i].GetInstanceID());
            HashSet<int> seen = new HashSet<int>();
            if (wantCollision) AddTargets(UnityEngine.Object.FindObjectsOfType<Collider2D>(), mineIds, seen);
            _ignoredMine.Clear();
            for (int i = 0; i < mine.Length; i++) {
                if (mine[i] == null) continue;
                _ignoredMine.Add(mine[i]);
                for (int j = 0; j < _ignored.Count; j++) {
                    Collider2D t = _ignored[j].col;
                    if (t == null) continue;
                    try { Physics2D.IgnoreCollision(mine[i], t, true); } catch { /* 静默：单个碰撞对失败不影响其它 */ }
                }
            }
            int pressCount = 0;
            for (int i = 0; i < _ignored.Count; i++) {
                IgnoreTarget t = _ignored[i];
                if (t != null && !t.noDisable && t.col != null) pressCount++;
            }
            if (_pressCache.Length != pressCount) _pressCache = new Collider2D[pressCount];
            int pk = 0;
            for (int i = 0; i < _ignored.Count; i++) {
                IgnoreTarget t = _ignored[i];
                if (t != null && !t.noDisable && t.col != null) _pressCache[pk++] = t.col;
            }
        }

        private static void AddTargets(Collider2D[] cols, HashSet<int> mineIds, HashSet<int> seen) {
            if (cols == null) return;
            for (int i = 0; i < cols.Length; i++) {
                Collider2D col = cols[i];
                if (col == null) continue;
                if (mineIds.Contains(col.GetInstanceID())) continue;   // 自己身上的不收
                if (!seen.Add(col.GetInstanceID())) continue;
                IgnoreTarget t = new IgnoreTarget();
                t.col = col;
                t.wasEnabled = col.enabled;
                // 其他角色的碰撞体只关碰撞对不禁用，否则对方在本地会穿地、抽搐。
                Character other = col.GetComponentInParent<Character>();
                t.noDisable = other != null && !other.hasAuthority;
                _ignored.Add(t);
            }
        }

        // 分区：页面（自由模式页的「自身状态」分区）
        internal static void RenderRows() {
            try {
                float w = SRApi.Ctl.Sc(200f);
                float gap = SRApi.Ctl.Sc(12f);
                RenderPair(SRApi.Tid("1b9e3f8e50", "无敌：", "Invincible: "), SRApi.Tid("b97a44acdd", "自己免疫非强制死亡", "Immune to non-forced deaths"),
                           On(_invincible), _invincibleKey, delegate { Toggle(_invincible, "无敌", "Invincible"); },
                           SRApi.Tid("843e457386", "飞天：", "Fly: "), SRApi.Tid("c84116a612", "方向键自由飞行", "Fly with the arrow keys"),
                           On(_fly), _flyKey, delegate { Toggle(_fly, "飞天", "Fly"); }, w, gap);
                GUILayout.Space(SRApi.Ctl.Sc(4f));
                RenderPair(SRApi.Tid("5ca4434851", "完美无敌：", "God mode: "), SRApi.Tid("c1af606272", "连强制死亡、深坑、掉出判死线都拦", "Also blocks forced deaths (pits, death line)"),
                           On(_godMode), _godModeKey, delegate { Toggle(_godMode, "完美无敌", "God mode"); },
                           SRApi.Tid("ffcbbac6d6", "无视碰撞：", "Ignore collision: "), SRApi.Tid("92c9343976", "自己穿过所有实体碰撞", "Pass through every solid collider"),
                           On(_ignoreCollision), _ignoreCollisionKey, delegate { Toggle(_ignoreCollision, "无视碰撞", "Ignore collision"); }, w, gap);
            } catch (Exception __ex) { SRApi.Guard.Log("自身状态/渲染", __ex); }
        }

        private static void RenderPair(string z1, string t1, bool on1, ConfigEntry<KeyCode> k1, Action a1,
                                       string z2, string t2, bool on2, ConfigEntry<KeyCode> k2, Action a2,
                                       float w, float gap) {
            GUILayout.BeginHorizontal();
            try {
                if (SRApi.Ctl.SelfToggleButton(z1, t1, on1, k1, w, true)) a1();
                GUILayout.Space(gap);
                if (SRApi.Ctl.SelfToggleButton(z2, t2, on2, k2, w, true)) a2();
                GUILayout.FlexibleSpace();
            } finally { GUILayout.EndHorizontal(); }
        }
    }
}
