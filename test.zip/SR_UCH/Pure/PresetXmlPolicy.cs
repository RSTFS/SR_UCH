// 注意事项：预设 XML 的四层防护，纯字符串判定；文件 I/O 由调用方负责。
using System;
using System.IO;

namespace SR_UCH.Pure {
    internal static class PresetXmlPolicy {
        internal const long MaxBytes = 4L * 1024 * 1024;
        internal const int MaxPieces = 3000;
        internal const string RootName = "SR_UCH_Preset";

        internal static bool IsUnderRoot(string root, string candidate) {
            if (root == null || candidate == null) return false;
            string r = Path.GetFullPath(root).TrimEnd(Path.DirectorySeparatorChar, Path.AltDirectorySeparatorChar);
            string c;
            try { c = Path.GetFullPath(candidate); } catch { return false; }
            return c.Equals(r, StringComparison.OrdinalIgnoreCase)
                || c.StartsWith(r + Path.DirectorySeparatorChar, StringComparison.OrdinalIgnoreCase);
        }

        internal static bool SizeOk(long bytes) { return bytes >= 0 && bytes <= MaxBytes; }
        internal static bool ForbidsDtd(string text) {
            return text != null && !text.Contains("<!DOCTYPE") && !text.Contains("<!ENTITY");
        }
        internal static bool RootOk(string text) {
            return text != null && text.Contains("<" + RootName);
        }
        internal static bool All(string root, string candidate, long bytes, string text) {
            return IsUnderRoot(root, candidate) && SizeOk(bytes) && ForbidsDtd(text) && RootOk(text);
        }
    }
}
