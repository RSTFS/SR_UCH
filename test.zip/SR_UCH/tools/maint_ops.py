#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""维护操作三件套：CHK 影响路由 / 可重放 codemod / 离线重放。

被 tools/uch.py 与 tools/spec_engine.py 共同引用；零外部依赖。
改动固定 CHK 表时，必须同步 IMPACT，否则 IMPACT-001 会红。
"""
import json
import os
import re
import subprocess
import sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
os.chdir(ROOT)
GENDIR = 'build/specs/generated'
SPEC = 'build/specs/features.spec.json'


def rd(p):
    b = open(p, 'rb').read()
    if b.startswith(b'\xef\xbb\xbf'):
        b = b[3:]
    return b.decode('utf-8').replace('\r\n', '\n')


def wr(p, s):
    os.makedirs(os.path.dirname(p), exist_ok=True)
    open(p, 'wb').write(s.encode('utf-8'))


def js(p):
    return json.loads(rd(p))


def dump(o):
    return json.dumps(o, ensure_ascii=False, indent=2) + '\n'


# ---------------------------------------------------------------- 1. CHK 影响路由
# 每项：owners（路径前缀/glob 片段）+ depends（必须先跑的 CHK）。
# '#' 前缀表示"任何源码/声明改动都要跑"的全局项。
def _i(owners, deps=()):
    return {'owners': list(owners), 'depends': list(deps)}


IMPACT = {
    'ENV-001': _i([]), 'ENV-002': _i([]), 'ENV-003': _i([]), 'ENV-004': _i([]),
    'SPEC-001': _i([SPEC]), 'SPEC-002': _i([SPEC], ['SPEC-001']),
    'SPEC-003': _i([SPEC, 'build/specs/generated/facts.generated.json']),
    'SPEC-004': _i([SPEC]), 'SPEC-005': _i([SPEC]),
    'GEN-001': _i([GENDIR]), 'GEN-002': _i([SPEC, GENDIR]),
    'GEN-003': _i([GENDIR]), 'GEN-004': _i([GENDIR], ['GEN-003']),
    'GEN-005': _i([GENDIR + '/sources.manifest.json', 'SR_UCH/', 'Features/', 'Pure/', 'MainPlugin.cs']),
    'RSP-001': _i(['build/rsp/', SPEC]),
    'RSP-002': _i(['build/rsp/']),
    'RSP-003': _i(['build/rsp/sr_uch.rsp', GENDIR + '/facts.generated.json']),
    'RSP-004': _i(['build/rsp/', GENDIR + '/sources.manifest.json']),
    'SRC-001': _i(['SR_UCH/', 'Features/', 'Pure/', 'tests/', 'MainPlugin.cs']),
    'RATCHET-001': _i(['SR_UCH/Contracts/', GENDIR + '/ratchets.json', SPEC]),
    'RATCHET-002': _i(['SR_UCH/', 'Features/', 'Pure/', 'MainPlugin.cs', GENDIR + '/ratchets.json']),
    'TOOL-001': _i(['tools/', SPEC]), 'TOOL-002': _i(['.github/workflows/guards.yml', 'tools/uch.py']),
    'TOOL-003': _i(['tools/spec_engine.py', 'tools/uch.py']),
    'ARCH-001': _i(['SR_UCH/', 'Features/', 'Pure/', 'tools/check_architecture.py', SPEC]),
    'UI-001': _i(['build/specs/ui.pages.json', 'SR_UCH/Contracts/SrPageModel.cs', 'tools/check_uimodel.py']),
    'SINGLE-001': _i([SPEC]),
    'UI-002': _i(['build/specs/ui.pages.json', GENDIR + '/ui-model.generated.json']),
    'UI-003': _i([GENDIR + '/ui-model.generated.json']),
    'DOC-001': _i(['docs/', 'tools/uch.py']),
    'DOC-002': _i(['docs/STATUS.md', GENDIR + '/facts.generated.json']),
    'DOC-003': _i(['README.md', 'README.zh-CN.md']),
    'HEALTH-001': _i(['SR_UCH/Contracts/HealthSnapshot.cs', GENDIR + '/health.schema.json', GENDIR + '/facts.generated.json']),
    'CONTRACT-001': _i(['SR_UCH/', 'Features/', 'MainPlugin.cs', GENDIR + '/selftest.expected.json', SPEC]),
    'CONTRACT-002': _i([GENDIR + '/contract-verification.json', GENDIR + '/contract-fingerprint.json']),
    'NET-001': _i(['SR_UCH/Contracts/Generated/NetMessages.g.cs', 'SR_UCH/Contracts/NetMsgId.cs']),
    'CFG-001': _i([SPEC]),
    'CI-001': _i(['.github/workflows/guards.yml', GENDIR + '/facts.generated.json']),
    'CI-002': _i(['.github/workflows/guards.yml']),
    'LEGACY-001': _i(['build/', SPEC]),
    'MANIFEST-001': _i([GENDIR + '/verify.manifest.json']),
    'CATCH-001': _i(['SR_UCH/', 'Features/', 'Pure/', 'MainPlugin.cs']),
    # 本轮新增
    'ENGINE-001': _i(['tools/spec_engine.py', GENDIR], ['SPEC-002']),
    'ENGINE-002': _i(['build/build.ps1', 'build/run-tests.ps1', 'tools/spec_engine.py']),
    'DUPE-001': _i(['.github/workflows/guards.yml', 'tools/spec_engine.py', 'tools/uch.py']),
    'IMPACT-001': _i(['tools/maint_ops.py', 'tools/uch.py', GENDIR + '/checks.generated.json']),
    'META-001': _i(['tools/uch_rules.py', 'tools/uch.py', 'build/specs/features.spec.json']),
    'ERROR-001': _i(['SR_UCH/', 'Features/', 'Pure/', 'MainPlugin.cs', GENDIR + '/error-sites.generated.json']),
    'SHADOW-001': _i([GENDIR + '/ui-shadow.generated.json', SPEC, 'build/specs/ui.pages.json']),
    'RUNTIME-001': _i(['SR_UCH/Contracts/SrRuntime.cs', 'Pure/RuntimeRules.cs', 'tests/PureTests.cs']),
    'CODEMOD-001': _i(['tools/maint_ops.py', SPEC]),
    'SMOKE-001': _i(['tools/uch.py', GENDIR + '/smoke.generated.json', GENDIR + '/health.golden.json']),
}


def route(path):
    """改了 path，需要跑哪些 CHK（含依赖闭包），返回 [(id, 原因)]。"""
    p = path.replace('\\', '/')
    hit, why = [], {}
    for cid, meta in IMPACT.items():
        owners = meta['owners']
        if '#' in owners:
            hit.append(cid)
            why[cid] = '全局项（任何改动都跑）'
            continue
        for o in owners:
            if o in p or (o.endswith('/') and p.startswith(o)) or (o in SPEC and p == SPEC):
                hit.append(cid)
                why[cid] = 'owner: ' + o
                break
    # 依赖闭包
    changed = True
    while changed:
        changed = False
        for cid in list(hit):
            for d in IMPACT.get(cid, {}).get('depends', []):
                if d not in hit:
                    hit.append(d)
                    why[d] = '被 ' + cid + ' 依赖'
                    changed = True
    order = {cid: i for i, cid in enumerate(IMPACT)}
    return sorted(((c, why.get(c, '')) for c in hit), key=lambda x: order.get(x[0], 999))


# ---------------------------------------------------------------- 2. 可重放 codemod
def _run(args):
    try:
        r = subprocess.run(args, cwd=ROOT, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, timeout=180)
        return r.returncode, r.stdout.decode('utf-8', 'replace').strip().splitlines()
    except Exception as e:
        return 2, [str(e)]


def _checks():
    s = js(SPEC)
    return [
        ('M01', '声明单源化', s['schema'] == 3,
         lambda: _fix_spec_schema()),
        ('M02', '生成物归位', all('/Generated/' in p for p in
              [x for x in _all_cs() if x.endswith('.g.cs')]),
         lambda: _fix_generated()),
        ('M04', '页面模型', js(GENDIR + '/ui-model.generated.json')['page_count'] == 29,
         lambda: _run([sys.executable, 'tools/check_uimodel.py', '--generate'])[0]),
        ('M05', 'cfg schema 门', s['cfg']['schema'] == 3 and os.path.isfile('SR_UCH/Contracts/SrCfgColumns.cs'),
         lambda: _fix_cfg_schema()),
        ('M06', '指纹哈希链', js(GENDIR + '/contract-verification.json')['fingerprint_hash'] ==
              js(GENDIR + '/facts.generated.json')['fingerprint_hash'],
         lambda: _fix_hash_chain()),
        ('M07', '构建图同源', all(('Include="%s"' % x['name']) in rd(GENDIR + '/references.props')
              for x in s['build']['game']),
         lambda: _run([sys.executable, 'tools/spec_engine.py', 'generate'])[0]),
        ('M08', '统一基线', js(GENDIR + '/verify.manifest.json')['spec_schema'] == s['schema'],
         lambda: _run([sys.executable, 'tools/uch.py', 'seal'])[0]),
        ('M09', '单一引擎可跑', _run([sys.executable, 'tools/spec_engine.py', 'derive'])[0] == 0,
         lambda: _run([sys.executable, 'tools/spec_engine.py', 'verify'])[0]),
        ('M10', '错误站点覆盖', js(GENDIR + '/error-sites.generated.json')['count'] ==
              js(GENDIR + '/ratchets.json')['silent_catch_total'],
         lambda: _run([sys.executable, 'tools/spec_engine.py', 'generate'])[0]),
    ]


def _all_cs():
    out = []
    for d in ['.']:
        for dp, dn, fn in os.walk(d):
            if '.git' in dp or dp.startswith('./build') or dp.startswith('./docs'):
                continue
            for f in fn:
                if f.endswith('.cs'):
                    out.append(os.path.join(dp, f)[2:].replace('\\', '/'))
    return sorted(out)


def _fix_spec_schema():
    s = js(SPEC)
    s['schema'] = 3
    wr(SPEC, dump(s))
    return 0


def _fix_cfg_schema():
    s = js(SPEC)
    s['cfg']['schema'] = 3
    wr(SPEC, dump(s))
    return 0


def _fix_generated():
    n = 0
    for p in _all_cs():
        if p.endswith('.g.cs') and '/Generated/' not in p:
            dst = 'SR_UCH/Contracts/Generated/' + os.path.basename(p)
            if not os.path.isfile(dst):
                os.rename(p, dst)
                n += 1
    return 0


def _fix_hash_chain():
    p = GENDIR + '/contract-verification.json'
    d = js(p)
    d['fingerprint_hash'] = js(GENDIR + '/facts.generated.json')['fingerprint_hash']
    wr(p, dump(d))
    return 0


def status():
    return all(ok for mid, title, ok, fix in _checks())


def codemod(apply=False):
    rows = _checks()
    print('== codemod 可重放规则（%d 条） ==' % len(rows))
    missing = 0
    for mid, title, ok, fix in rows:
        print('  %s  %-18s %s' % (mid, title, 'OK' if ok else 'NEED-FIX'))
        if not ok:
            missing += 1
            if apply:
                r = fix()
                print('       → 已重放，exit=%s' % r)
    if apply:
        rows2 = _checks()
        bad = [m for m, t, ok, f in rows2 if not ok]
        print('\n重放后: %s' % ('全部齐备' if not bad else '仍缺 ' + ', '.join(bad)))
        return 1 if bad else 0
    print('\n结论: %s（加 --apply 真重放；-Generate 之外不需要人肉改）' %
          ('全部齐备' if not missing else '%d 条待重放' % missing))
    return 0


# ---------------------------------------------------------------- 3. 离线重放
def replay(selftest_only=False):
    """headless trace + golden selftest：无游戏也能重放的纯数据断言。"""
    fails = []
    if not selftest_only:
        pages = js('build/specs/ui.pages.json')['pages']
        uim = js(GENDIR + '/ui-model.generated.json')
        traces = uim.get('traces', {})
        n = 0
        for pg in pages:
            pid = pg['id']
            trace = traces.get(pid) if isinstance(traces, dict) else None
            # 与 Pure/UiTrace.cs 同源：每页一条轨迹，首节点归属正确，滚动节点不嵌套。
            if not isinstance(trace, str) or not trace:
                fails.append('缺 trace: ' + pid)
                continue
            parts = trace.split('|')
            if not parts or not parts[0].startswith('page:' + pid):
                fails.append('trace 归属错: ' + pid)
            if sum(1 for x in parts if x.startswith('scroll:')) > 1:
                fails.append('滚动策略违规（嵌套）: ' + pid)
            if pg.get('policy') not in ('per-page', 'global'):
                fails.append('策略未声明: ' + pid)
            n += 1
        print('[replay] headless trace: %d/%d 页通过' % (n, len(pages)))
    exp = js(GENDIR + '/selftest.expected.json')
    golden = js(GENDIR + '/health.golden.json')
    for k, want in golden['expect'].items():
        got = exp.get(k)
        if got != want:
            fails.append('golden selftest %s: %s != %s' % (k, got, want))
    print('[replay] golden selftest: %d 项比对' % len(golden['expect']))
    if fails:
        for f in fails[:20]:
            print('  [FAIL] ' + f)
        print('== replay FAIL %d ==' % len(fails))
        return 1
    print('== replay PASS ==')
    return 0


def main():
    a = sys.argv[1:]
    if a and a[0] == 'route' and len(a) > 1:
        for cid, why in route(a[1]):
            print('  %-12s %s' % (cid, why))
        return 0
    if a and a[0] == 'codemod':
        return codemod('--apply' in a)
    if a and a[0] == 'replay':
        return replay('--selftest' in a)
    print('maint_ops.py route <file> | codemod [--apply] | replay [--selftest]')
    return 2


if __name__ == '__main__':
    sys.exit(main())
