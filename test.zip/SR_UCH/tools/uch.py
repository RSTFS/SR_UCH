#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""SR_UCH 唯一维护入口（零外部依赖，Python 3.8+）。

  uch.py verify [--strict]       统一回归：固定 CHK 表 + 单一 manifest 基线
  uch.py seal                    登记生成器产物哈希（生成器写回产物后调用）
  uch.py smoke                   一条命令冒烟：读基线 + 环境诊断 + 双轨闸门
  uch.py doctor                  环境诊断，给出明确的下一步命令
  uch.py trace-gate              双轨退役闸门（批次覆盖率）
  uch.py rules --suite <name>    机械守卫唯一实现
  uch.py precompile              第一次真编译前的离线预检
  uch.py freeze-check            与已提交基线逐字节核对
  uch.py migrate [--dry-run]     列出/核对历轮结构改动是否齐备
  uch.py docs                    生成 docs/INDEX.md 单一文档入口
  uch.py add <Name>              生成功能骨架（无 pwsh 也能跑）
  uch.py remove <Name>           列出删除残渣清单

设计原则：判定逻辑只有一份（spec_engine.py 派生 / uch_rules.py 守卫），
本入口统一调度、统一报告、统一基线；不再有第二套解析或转发薄壳。
"""
import argparse, glob, hashlib, json, os, re, shutil, subprocess, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import maint_ops
import uch_rules

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
os.chdir(ROOT)
SPEC = 'build/specs/features.spec.json'
GENDIR = 'build/specs/generated'
MANIFEST = GENDIR + '/verify.manifest.json'
UCH_VERSION = 2
REQUIRED_SPEC_SCHEMA = 3
UCH_CHECKS = GENDIR + '/checks.generated.json'


def rd(p):
    b = open(p, 'rb').read()
    if b.startswith(b'\xef\xbb\xbf'):
        b = b[3:]
    return b.decode('utf-8').replace('\r\n', '\n')


def wr(p, s):
    os.makedirs(os.path.dirname(p), exist_ok=True)
    open(p, 'wb').write(s.encode('utf-8'))


def js(p):
    return json.loads(rd(p))


def sha(p):
    return hashlib.sha256(open(p, 'rb').read()).hexdigest()


def exists(p):
    return os.path.isfile(p)


def cs_files(sub):
    out = []
    for dp, dn, fn in os.walk(sub):
        for f in sorted(fn):
            if f.endswith('.cs'):
                out.append(os.path.join(dp, f).replace('\\', '/'))
    return sorted(out)


def run_script(rel):
    try:
        r = subprocess.run([sys.executable, rel], cwd=ROOT,
                           stdout=subprocess.PIPE, stderr=subprocess.STDOUT, timeout=180)
        tail = r.stdout.decode('utf-8', 'replace').strip().splitlines()
        last = tail[-1] if tail else '(no output)'
        return r.returncode == 0, 'exit=%d / %s' % (r.returncode, last[:110])
    except Exception as e:
        return False, '无法执行 %s: %s' % (rel, e)


def gen_hashes(exclude_self=True):
    out = {}
    if not os.path.isdir(GENDIR):
        return out
    for f in sorted(os.listdir(GENDIR)):
        p = GENDIR + '/' + f
        if not os.path.isfile(p):
            continue
        if exclude_self and f == 'verify.manifest.json':
            continue
        out[f] = sha(p)
    return out


def source_hashes():
    out = {}
    for d in ['SR_UCH', 'Features', 'Pure', 'tests', 'build', 'tools']:
        for dp, dn, fn in os.walk(d):
            for f in sorted(fn):
                p = os.path.join(dp, f).replace('\\', '/')
                if (f.endswith(('.cs', '.ps1', '.rsp', '.py', '.json', '.yml', '.props', '.targets'))
                        and p != MANIFEST):
                    out[p] = sha(p)
    out['MainPlugin.cs'] = sha('MainPlugin.cs')
    return out


# ---------------------------------------------------------------- 固定 CHK 表
# 每项 (id, 描述, 函数, 级别)：级别 fail 计入 FAIL；info 只报告。
# ID 与顺序稳定 —— 任何报告都引用同一套，不再出现 85/56/46/32 的口径漂移。
def _rules_quiet(action, *args):
    r = subprocess.run([sys.executable, 'tools/uch_rules.py', action] + list(args),
                       stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    return r.returncode, r.stdout.decode('utf-8', 'replace')


def C():
    s = js(SPEC)
    tc = s['toolchain']
    facts = js(GENDIR + '/facts.generated.json')
    checks = []

    def add(i, d, fn, level='fail'):
        checks.append((i, d, fn, level))

    # --- 环境 ---
    add('ENV-001', 'Python >= 3.8', lambda: (sys.version_info >= (3, 8), 'Python %d.%d.%d' % sys.version_info[:3]))
    add('ENV-002', 'pwsh 可用（生成器本体）',
        lambda: (shutil.which('pwsh') is not None, '本地需安装；CI 用 setup 自带'), 'info')
    add('ENV-003', 'dotnet 可用（真编译）',
        lambda: (shutil.which('dotnet') is not None, 'CI compile-gate / pure-tests 会跑'), 'info')
    add('ENV-004', 'UCH_MANAGED 已配置（全源码 IL）',
        lambda: (bool(os.environ.get('UCH_MANAGED') or os.environ.get('UCH_MANAGED_DIR')),
                 '未配置则跳过全源码 IL 编译，这是唯一硬缺口'), 'info')

    # --- 声明 ---
    add('SPEC-001', 'spec 存在且可解析', lambda: (exists(SPEC), SPEC))
    add('SPEC-002', 'spec schema == %d' % REQUIRED_SPEC_SCHEMA,
        lambda: (s['schema'] == REQUIRED_SPEC_SCHEMA, 'schema=%s' % s['schema']))
    add('SPEC-003', '组/功能/核心功能数与 facts 一致',
        lambda: ((len(s['groups']), len(s['features']), len(s['core_features'])) ==
                 (facts['groups'], facts['features'], facts['core_features']),
                 '%d 组 / %d 功能 / %d 核心' % (len(s['groups']), len(s['features']), len(s['core_features']))))
    ids = [f.get('id') for f in s['features']]
    add('SPEC-004', 'feature id 唯一', lambda: (len(ids) == len(set(ids)), '%d 个 id' % len(ids)))
    need = ['entry', 'ci_entry_command', 'rsp_scope', 'api_level_scope', 'required_generated',
            'legacy_scripts', 'migrations', 'trace_gate', 'generated_policy']
    add('SPEC-005', 'toolchain 段完整',
        lambda: (all(k in tc for k in need),
                 '%d/%d 键' % (sum(1 for k in need if k in tc), len(need))))

    # --- 元层冻结 ---
    def _all_rules():
        rc, out = _rules_quiet('run', '--suite', 'all', '--json')
        try:
            j = json.loads(out)
            return (rc == 0 and j['failed'] == 0 and j['total'] > 0,
                    '%d 项 / %d FAIL' % (j['total'], j['failed']))
        except Exception as e:
            return (False, '规则输出不可解析: %s' % e)
    add('META-001', '机械守卫唯一实现全绿', _all_rules)

    # --- 派生产物 ---
    add('GEN-001', 'generated/ 目录存在', lambda: (os.path.isdir(GENDIR), GENDIR))
    miss = [x for x in tc['required_generated'] if not exists(GENDIR + '/' + x)]
    add('GEN-002', '必需生成物齐备', lambda: (not miss, '%d 项，缺 %s' % (len(tc['required_generated']), ', '.join(miss) or '0')))
    badjson = []
    for f in sorted(os.listdir(GENDIR)):
        if f.endswith('.json'):
            try:
                js(GENDIR + '/' + f)
            except Exception as e:
                badjson.append(f)
    add('GEN-003', '生成物 JSON 全部可解析', lambda: (not badjson, ', '.join(badjson) or '全部 OK'))
    sealed = exists(MANIFEST) and bool(js(MANIFEST).get('generator_seal'))
    add('GEN-004', '生成器产物哈希与 seal 一致',
        lambda: (True, '已 seal' if sealed else '未 seal（跑 uch.py seal）') if not sealed else
                (js(MANIFEST)['generator_seal']['hashes'] == gen_hashes(),
                 '一致' if js(MANIFEST)['generator_seal']['hashes'] == gen_hashes() else '哈希漂移：跑 -Generate + seal'),
        'info' if not sealed else 'fail')
    srcm = js(GENDIR + '/sources.manifest.json')
    srclist = [x.replace('\\', '/') for x in srcm['compile']]
    miss_src = [x for x in srclist if not exists(x)]
    add('GEN-005', '唯一源码清单 compile 全部存在',
        lambda: (not miss_src and len(srclist) > 0,
                 '%d 条，缺 %d' % (len(srclist), len(miss_src))))

    # --- 构建清单 ---
    rspgroups = [f for f in os.listdir('build/rsp') if f.startswith('feat_') and f.endswith('.rsp')]
    add('RSP-001', '单链构建：无 feat_*.rsp / 无 split 残留',
        lambda: (not rspgroups and not exists('build/rsp/sr_uch_core.rsp')
                 and not exists('build/rsp/sr_uch_contracts.rsp'),
                 'feat=%d / core=%s' % (len(rspgroups), exists('build/rsp/sr_uch_core.rsp'))))
    rspbad = []
    rsp_all = glob.glob('build/rsp/**/*.rsp', recursive=True)
    for p in rsp_all:
        b = open(p, 'rb').read()
        if not b.startswith(b'\xef\xbb\xbf') or b'\r\n' in b:
            rspbad.append(p)
    extra_rsp = [p for p in rsp_all if p.replace('\\', '/') != 'build/rsp/sr_uch.rsp']
    add('RSP-002', '全部 .rsp 为 BOM + LF 且单链只有 sr_uch.rsp',
        lambda: (not rspbad and not extra_rsp,
                 ', '.join(rspbad + [x + ' (多余)' for x in extra_rsp]) or '全部合规'))
    main_rsp = rd('build/rsp/sr_uch.rsp')
    n_src = len([l for l in main_rsp.splitlines() if re.search(r'\.cs"?\s*$', l)])
    add('RSP-003', 'sr_uch.rsp 源码数与 facts 一致',
        lambda: (n_src == facts['rsp_sources'], '%d / %d' % (n_src, facts['rsp_sources'])))
    rsp_scope = tc['rsp_scope']
    comp = set(x.replace('\\', '/') for x in js(GENDIR + '/sources.manifest.json')['compile'])
    def _inscope(f):
        for pat in rsp_scope['checked']:
            if pat == f:
                return True
            if '*' in pat:
                a, b = pat.split('*', 1)
                if f.startswith(a) and f.endswith(b):
                    return True
        return False
    rsp_ref_miss, rsp_checked = [], 0
    for f in sorted(os.listdir('build/rsp')):
        if not f.endswith('.rsp') or not _inscope(f):
            continue  # 外部插件清单按声明豁免
        for l in rd('build/rsp/' + f).splitlines():
            t = l.strip()
            if t.startswith('/'):
                continue
            m = re.search(r'([A-Za-z0-9_./\\-]+\.cs)"?\s*$', t)
            if m:
                rsp_checked += 1
                p = m.group(1).replace('\\', '/')
                if p not in comp:
                    rsp_ref_miss.append('%s:%s' % (f, p))
    add('RSP-004', '主链 rsp 源码行全部命中唯一源码清单',
        lambda: (not rsp_ref_miss and rsp_checked > 0,
                 '%d 行核对 / %d 条漂移（单链，外部清单 0 份）' %
                 (rsp_checked, len(rsp_ref_miss))))

    # --- 源码 ---
    allcs = cs_files('SR_UCH') + cs_files('Features') + cs_files('Pure') + cs_files('tests') + ['MainPlugin.cs']
    enc_bad = []
    for p in allcs:
        b = open(p, 'rb').read()
        if b.startswith(b'\xef\xbb\xbf') or b'\r\n' in b:
            enc_bad.append(p)
    add('SRC-001', '.cs 编码合规（无 BOM / LF）',
        lambda: (not enc_bad, '%d 个文件，%d 异常' % (len(allcs), len(enc_bad))))

    # --- 棘轮（口径来自 spec，不再各自硬编码）---
    scope = tc['api_level_scope']
    ex = tuple(scope['exclude_dirs'])
    afiles = [p for p in cs_files(scope['root']) if not any(x in p for x in ex)]
    am = re.search(r'public\s+const\s+int\s+ApiLevel\s*=\s*(\d+)', rd('SR_UCH/Contracts/Contracts.cs'))
    a_level, a_members = int(am.group(1)), sum(
        1 for p in afiles for l in rd(p).splitlines() if re.match(r'^\s*public\s', l))
    rat = js(GENDIR + '/ratchets.json')
    add('RATCHET-001', 'api_level 从声明口径派生且与 ratchets 一致',
        lambda: ((rat['api_level']['ApiLevel'], rat['api_level']['members']) == (a_level, a_members),
                 'ApiLevel=%d / public=%d（排除 Generated/）' % (a_level, a_members)))
    pat = re.compile(r'catch\s*(\([^)]*\))?\s*\{\s*(\}|/\*\s*静默)')
    sc_total = 0
    for d in ['SR_UCH', 'Features', 'Pure']:
        for p in cs_files(d):
            if '/tests/' in p:
                continue
            sc_total += len(pat.findall(rd(p)))
    sc_total += len(pat.findall(rd('MainPlugin.cs')))
    add('RATCHET-002', '静默 catch 棘轮一致',
        lambda: (sc_total == rat['silent_catch_total'], '%d / %d' % (sc_total, rat['silent_catch_total'])))

    # --- 工具链收敛 ---
    add('TOOL-001', '权威脚本齐备',
        lambda: (all(exists(x) for x in tc['legacy_scripts'] + ['tools/uch.py']),
                 '%d 个' % (len(tc['legacy_scripts']) + 1)))
    wf = rd('.github/workflows/guards.yml')
    add('TOOL-002', 'CI 只经 uch.py 调度 Python 守卫',
        lambda: ('python3 tools/check_' not in wf and 'tools/uch.py verify' in wf, '单一入口'))
    add('TOOL-003', '单一引擎 generate 末尾会 seal',
        lambda: ('seal' in rd('tools/spec_engine.py') and
                 'uch.py' in rd('tools/spec_engine.py'), '引擎 seal'))

    # --- 权威实现统一调度 ---
    add('ARCH-001', '源码分层与依赖方向', lambda: run_script('tools/check_architecture.py'))
    add('UI-001', '声明式页面模型对账', lambda: run_script('tools/check_uimodel.py'))
    add('SINGLE-001', '单产物声明与部署一致',
        lambda: (s['deployment']['mode'] == 'single' and s['deployment']['dll'] == s['artifacts']['dll'],
                 '%s / %s' % (s['deployment']['mode'], s['deployment']['dll'])))

    # --- 页面与双轨 ---
    pages = js('build/specs/ui.pages.json')['pages']
    uim = js(GENDIR + '/ui-model.generated.json')
    add('UI-002', '29 页声明与生成物一致',
        lambda: (len(pages) == uim['page_count'] == 29, '%d / %d' % (len(pages), uim['page_count'])))
    add('UI-003', 'trace-gate 状态可读',
        lambda: (isinstance(uim.get('traces'), (list, dict)), 'traces 字段存在'), 'info')

    # --- 文档 / 健康 / 契约 ---
    idx = 'docs/INDEX.md'
    add('DOC-001', 'docs/INDEX.md 单一入口已生成',
        lambda: (exists(idx) and '<!-- generated:uch.py docs -->' in rd(idx) and
                 sorted(f for f in os.listdir('docs') if f.endswith('.md')) == ['INDEX.md', 'STATUS.md'],
                 '2 份文档：入口 + 事实页'))
    status = rd('docs/STATUS.md')
    add('DOC-002', 'STATUS.md 数值与 facts 一致',
        lambda: (all('| %s | %s |' % (k, facts[k]) in status
                     for k in ['groups', 'features', 'core_features', 'ci_jobs', 'health_fields']), '5 项'))
    rmbad = []
    for f in ['README.md', 'README.zh-CN.md']:
        t = rd(f)
        if '<!-- generated:facts:begin' not in t or '<!-- generated:facts:end -->' not in t:
            rmbad.append(f)
    add('DOC-003', '中英 README 生成区块在位', lambda: (not rmbad, ', '.join(rmbad) or '两份'))
    hs = js(GENDIR + '/health.schema.json')
    add('HEALTH-001', '健康 schema 字段数与 facts 一致',
        lambda: (len(hs['fields']) == facts['health_fields'],
                 '%d / %d（含 %d 个事件码）' % (len(hs['fields']), facts['health_fields'], len(hs['event_codes']))))
    exp = js(GENDIR + '/selftest.expected.json')
    all_text = '\n'.join(rd(p) for p in cs_files('SR_UCH') + cs_files('Features') + ['MainPlugin.cs'])
    ref_keys = set(re.findall(r'Ref\.Override(?:<[^>]*>)?\s*\(\s*"([^"]+)"', all_text))
    add('CONTRACT-001', '自检期望与源码派生一致',
        lambda: ((exp['reflection_unique_keys'], exp['features_declared'], exp['groups_declared']) ==
                 (len(ref_keys), len(s['features']), len(s['groups'])),
                 '%d 唯一反射 key' % len(ref_keys)))
    cv = js(GENDIR + '/contract-verification.json')
    add('CONTRACT-002', '契约指纹离线比对 OK',
        lambda: (cv['verdict'] == 'OK' and not cv['suspected_missing'],
                 '%s / checked=%d' % (cv['verdict'], cv['checked'])))
    net = rd('SR_UCH/Contracts/Generated/NetMessages.g.cs')
    add('NET-001', '网络消息零裸号', lambda: (not re.search(r'=\s*\d{3,}', net), 'NetMsgId 常量'))
    add('CFG-001', 'cfg schema 门 == 3', lambda: (s['cfg']['schema'] == 3, 'schema=%s' % s['cfg']['schema']))

    # --- CI ---
    wj = wf[wf.find('\njobs:'):] if '\njobs:' in wf else wf
    jobs = re.findall(r'^  ([a-z][a-z0-9_-]*):\s*$', wj, re.M)
    add('CI-001', 'CI job 数与 facts 一致',
        lambda: (len(jobs) == facts['ci_jobs'], '%d / %d' % (len(jobs), facts['ci_jobs'])))
    add('CI-002', '每个 job 都有 steps',
        lambda: (wf.count('steps:') >= len(jobs), '%d steps 段' % wf.count('steps:')))

    # --- 本轮：单一引擎 / 错误模型 / 双轨 / 路由 / 重放 ---
    add('ENGINE-001', '单一声明引擎可跑且派生自洽',
        lambda: (run_script('tools/spec_engine.py --derive')[0] if False else
                 _engine_check(), 'spec_engine.py derive'))
    add('ENGINE-002', '判定逻辑只有一份实现（无第二套解析）',
        lambda: (not any(x in rd('build/build.ps1') + rd('build/run-tests.ps1')
                         for x in ['function Sync-', 'Get-Ratchet', 'WriteBaseline'])
                 and exists('tools/spec_engine.py') and exists('tools/uch_rules.py'),
                 'build/ 仅 2 个实脚本，判定全在 Python'))
    dupe_bad = _dupes()
    add('DUPE-001', '无重复注入块（历轮脚本累加垃圾已清）',
        lambda: (not dupe_bad, ', '.join(dupe_bad) or 'pwsh / CI / 生成器均干净'))
    chk_owners = js(UCH_CHECKS) if exists(UCH_CHECKS) else {'checks': {}}
    add('IMPACT-001', '固定 CHK 与影响路由表一一对应',
        lambda: (set(chk_owners['checks']) == set(i for i, d, f, l in checks) and
                 len(chk_owners['checks']) == len(checks),
                 '%d 项' % len(chk_owners['checks'])))
    es = js(GENDIR + '/error-sites.generated.json') if exists(GENDIR + '/error-sites.generated.json') else {'count': -1}
    add('ERROR-001', '结构化错误站点覆盖全部静默 catch',
        lambda: (es['count'] == js(GENDIR + '/ratchets.json')['silent_catch_total'] and
                 exists('SR_UCH/Contracts/SrError.cs'),
                 '%d 站点 / 事件码可粘贴' % es['count']))
    sh = js(GENDIR + '/ui-shadow.generated.json') if exists(GENDIR + '/ui-shadow.generated.json') else {}
    add('SHADOW-001', '双轨闸门：声明与实机证据分离',
        lambda: (sh.get('declaration_ready') is True and sh.get('allowed') ==
                 (bool(sh.get('cutover_requested')) and bool(sh.get('runtime_ab_evidence'))),
                 'cutover=%s / ab=%s' % (sh.get('allowed'), sh.get('runtime_ab_evidence'))))
    add('RUNTIME-001', '组合根关机顺序可注入替身单测',
        lambda: (all(x in rd('SR_UCH/Contracts/SrRuntime.cs') for x in
                     ['Configure(ISrServices', 'RuntimeRules.ShutdownOrder', 'SrErrorSink.Pending']) and
                 'SrErrorSink.Flush(s)' in rd('SR_UCH/SR.Health.cs') and
                 'RuntimeRules.OrderIsValid' in rd('tests/PureTests.cs'),
                 '4 域 + 错误合流 + 纯函数断言'))
    add('CODEMOD-001', '结构规则可重放且当前齐备',
        lambda: (maint_ops.status(), '10 条幂等规则全 OK' if maint_ops.status() else '有待重放项'))
    smoke = js(GENDIR + '/smoke.generated.json') if exists(GENDIR + '/smoke.generated.json') else {'steps': []}
    add('SMOKE-001', '全链路 smoke 步骤齐备',
        lambda: (len(smoke['steps']) >= 7 and exists(GENDIR + '/health.golden.json'),
                 '%d 步 + golden selftest' % len(smoke['steps'])))

    # --- 退役 / 自洽 ---
    stale = [f for f in tc['retired_baselines'] if exists('build/' + f)]
    add('LEGACY-001', '手填基线全部退役',
        lambda: (not stale, ', '.join(stale) or '%d 项已清' % len(tc['retired_baselines'])))
    if exists(MANIFEST):
        m = js(MANIFEST)
        okm = m.get('schema') == UCH_VERSION and m.get('spec_schema') == REQUIRED_SPEC_SCHEMA
    else:
        okm = True  # 首次运行会生成
    add('MANIFEST-001', 'verify.manifest.json 自洽',
        lambda: (okm, 'schema=%d / spec=%d' % (UCH_VERSION, REQUIRED_SPEC_SCHEMA)))
    add('CATCH-001', '静默 catch 可见性（诊断）',
        lambda: (True, '%d 处；事件码见 health.schema.json event_codes' % sc_total), 'info')
    return checks, s, facts



def _engine_check():
    r = subprocess.run([sys.executable, 'tools/spec_engine.py', 'derive'], cwd=ROOT,
                       stdout=subprocess.PIPE, stderr=subprocess.STDOUT, timeout=120)
    return r.returncode == 0, r.stdout.decode('utf-8', 'replace').strip().splitlines()[-1][:100] if r.stdout else ''


def _dupes():
    bad = []
    for p in ['.github/workflows/guards.yml', 'tools/spec_engine.py', 'tools/uch.py']:
        if not exists(p):
            continue
        seen = {}
        for l in rd(p).splitlines():
            k = l.strip()
            if len(k) > 25:
                seen[k] = seen.get(k, 0) + 1
        if any(v > 3 for k, v in seen.items()
               if 'doctor' in k or 'Get-Command python3' in k or '统一维护入口' in k or 'uch.py seal' in k):
            bad.append(p)
    return bad


def cmd_verify(strict=False, as_json=False, fast=False, changed=None, nowrite=False):
    checks, s, facts = C()
    sel = None
    if fast or changed:
        paths = list(changed or [])
        if fast and exists(MANIFEST):
            base = js(MANIFEST).get('source_hashes', {})
            paths += [p for p, h in base.items() if not exists(p) or sha(p) != h]
        routed = set()
        for p in paths:
            for cid, why in maint_ops.route(p):
                routed.add(cid)
        for cid, meta in maint_ops.IMPACT.items():
            if '#' in meta['owners']:
                routed.add(cid)
        sel = routed
        print('[fast] 变更 %d 个文件 → 路由命中 %d / %d 项 CHK（含全局项）' %
              (len(set(paths)), len(sel), len(checks)))
    owners_map = js(UCH_CHECKS)['checks'] if exists(UCH_CHECKS) else {}
    results, nfail, ninfo = [], 0, 0
    for i, d, fn, level in checks:
        if sel is not None and i not in sel:
            continue
        try:
            ok, detail = fn()
        except Exception as e:
            ok, detail = False, '检查自身异常: %s' % e
        status = 'ok' if ok else ('info' if level == 'info' else 'fail')
        if status == 'fail':
            nfail += 1
        if status == 'info':
            ninfo += 1
        results.append({'id': i, 'desc': d, 'status': status, 'detail': detail,
                       'owners': owners_map.get(i, {}).get('owners', [])})
        if not as_json:
            print('[%s] %-9s %-34s %s' % (
                {'ok': ' OK ', 'info': 'INFO', 'fail': 'FAIL'}[status], i, d, detail))
    if nowrite:
        print('\n== UCH verify (fast)  PASS %d / FAIL %d / INFO %d ==' %
              (len(results) - nfail - ninfo, nfail, ninfo))
        return 1 if nfail else 0
    mf = {
        'schema': UCH_VERSION, 'tool': 'tools/uch.py', 'spec_schema': s['schema'],
        'checks': results, 'counts': {'total': len(results), 'ok': len(results) - nfail - ninfo,
                                      'fail': nfail, 'info': ninfo},
        'generated_hashes': gen_hashes(), 'source_hashes': source_hashes(),
        'generator_seal': (js(MANIFEST).get('generator_seal') if exists(MANIFEST) else None),
        'engine': 'tools/spec_engine.py',
        'impact': UCH_CHECKS,
        'next': 'uch.py doctor'
    }
    wr(MANIFEST, json.dumps(mf, ensure_ascii=False, indent=2) + '\n')
    if not as_json:
        print('\n== UCH verify  PASS %d / FAIL %d / INFO %d  (共 %d 项，ID 稳定) ==' %
              (len(results) - nfail - ninfo, nfail, ninfo, len(results)))
        print('基线: ' + MANIFEST)
        print('下一步: uch.py doctor')
    else:
        print(json.dumps(mf, ensure_ascii=False))
    return 1 if (nfail and (strict or True)) else 0


def cmd_seal():
    h = gen_hashes()
    mf = js(MANIFEST) if exists(MANIFEST) else {
        'schema': UCH_VERSION, 'tool': 'tools/uch.py', 'spec_schema': js(SPEC)['schema'],
        'checks': [], 'counts': {}, 'generated_hashes': {}, 'source_hashes': {}, 'next': ''}
    mf['schema'] = UCH_VERSION
    mf['generator_seal'] = {'sealed_by': 'tools/spec_engine.py generate', 'count': len(h), 'hashes': h}
    mf['generated_hashes'] = h
    mf['spec_schema'] = js(SPEC)['schema']
    wr(MANIFEST, json.dumps(mf, ensure_ascii=False, indent=2) + '\n')
    print('[seal] %d 个生成物哈希已写入 %s' % (len(h), MANIFEST))
    return 0


def cmd_trace_gate(enforce=False):
    uim = js(GENDIR + '/ui-model.generated.json')
    pages = js('build/specs/ui.pages.json')['pages']
    tc = js(SPEC)['toolchain']['trace_gate']
    traces = uim.get('traces', {})
    cov = {}
    for b in ['1', '2', '3']:
        batch = [p for p in pages if str(p.get('batch')) == b]
        traced = [p for p in batch if isinstance(traces, dict) and p['id'] in traces]
        cov[b] = (len(traced), len(batch))
    print('== 双轨退役闸门（target batch %s / %s） ==' % (tc['target_batch'], tc['mode']))
    for b, (t, n) in cov.items():
        print('  批 %s: %d/%d 页有 trace  %s' % (b, t, n, 'READY' if n and t == n else 'BLOCKED'))
    t, n = cov[str(tc['target_batch'])]
    ready = n > 0 and t == n
    print('结论: %s' % ('声明层 READY（三批 trace 齐备）' if ready else '声明层 BLOCKED'))
    sh = js(GENDIR + '/ui-shadow.generated.json') if exists(GENDIR + '/ui-shadow.generated.json') else {}
    ab = bool(sh.get('runtime_ab_evidence'))
    want = bool(sh.get('cutover_requested'))
    allowed = bool(sh.get('allowed'))
    print('运行时证据: %s / cutover 请求: %s / 允许: %s' %
          ('PASS' if ab else 'MISSING', 'YES' if want else 'no', 'YES' if allowed else 'NO'))
    print('注意: 声明齐备只说明节点树完整；移除旧 IMGUI 必须同时有实机 A/B 证据。')
    if enforce and want and not allowed:
        print('结论: BLOCKED —— cutover_requested=true 但实机 A/B 证据缺失，禁止合入。')
        return 1
    if enforce and not want:
        print('结论: 声明层 READY / 未请求 cutover，旧绘制路径保持（CI 不红）。')
        return 0
    return 0 if (ready or tc['mode'] != 'enforce') else 1


def cmd_doctor(code=None):
    if code:
        return cmd_doctor_code(code)
    print('== uch.py doctor ==')
    have_pwsh = shutil.which('pwsh') is not None
    have_dotnet = shutil.which('dotnet') is not None
    have_managed = bool(os.environ.get('UCH_MANAGED') or os.environ.get('UCH_MANAGED_DIR'))
    print('  pwsh      : %s' % ('有' if have_pwsh else '无 → 生成器本体只能在本地/CI 跑；统一入口不依赖它'))
    print('  dotnet    : %s' % ('有' if have_dotnet else '无 → CI compile-gate / pure-tests 承担真编译'))
    print('  UCH_MANAGED: %s' % ('有 → 可跑全源码 IL 编译' if have_managed else '无 → 全源码 IL 编译跳过（唯一硬缺口）'))
    print('\n推荐顺序（任选环境）：')
    print('  1) python3 tools/uch.py verify --strict     # 统一回归，固定 CHK 表')
    print('  2) python3 tools/uch.py gen              # 重算全部派生产物')
    print('  3) pwsh ./build/build.ps1 -Check         # 或 dotnet build SR_UCH.csproj')
    print('  4) dotnet build SR_UCH.csproj -c Release -warnaserror  # 需 UCH_MANAGED')
    print('  5) 进游戏取 [SR.SelfTest] → 写 health.actual.json / ui-ab-evidence.json')
    print('  6) python3 tools/uch.py gen         # 单一引擎重算全部派生产物')
    print('  7) python3 tools/uch.py ship        # 兑现清单（推包/真编译/实机）')
    print('\n日常只需要第 1 条；改了声明/生成物后跑 uch.py seal 或 -Generate 重新 seal。')
    print('怀疑有人偷偷改过文件：uch.py freeze-check（与已提交基线逐字节核对）。')
    return 0


def cmd_smoke(full=False):
    if full:
        return cmd_smoke_full()
    print('== uch.py smoke ==')
    r = cmd_verify(strict=False)
    print()
    cmd_doctor()
    print()
    t = cmd_trace_gate()
    if exists(MANIFEST):
        mf = js(MANIFEST)
        print('\n[health] %s / 检查 %d 项 / 生成物 %d / 源码 %d' %
              ('PASS' if mf['counts'].get('fail', 0) == 0 else 'FAIL',
               mf['counts'].get('total', 0), len(mf['generated_hashes']), len(mf['source_hashes'])))
    return r or t




def _needs_bootstrap():
    try:
        req = js(SPEC)['toolchain']['required_generated']
    except Exception:
        req = ['facts.generated.json', 'sources.manifest.json']
    if any(not exists(GENDIR + '/' + x) for x in req):
        return True
    return not exists('build/rsp/sr_uch.rsp')


def cmd_materialize():
    return subprocess.run([sys.executable, 'tools/materialize.py'], cwd=ROOT).returncode


def _ensure():
    if os.environ.get('UCH_NO_BOOTSTRAP') == '1':
        return 0
    try:
        if _needs_bootstrap():
            print('[bootstrap] 派生物缺失，自动恢复…')
            os.environ['UCH_NO_BOOTSTRAP'] = '1'
            r = cmd_materialize()
            os.environ.pop('UCH_NO_BOOTSTRAP', None)
            return r
    except Exception:
        pass
    return 0

def cmd_gen(mode='generate'):
    r = subprocess.run([sys.executable, 'tools/spec_engine.py', mode], cwd=ROOT)
    print('完成后跑: python3 tools/uch.py verify --strict')
    return r.returncode


def cmd_impact(path):
    rows = maint_ops.route(path)
    print('== 影响路由: %s ==' % path)
    for cid, why in rows:
        print('  %-12s %s' % (cid, why))
    print('\n共 %d / %d 项 CHK；只跑这些用：uch.py verify --changed %s' %
          (len(rows), len(maint_ops.IMPACT), path))
    return 0


def cmd_smoke_full():
    steps = js(GENDIR + '/smoke.generated.json')['steps']
    print('== uch.py smoke --full（全链路可复现） ==')
    failed, skipped = [], []
    for st in steps:
        cmd = st['cmd']
        optional = bool(st.get('optional'))
        if cmd.startswith('dotnet') and shutil.which('dotnet') is None:
            skipped.append(st['id']); print('  [%s] %-20s SKIP（无 dotnet）' % (st['id'], st['name'])); continue
        if cmd.startswith('spec_engine.py'):
            args = [sys.executable, 'tools/spec_engine.py'] + cmd.split()[1:]
        elif cmd.startswith('maint_ops.py'):
            args = [sys.executable, 'tools/maint_ops.py'] + cmd.split()[1:]
        elif cmd.startswith('uch.py'):
            args = [sys.executable, 'tools/uch.py'] + cmd.split()[1:]
        else:
            args = cmd.split()
        r = subprocess.run(args, cwd=ROOT, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, timeout=300)
        out = r.stdout.decode('utf-8', 'replace').strip().splitlines()
        tail = out[-1][:90] if out else '(no output)'
        ok = r.returncode == 0
        if not ok and not optional:
            failed.append(st['id'])
        print('  [%s] %-20s %s / %s' % (st['id'], st['name'], 'OK' if ok else 'FAIL', tail))
    print('\n== smoke: FAIL %d / SKIP %d / 共 %d 步 ==' % (len(failed), len(skipped), len(steps)))
    if skipped:
        print('跳过（本地补跑）: ' + ', '.join(skipped))
    return 1 if failed else 0


def cmd_ship():
    p = GENDIR + '/ship.checklist.json'
    if not exists(p):
        print('缺 ' + p + '，先跑 uch.py gen')
        return 1
    d = js(p)
    print('== uch.py ship（兑现清单，由单一引擎派生） ==')
    for x in d['items']:
        print('  %s  %-38s [%s] %s' % (x['id'], x['name'], x['owner'], x['why']))
    print('\n本侧已就绪：单一引擎 / 固定 CHK / 影响路由 / 错误码 / 闸门 / 重放。')
    print('清单: ' + p)
    return 0


def cmd_doctor_code(code):
    p = GENDIR + '/error-sites.generated.json'
    if not exists(p):
        print('缺 ' + p); return 1
    d = js(p)
    hit = [x for x in d['sites'] if x['code'] == code]
    print('== %s：%d 个站点 / %s ==' % (code, len(hit), d['sites'][0]['action'] if d['sites'] else ''))
    for x in hit[:20]:
        print('  %-46s %-14s %s' % (x['site'], x['owner'], x['severity']))
    return 0


def cmd_freeze_check():
    """与已提交基线逐字节核对：谁在我不知情时改了源码或生成物。"""
    if not exists(MANIFEST):
        print('[frozen] 缺基线，先跑 uch.py verify')
        return 1
    mf = js(MANIFEST)
    src_base = {k: v for k, v in mf.get('source_hashes', {}).items() if k != MANIFEST}
    gen_base = mf.get('generated_hashes', {})
    drift = []
    for p, h in src_base.items():
        if not exists(p):
            drift.append('源码 缺失: %s' % p)
        elif sha(p) != h:
            drift.append('源码 变更: %s' % p)
    for f, h in gen_base.items():
        p = GENDIR + '/' + f
        if not exists(p):
            drift.append('生成物 缺失: %s' % f)
        elif sha(p) != h:
            drift.append('生成物 变更: %s' % f)
    cur = gen_hashes()
    extra = [f for f in cur if f not in gen_base]
    print('== uch.py freeze-check ==')
    print('  基线: 源码 %d / 生成物 %d' %
          (len(mf.get('source_hashes', {})), len(mf.get('generated_hashes', {}))))
    if drift or extra:
        print('  漂移 %d 项：' % (len(drift) + len(extra)))
        for d in (drift + ['生成物新增: ' + f for f in extra])[:20]:
            print('   - ' + d)
        print('  改完确认无误后跑 uch.py verify 重新写基线。')
        return 1
    print('  OK：当前树与已提交基线逐字节一致')
    return 0


def cmd_migrate(dry=False, apply=False):
    tc = js(SPEC)['toolchain']
    print('== 结构改动清单（可重放） ==')
    for m in tc['migrations']:
        print('  %s  %-42s → %s' % (m['id'], m['title'], m['chk']))
    if apply:
        print('\n[apply] 逐条真重放（幂等）…')
        return maint_ops.codemod(True)
    checks, _, _ = C()
    by = {i: fn for i, d, fn, lv in checks}
    misses = []
    for m in tc['migrations']:
        i = m['chk']
        if i not in by:
            misses.append('%s 缺 CHK %s' % (m['id'], i)); continue
        ok, _ = by[i]()
        if not ok:
            misses.append('%s (%s) 未通过' % (m['id'], i))
    print('\n结论: %s（加 --apply 真重放）' % ('全部齐备' if not misses else '缺 %d 项' % len(misses)))
    return 1 if misses else 0


def cmd_docs():
    """唯一文档入口：所有维护信息收在一份 INDEX.md（由本命令生成，勿手改）。"""
    L = ['<!-- generated:uch.py docs -->', '# SR_UCH 维护手册', '',
         '本文件是唯一文档入口，由 `python3 tools/uch.py docs` 生成。',
         '数值来自 `build/specs/generated/facts.generated.json` 与 `docs/STATUS.md`。', '',
         '## 结构：一个入口 / 一个引擎 / 一份规则', '',
         '- 唯一声明：`build/specs/features.spec.json`（schema 3，旧版直接拒绝）',
         '- 唯一入口：`tools/uch.py`（verify / gen / doctor / smoke / add / remove / docs …）',
         '- 唯一引擎：`tools/spec_engine.py`（从 spec + 磁盘源码派生全部生成物）',
         '- 唯一规则：`tools/uch_rules.py`（26 条机械守卫，`uch.py rules --suite all`）',
         '- 独立守卫：`tools/check_architecture.py`（分层）、`tools/check_uimodel.py`（页面）',
         '- 构建：`build/build.ps1`（rsp 单链）、`build/run-tests.ps1`（真实程序集测试）',
         '- 派生物：`build/rsp/`、`build/specs/generated/`、`*.g.cs` 由 `uch.py gen` 重算，勿手改', '',
         '## 日常三条命令', '', '```',
         'python3 tools/uch.py verify --strict   # 统一回归（固定 CHK + 单一基线）',
         'python3 tools/uch.py doctor            # 环境诊断与下一步',
         'python3 tools/uch.py gen               # 改了声明/源码后重算派生物',
         '```', '',
         '加功能：`uch.py add <Name>`（生成骨架并打印声明片段）；',
         '删功能：`uch.py remove <Name>`（列出残渣清单）→ 手工删除后 `gen` + `verify`。', '',
         '## 口径（既定，不再改动）', '',
         '- 单 DLL 构建；split 需求已移除；EX 与独立插件在各自项目构建',
         '- 关闭混乱牌组 → 所有人的修改器清空（无快照回滚）',
         '- 派对盒炸弹不处理；不加搜索框；README 描述文案人工维护',
         '- 不兼容旧版本：Tid 只认 @id，cfg schema 门 == 3', '',
         '## 诊断与游戏更新', '',
         '- 游戏更新后跑 `uch.py doctor` → 契约指纹离线比对，红哪条改哪个功能',
         '- 运行时健康状态由 `[SR.SelfTest]` / 诊断报告 / 结构化事件码给出',
         '- 双轨 UI 仍并跑：`uch.py trace-gate --enforce` 校验声明完整；',
         '  旧 IMGUI 路径的退役需实机 A/B 证据，未达标不请求 cutover', '',
         '## 验证边界', '',
         '- CI（3 个 job）：统一回归 / 契约层与纯函数层真实编译 / 构建图与全源码 IL',
         '- 全源码 IL 编译需要 `UCH_MANAGED_DIR`；本地 `build.ps1 -Check` 等价',
         '- 报告与基线：`build/specs/generated/verify.manifest.json`（固定 CHK ID）', '']
    wr('docs/INDEX.md', '\n'.join(L))
    print('[docs] docs/INDEX.md 已生成（唯一文档入口）')
    return 0

def cmd_add_remove(name, remove=False):
    """加功能：生成骨架 + 打印声明片段；删功能：列出残渣清单（真删仍需人工）。"""
    if remove:
        plan = GENDIR + '/removal-plan.json'
        print('== 删除 %s：残渣清单 ==' % name)
        if exists(plan):
            for x in js(plan).get('items', [])[:40]:
                print('  -', x if isinstance(x, str) else json.dumps(x, ensure_ascii=False))
        print('手工删除后跑: python3 tools/uch.py gen && python3 tools/uch.py verify --strict')
        return 0
    if not re.match(r'^[A-Za-z][A-Za-z0-9]*$', name):
        print('功能名只能用字母/数字且以字母开头')
        return 1
    fid = 'sr.' + name.lower()
    spec = js(SPEC)
    if any(f['id'] == fid for f in spec['features']):
        print('声明里已有该功能 id：' + fid)
        return 1
    path = 'Features/' + name + '.cs'
    if exists(path):
        print('已存在，不覆盖：' + path)
        return 1
    ranks = set()
    for p in glob.glob('Features/**/*.cs', recursive=True):
        ranks.update(int(x) for x in re.findall(r'SRApi\.Nav\([^,]+,\s*(\d+)\s*\)', rd(p)))
    rank = 131
    while rank in ranks:
        rank += 1
    tpl = """// <N>：<一句话说明>（由 tools/uch.py add 生成，按需补实现）。
using System;
using BepInEx.Configuration;
using UnityEngine;

namespace SR_UCH.Tweaks {
    [SrFeature("<ID>", "<N>", "1.0")]
    public class <N> : ITweak {
        private const string Sec = "<N>";
        private static ConfigEntry<bool> _enabled;

        private static void SelfReg() {
            SRApi.LocSec(Sec, "<N>", "<N>");
            SRApi.Nav(Sec, <RANK>);
            SRApi.RegisterPage(Sec, "Main", "主页", "Main", 10, RenderPage);
            SRApi.LocKey(Sec, "Enabled", "启用<N>", "Enable <N>");
            SRApi.LocDesc(Sec, "Enabled", "启用<N>\n打开后本功能才生效。",
                "Enable <N>\nTurn on to activate this feature.");
        }

        public void Initialize(IFeatureHost plugin) {
            try {
                SelfReg();
                _enabled = plugin.Config.Bind(Sec, "Enabled", false, "总开关：打开后本功能才生效。");
                SRApi.OnShutdown("<N>", Shutdown);
            } catch (Exception __ex) { SRApi.Guard.Log("<N>/初始化", __ex); }
        }

        public void Shutdown() { }

        private static void RenderPage() {
            if (_enabled != null) SRApi.Ctl.DrawEntryRow(_enabled, SRApi.Ctl.Sc(180f));
        }
    }
}
"""
    tpl = tpl.replace('<N>', name).replace('<ID>', fid).replace('<RANK>', str(rank))
    wr(path, tpl)
    print('已生成: %s (rank=%d)' % (path, rank))
    print('回填声明片段：')
    print('  groups[]  : { "id": "%s", "feature_ids": [ "%s" ] }' % (name, fid))
    print('  features[]: { "id": "%s", "name": "%s", "version": "1.0", "modes": "all", "provides": [] }' % (fid, name))
    print('随后跑: python3 tools/uch.py gen && python3 tools/uch.py verify --strict')
    return 0

def main():
    ap = argparse.ArgumentParser(description='SR_UCH 唯一维护入口')
    sub = ap.add_subparsers(dest='cmd')
    p = sub.add_parser('verify'); p.add_argument('--strict', action='store_true')
    p.add_argument('--json', action='store_true'); p.add_argument('--fast', action='store_true')
    p.add_argument('--changed', nargs='*', default=None)
    sub.add_parser('gen'); sub.add_parser('seal'); sub.add_parser('materialize'); sub.add_parser('smoke').add_argument('--full', action='store_true')
    p = sub.add_parser('doctor'); p.add_argument('--code', default=None)
    sub.add_parser('freeze-check')
    p = sub.add_parser('trace-gate'); p.add_argument('--enforce', action='store_true')
    p = sub.add_parser('migrate'); p.add_argument('--dry-run', action='store_true'); p.add_argument('--apply', action='store_true')
    p = sub.add_parser('codemod'); p.add_argument('--dry-run', action='store_true'); p.add_argument('--apply', action='store_true')
    p = sub.add_parser('impact'); p.add_argument('path')
    sub.add_parser('ship'); sub.add_parser('docs')
    sub.add_parser('precompile')
    p = sub.add_parser('rules'); p.add_argument('--suite', default='all')
    p.add_argument('--json', action='store_true'); p.add_argument('--generate', action='store_true')
    p.add_argument('--log'); p.add_argument('--health'); p.add_argument('--update', action='store_true')
    p = sub.add_parser('add'); p.add_argument('name')
    p = sub.add_parser('remove'); p.add_argument('name')
    a = ap.parse_args()
    if a.cmd not in (None, 'materialize', 'gen', 'seal'):
        if _ensure(): return 1
    if a.cmd == 'materialize': return cmd_materialize()
    if a.cmd == 'verify':
        return cmd_verify(a.strict, a.json, a.fast, a.changed, nowrite=(a.fast or a.changed is not None))
    if a.cmd == 'gen': return cmd_gen('generate')
    if a.cmd == 'seal': return cmd_seal()
    if a.cmd == 'smoke': return cmd_smoke(a.full)
    if a.cmd == 'doctor': return cmd_doctor(a.code)
    if a.cmd == 'freeze-check': return cmd_freeze_check()
    if a.cmd == 'trace-gate': return cmd_trace_gate(a.enforce)
    if a.cmd == 'migrate': return cmd_migrate(a.dry_run, a.apply)
    if a.cmd == 'codemod': return cmd_migrate(False, a.apply)
    if a.cmd == 'impact': return cmd_impact(a.path)
    if a.cmd == 'ship': return cmd_ship()
    if a.cmd == 'docs': return cmd_docs()
    if a.cmd == 'rules':
        return uch_rules.run_suite(a.suite, a.json, a.generate, a.log, a.health, a.update)
    if a.cmd == 'precompile': return uch_rules.precompile()
    if a.cmd == 'add': return cmd_add_remove(a.name, False)
    if a.cmd == 'remove': return cmd_add_remove(a.name, True)
    ap.print_help(); return 0


if __name__ == '__main__':
    sys.exit(main())
