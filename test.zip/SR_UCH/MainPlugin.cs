// 入口：配置外置、API sink 注入、功能装载、外部 DLL 扫描、程序集解析。
// 注意：功能装载统一走 FeatureRuntime.TryInit（按 Type 幂等），不要在别处再建已初始化表。
using System;
using UnityEngine;
using BepInEx.Configuration;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using BepInEx;
using BepInEx.Logging;
using SR_UCH.Tweaks;

namespace SR_UCH {
    // 单一真值：插件声明与 SR.Core.EnsureScanned 必须比对同一字符串；用 const 要求编译期内联。
    [BepInPlugin(PluginGuid, "SR_UCH", "1.0.0")]
    
    public class MainPlugin : BaseUnityPlugin, IFeatureHost {
        public const string PluginGuid = "com.rs.SR_UCH";

        public static ManualLogSource ModLogger;

        
        ManualLogSource IFeatureHost.Logger { get { return Logger; } }

        // 已处理过的外部程序集：同一份 DLL 只初始化一次。
        private static readonly HashSet<string> _extSeen = new HashSet<string>();

        // 配置外置：所有 Bind 落到这个文件，插件自己的 cfg 保持为空。
        public static BepInEx.Configuration.ConfigFile Data;

        // 进程退出 / 模组销毁：执行功能登记的关机回调。不要在这里 Unpatch：补丁表随程序集卸载，强拆会打断退出流程。
        private void OnDestroy() {
            try { SR.NetShutdown(); } catch (Exception __ns) { SRApi.Guard.Log("联机握手/注销", __ns); }
            try { SR.RunShutdowns(); } catch (Exception __sd) { try { ModLogger.LogWarning("[SR] 关机回调执行失败: " + __sd.Message); } catch { /* 静默：非关键路径，失败可直接忽略 */ } }
        }

        public void Awake() {
            // 必须是本方法第一条语句：后续步骤与其 catch 内的日志都依赖它。
            ModLogger = Logger;
            // 顶层兜底：任何一步异常都不能让模组"静默不启动"，失败须留可 grep 的标记行。
            string stage = "start";
            try {
                // 启动阶段计时：慢启动时看出卡在哪个阶段。
                System.Text.StringBuilder __boot = new System.Text.StringBuilder();
                System.Diagnostics.Stopwatch __sw = System.Diagnostics.Stopwatch.StartNew();
                System.Action<string, System.Action> __run = (nm, act) => {
                    stage = nm;
                    long __before = __sw.ElapsedMilliseconds;
                    act();
                    __boot.Append(nm).Append('=').Append(__sw.ElapsedMilliseconds - __before).Append("ms ");
                };
                __run("PatchOwnConfigFile", PatchOwnConfigFile);
                __run("SetupStandaloneConfig", SetupStandaloneConfig);
                __run("MigrateLegacyConfigNames", MigrateLegacyConfigNames);
                // 程序集解析：外部 DLL 只引用 SR_UCH.dll，全局注册一次。
                __run("AssemblyResolve", delegate { AppDomain.CurrentDomain.AssemblyResolve += OnAssemblyResolve; });
                __run("InjectApiSinks", InjectApiSinks);
                __run("InitializeTweaks", delegate { InitializeTweaks(); });
                    // 外部功能 / 语言包 DLL：一个 DLL 一个功能或一门语言。
                __run("LoadExternal", LoadExternal);
                // 装配完成后补扫一轮 ITweak；EX 自身幂等。
                __run("InitializeTweaks(late)", delegate { InitializeTweaks(true); });
                __run("RebuildFeatureManifest", RebuildFeatureManifest);   // 含功能清单登记 + 启动自检 + 自检日志
                    __run("NetHandshake", SR.NetInit);   // 联机版本/功能握手（纯提示，不改游戏状态）
                try { SR.BootTimings = __boot.ToString().TrimEnd(); } catch (Exception __bt) { SRApi.Guard.Log("启动耗时/记录", __bt); }
                try { ModLogger.LogInfo("[SR.Boot] 启动耗时: " + (SR.BootTimings ?? "?")); } catch (Exception __bl) { SRApi.Guard.Log("启动耗时/日志", __bl); }
            } catch (Exception __aw) {
                try {
                    ModLogger.LogError("[SR.Boot] 启动失败于阶段 " + stage + "：" + __aw);
                    ModLogger.LogError("[SR.SelfTest] FAIL 阶段=" + stage + " 原因=" + __aw.GetType().Name + ": " + __aw.Message);
                } catch { /* 静默：日志通道自身不可用时只能放弃 */ }
            }
        }

        // 需显式注册补丁（CreateAndPatchAll 不递归发现独立类型），失败只记日志。
        private void PatchOwnConfigFile() {
            try { SRApi.RegisterPatch(typeof(PatchOwnConfigFile)); }
            catch (Exception __pf) { try { ModLogger.LogWarning("配置外置补丁(PatchOwnConfigFile)注册失败: " + __pf.Message); } catch { /* 静默：非关键路径，失败可直接忽略 */ } }

        }

        // 独立配置文件（旧 cfg 自动迁移）+ 插件 Config 后备字段指向它。
        private void SetupStandaloneConfig() {

            try {
                string __dir = BepInEx.Paths.ConfigPath;
                string __newF = System.IO.Path.Combine(__dir, "SR_UCH_data.cfg");
                string __oldA = System.IO.Path.Combine(__dir, "com.rs.SR_UCH.cfg");
                string __oldB = System.IO.Path.Combine(__dir, "com.gamingbeast.SR_UCH.cfg");
                if (!System.IO.File.Exists(__newF)) {
                    if (System.IO.File.Exists(__oldA)) { System.IO.File.Copy(__oldA, __newF); ModLogger.LogInfo("[配置] 已迁移 com.rs.SR_UCH.cfg -> SR_UCH_data.cfg"); }
                    else if (System.IO.File.Exists(__oldB)) { System.IO.File.Copy(__oldB, __newF); ModLogger.LogInfo("[配置] 已迁移 com.gamingbeast.SR_UCH.cfg -> SR_UCH_data.cfg"); }
                }
                Data = new BepInEx.Configuration.ConfigFile(__newF, true);
                // 把 Config 后备字段指向本文件：BepInEx 自身保存也走这里。
                try {
                    System.Reflection.FieldInfo __cf = typeof(BepInEx.BaseUnityPlugin).GetField("<Config>k__BackingField",
                        System.Reflection.BindingFlags.Instance | System.Reflection.BindingFlags.NonPublic);
                    if (__cf != null && Data != null) { __cf.SetValue(this, Data); ModLogger.LogInfo("[配置] 插件 Config 已指向 SR_UCH_data.cfg（外置生效）"); }
                    else ModLogger.LogWarning("[配置] 未找到 Config 后备字段，配置外置可能未生效");
                } catch (Exception __cfx) { try { ModLogger.LogWarning("配置外置(后备字段)失败: " + __cfx.Message); } catch { /* 静默：非关键路径，失败可直接忽略 */ } }
            } catch (Exception __de) { try { ModLogger.LogWarning("配置外置失败: " + __de.Message); } catch { /* 静默：非关键路径，失败可直接忽略 */ } }

        }

        private void MigrateLegacyConfigNames() {
            try {
                string __cfgDir = BepInEx.Paths.ConfigPath;
                string __oldCfg = System.IO.Path.Combine(__cfgDir, "com.gamingbeast.SR_UCH.cfg");
                string __newCfg = System.IO.Path.Combine(__cfgDir, "com.rs.SR_UCH.cfg");
                if (System.IO.File.Exists(__oldCfg) && !System.IO.File.Exists(__newCfg)) {
                    System.IO.File.Copy(__oldCfg, __newCfg, false);
                    ModLogger.LogInfo("[配置] 已从旧 GUID 配置迁移: com.gamingbeast.SR_UCH.cfg -> com.rs.SR_UCH.cfg");
                }
            } catch (Exception __mig) { try { ModLogger.LogWarning("配置迁移失败: " + __mig.Message); } catch { /* 静默：非关键路径，失败可直接忽略 */ } }
        }

        // 契约层 API 门面的全部 sink：漏注入会让功能静默失效。
        private void InjectApiSinks() {
        // 结构登记：UI 层级与自定义消息号在启动期一次性声明，重复即进诊断报告。
        UiLayerRegistry.Reset(); NetMsgId.Reset();
        UiLayerRegistry.Register("SR.MainWindow", UiLayer.Main);
        UiLayerRegistry.Register("SR.FloatWindow", UiLayer.Modal);
        UiLayerRegistry.Register("SR.FloatWindow", UiLayer.Backdrop);
        UiLayerRegistry.Register("HUD", UiLayer.Hud);
        UiLayerRegistry.Register("NotifyHub", UiLayer.Toast);
        UiLayerRegistry.Register("FreePlay.Map", UiLayer.WorldOverlay);
        NetMsgId.Register("Chaos", NetMsgId.ChaosRule);
        NetMsgId.Register("Chaos", NetMsgId.ChaosCard);
        NetMsgId.Register("Chaos", NetMsgId.ChaosHello);
        NetMsgId.Register("Chaos", NetMsgId.ChaosKill);

            
            SinkStep("Log", delegate () {
                SRApi.SetLogSinks(
                    delegate (string __m) { SR.LogInfo(__m); },
                    delegate (string __m) { SR.LogWarn(__m); },
                    delegate (string __m) { SR.LogError(__m); });
            });
            SinkStep("CloseMenu", delegate () {
                SRApi.SetCloseMenuSink(delegate { SR.CloseMenuExternal(); });
                SRApi.SetOpenMenuSink(delegate { SR.OpenMenuExternal(); });
            });
            // 线程契约检查：仅诊断模式启用，越线程访问静态集合记一次警告。
            SinkStep("MainThread", delegate () {
                SR_UCH.MainThread.Enable(false);   // 线程契约检查默认关（零成本）
            });
            SinkStep("Notify", delegate () {
                SRApi.SetNotifySink(delegate (string __t) { SR.Notify(__t); });
                SRApi.SetNotifyExSink(delegate (SRApi.NotifyArgs __a) { SR.NotifyEx(__a); });
            });
            SinkStep("Ref", delegate () {
                SRApi.Ref.SetSinks(
                    delegate (Type __o, string __n, string __f) { return SR.RefField(__o, __n, __f); },
                    delegate (Type __o, string __n, string __f) { return SR.RefMethod(__o, __n, __f); },
                    delegate (Type __o, string __n, Type[] __p, string __f) { return SR.RefMethod(__o, __n, __p, __f); },
                    delegate (string __m, string __f) { SR.RefOverride(__m, __f); });
            });
            SinkStep("Ctl/Table sinks", delegate () {
                // 契约层给外部 DLL 预留的控件 / 表格 sink。
                SRApi.SetTableActionColumnWidthSink(delegate (SRApi.TableAction[] __a) { return SR.Ctl.TableActionColumnWidth(__a); });
                SRApi.SetTableColMoveSink(delegate (Event __e, Rect __c, int __ci, int __k, List<int> __cols, Vector2 __mp, bool __inBox,
                    List<Rect> __hc, int[] __ord, Action<int[]> __apply, Action __save, Action<int> __click,
                    ref int __mc, ref float __x0, ref float __dx, ref Vector2 __sc, ref Vector2 __scAt, bool __vert) {
                    return SR.TableColMove(__e, __c, __ci, __k, __cols, __mp, __inBox, __hc, __ord, __apply, __save, __click,
                        ref __mc, ref __x0, ref __dx, ref __sc, ref __scAt, __vert);
                });
                SRApi.Ctl.SetSelfToggleButtonSink(delegate (string __l, string __t, bool __on, ConfigEntry<KeyCode> __k, float __w, bool __bind) {
                    return SR.Ctl.SelfToggleButton(__l, __t, __on, __k, __w, __bind);
                });
                SRApi.Ctl.SetSelItemSink(delegate () { return SR.Ctl.SelItem; });
                SRApi.Ctl.SetCheckStylesSink(delegate () { return SR.Ctl.CheckOn; }, delegate () { return SR.Ctl.CheckOff; });
                SRApi.Ctl.SetForceZhSink(delegate () { return SR.Ctl.ForceZh; }, delegate (bool __v) { SR.Ctl.ForceZh = __v; });
            });
            SinkStep("Storage", delegate () {
                try {
                    string __root = System.IO.Path.Combine(BepInEx.Paths.ConfigPath, "SR_UCH_data");
                    SRApi.Storage.SetRoot(__root);
                    SRApi.Sinks.State("Storage", delegate { return SRApi.Storage.Ready; });
                } catch (Exception __st) { SRApi.Guard.Log("注入存储根目录", __st); }
            });
            SinkStep("LocDynamic", delegate () {
                SRApi.SetLocDynamicSink(delegate (ConfigEntryBase __e, string __zh, string __en) { SR.LocDynamic(__e, __zh, __en); });
            });
            SinkStep("FeatureGate", delegate () {
                SRApi.SetFeatureAllowedSink(delegate (Type __t) { return SR.FeatureAllowed(__t); });
            });
            SinkStep("KeyAction", delegate () {
                SRApi.SetKeyActionSink(delegate (string __n, ConfigEntry<KeyCode> __e, string __m, Action __a) {
                    SR.RegisterKeyAction(__n, __e, __m, __a);
                });
            });
            SinkStep("Section", delegate () {
                
                SRApi.WireSection(SR.SectionBegin, SR.SectionEnd);
                SRApi.Ctl.WireSection(SR.SectionBegin, SR.SectionEnd);
            });
            SinkStep("FeatureRuntime", delegate () {
                SR.InstallFeatureRuntime();
            });
            SinkStep("Ext", delegate () {
                SRApi.SetExtSinks(
                    delegate (string __s, int __r) { SR.FeatureNav(__s, __r); },
                    delegate (string __s) { SR.FeatureNavHide(__s); },
                    delegate (string __n, Action __a) { SR.FeatureTick(__n, __a); },
                    delegate (Action __a) { SR.FeatureScene(__a); },
                    delegate (Action __a) { SR.FeatureDismiss(__a); },
                    delegate (Func<float, bool> __w) { SR.FeatureWheel(__w); },
                    delegate (string __i, string __l, Action __a) { SR.FeatureHotkey(__i, __l, __a); },
                    delegate (string __n, Action __a) { SR.FeatureShutdown(__n, __a); });
            });
            SinkStep("State", delegate () {
                SRApi.SetStateSinks(
                    delegate { return SR.HasServer; },
                    delegate { return SR.GateMaster; },
                    delegate { return SR.GateHost; },
                    delegate { return SR.CanControlLocally; },
                    delegate { return SR.CanDoHost(); },
                    delegate { return SR.UiOpen; },
                    delegate { return SR.BlockInput; },
                    delegate { return SR.BlockWindowDrag; },
                    delegate { return SR.WheelFrame; },
                    delegate { return SR.TakeWheelEvent(); },
                    delegate { SR.MarkWheelUsed(); },
                    delegate { SR.ForceResetUiState(); },
                    delegate { SR.FlushConfig(); },
                    delegate (string __s) { return SR.SelectedPageId(__s); },
                    delegate (bool __v) { SR.BlockWindowDrag = __v; },
                    delegate (int __v) { SR.WheelFrame = __v; });
            });
            SinkStep("Lang", delegate () {
                SRApi.SetLangSinks(
                    delegate (string __id, string __z, string __e) { return SR.Tid(__id, __z, __e); },
                    delegate (string __z, string __e) { return SR.T(__z, __e); },
                    delegate (string __s, string __z) { SR.LocSec(__s, __z); },
                    delegate (string __s, string __z, string __e) { SR.LocSec(__s, __z, __e); },
                    delegate (string __s, string __k, string __z, string __e) { SR.LocKey(__s, __k, __z, __e); },
                    delegate (string __s, string __k, string __z, string __e) { SR.LocDesc(__s, __k, __z, __e); },
                    delegate (string __n, string __z) { SR.LocEnum(__n, __z); },
                    delegate { return SR.CurrentLanguageId; },
                    delegate { return SR.LangVer; },
                    delegate (string __z, string __e, object[] __a) { SR.NotifyT(__z, __e, __a); });
            });
            SinkStep("Ctl", delegate () {
                SRApi.Ctl.SetSinks(
                    delegate (float __v) { return SR.Ctl.Sc(__v); },
                    delegate (GUIContent __c, ConfigEntryBase __e, float __w, float __h, ConfigEntry<KeyCode> __k) { SR.Ctl.RestoreLabel(__c, __e, __w, __h, __k); },
                    delegate (ConfigEntryBase __e) { SR.Ctl.RenderControl(__e); },
                    delegate (ConfigEntryBase __e, bool __i, float __c2) { SR.Ctl.RenderEntryRow(__e, __i, __c2); },
                    delegate (string __s, string __k) { return SR.Ctl.FindEntry(__s, __k); },
                    delegate (string __s) { return SR.Ctl.SectionEntries(__s); },
                    delegate (ConfigEntryBase __e, float __w) { SR.Ctl.DrawEntryRow(__e, __w); },
                    delegate (string __t2, float __w) { return SR.Ctl.TextHeight(__t2, __w); },
                    delegate (Rect __r, float __v, float __mn, float __mx, bool __i) { return SR.Ctl.DrawSlider(__r, __v, __mn, __mx, __i); },
                    delegate (ConfigEntryBase __e, string __cur, Array __vals, string[] __opts, ref bool __open, float __w) { return SR.Ctl.ComboBox(__e, __cur, __vals, __opts, ref __open, __w); },
                    delegate { return SR.Ctl.SidebarWidth(); },
                    delegate { return SR.Ctl.WinWidth; },
                    delegate (ConfigEntryBase __e, object __v) { SR.Ctl.SetValue(__e, __v); },
                    delegate (string __l, string __t2, ConfigEntry<KeyCode> __k, float __w, bool __b) { return SR.Ctl.HotkeyActionButton(__l, __t2, __k, __w, __b); },
                    delegate (string __id, string __l, string __t2, Action __a, float __w, float __h) { return SR.Ctl.HotkeyButton(__id, __l, __t2, __a, __w, __h); },
                    delegate (string __n) {
                        switch (__n) {
                            case "Label": return SR.Ctl.Label;
                            case "LabelWrap": return SR.Ctl.LabelWrap;
                            case "ChatLabel": return SR.Ctl.ChatLabel;
                            case "ChatArea": return SR.Ctl.ChatArea;
                            case "SecHeader": return SR.Ctl.SecHeader;
                            case "Btn": return SR.Ctl.Btn;
                            case "BtnClip": return SR.Ctl.BtnClip;
                            case "SearchBox": return SR.Ctl.SearchBox;
                            case "Footer": return SR.Ctl.Footer;
                        }
                        return null;
                    },
                    delegate { SR.Ctl.ScrollToBottom(); },
                    delegate { SR.Ctl.NoteEntryBound(); },
                    delegate (ConfigFile __c) { SR.Ctl.MarkConfigDirty(__c); },
                    delegate { return SR.Ctl.LangEn; },
                    delegate { return SR.Ctl.EditOpen; });
                
                SRApi.Ctl.SetCheckboxSink(delegate (Rect __r, bool __v, string __tip) { return SR.Ctl.CheckboxAt(__r, __v, __tip); });
            });
            SinkStep("Ui", delegate () {
                SRApi.SetUiSinks(
                    delegate { return SR.ContentArea; }, delegate (Rect __v) { SR.ContentArea = __v; },
                    delegate { return SR.FooterHeight; }, delegate (float __v) { SR.FooterHeight = __v; },
                    delegate { return SR.PageScroll; }, delegate (Vector2 __v) { SR.PageScroll = __v; },
                    delegate { return SR.NoPageScrollBars; }, delegate (bool __v) { SR.NoPageScrollBars = __v; },
                    delegate { return SR.CursorResize; }, delegate (bool __v) { SR.CursorResize = __v; },
                    delegate { return SR.CursorMove; }, delegate (bool __v) { SR.CursorMove = __v; },
                    delegate (Func<bool> __p) { SR.RegisterTypingProvider(__p); },
                    delegate (Func<bool> __h) { SR.RegisterInputGateHold(__h); },
                    delegate (Action<Camera> __a) { SR.RegisterCameraView(__a); },
                    delegate (string __s, Action __h, Action __f) { SR.RegisterPageChrome(__s, __h, __f); },
                    delegate (string __n, ConfigEntry<KeyCode> __e, string __m) { SR.RegisterKey(__n, __e, __m); },
                    delegate (ConfigEntry<KeyCode> __e) { return SR.ComboKeyDown(__e); },
                    delegate (ConfigEntry<KeyCode> __e) { return SR.ComboKeyHeld(__e); },
                    delegate (string __s, Func<ConfigEntryBase, bool> __f) { SR.RenderSectionEntries(__s, __f); },
                    delegate (string __s) { return SR.SectionEntries(__s); },
                    delegate { return SR.TableLineStrong; },
                    delegate (Rect __r, Color __c) { SR.DrawFill(__r, __c); });
            });
            SinkStep("Gate", delegate () {
                SRApi.SetGateSinks(
                    delegate (int __m) { return SR.GateModeAllows((SR.ModeMask)__m); },
                    delegate { return SR.Env.SceneName; },
                    delegate { return SR.Env.InTreehouse; });
            });
            SinkStep("ActionRow", delegate () {
                SR.Ctl.InstallActionRowSinks();
            });
            SinkStep("KeyActionGated", delegate () {
                SRApi.SetKeyActionGatedSink(delegate (string __kn, ConfigEntry<KeyCode> __ke, string __km, Action __ka, Type __ki) {
                    SR.RegisterKeyAction(__kn, __ke, __km, __ka, __ki);
                });
            });
            SinkStep("Active", delegate () {
                SRApi.SetActiveSink(delegate (Type __ai, BepInEx.Configuration.ConfigEntryBase __ao) {
                    return SR.FeatureActive(__ai, __ao);
                });
            });
            SinkStep("Patch", delegate () {
                SRApi.SetPatchSink(delegate (Type __pt) { SR.RegisterPatchType(__pt); });
                SRApi.SetPatchCountSink(delegate { return SR.PatchedCount; });
            });
            SinkStep("FloatWindow", delegate () {
                SRApi.SetUiVisibleSink(delegate { return SR.Visible; });
                SRApi.Ctl.SetFloatWindowSinks(
                    delegate { return SR.FloatWindow.IsOpen; },
                    delegate (string __ft, Vector2 __fs, SRApi.Ctl.FloatDrawFn __fd, Action __fc) {
                        SR.FloatWindow.Open(__ft, __fs, delegate { __fd(); }, __fc);
                    },
                    delegate { SR.FloatWindow.Close(); },
                    delegate { return SR.FloatWindow.Rect; });
            });
            SinkStep("UiFont", delegate () {
                SRApi.Ctl.SetUiFontSink(delegate { return SR.UiFont; });
            });
            SinkStep("ButtonRow", delegate () {
                SRApi.Ctl.SetButtonRowSink(delegate (string[] __l, float[] __w, float __h) { return SR.Ctl.ButtonRow(__l, __w, __h); });
            });
            SinkStep("Misc", delegate () {
                SRApi.SetMiscSinks(
                    delegate (ConfigEntryBase __e) { return (int)SR.KeyComboMod(__e); },
                    delegate (ConfigEntryBase __e, int __m) { SR.SetDefaultCombo(__e, (SR.ComboMod)__m); },
                    delegate (string __t, int __mx, GUIStyle __st, GUILayoutOption[] __o) {
                        return __mx < 0 ? SR.ClearableTextField(__t, __st, __o) : SR.ClearableTextField(__t, __mx, __st, __o);
                    },
                    delegate (string __s, Action __a) { SR.FeaturePageSimple(__s, __a.Invoke); },
                    delegate (string __s, string __p, string __zh, string __en, int __o, Action __a) { SR.FeaturePageFull(__s, __p, __zh, __en, __o, __a.Invoke); });
            });
            SinkStep("Table", delegate () {
                SRApi.SetTableSinks(
                    delegate (SRApi.TableArgs __a) { SR.TableDraw(__a); },
                    delegate (Event __e, ref float __w, ref bool __sb, ref int __mc, ref float __md, ref int __dc, ref bool __dh, Action __sw, Action __sh, Action __rj) { SR.TableDragWatchdog(__e, ref __w, ref __sb, ref __mc, ref __md, ref __dc, ref __dh, __sw, __sh, __rj); },
                    delegate (Event __e, Rect __box, Vector2 __mp, float __mx, float __my, ref Vector2 __sc, ref Vector2 __sr) { return SR.TableWheelInput(__e, __box, __mp, __mx, __my, ref __sc, ref __sr); },
                    delegate (Event __e, Vector2 __mp, Rect __tr, Rect __th, float __sm, ref bool __dr, ref float __gy, ref float __sy) { return SR.TableScrollbarInput(__e, __mp, __tr, __th, __sm, ref __dr, ref __gy, ref __sy); });
            });
            SinkStep("Migration", delegate () {
                SRApi.Migration.SetSinks(
                    delegate (string __s, string[] __k) { ConfigMigration.Remove(__s, __k); },
                    delegate (string __f, string __t3, string __k) { ConfigMigration.Move(__f, __t3, __k); });
            });
            SinkStep("Ex", delegate () {
                SRApi.SetExSinks(
                    delegate { return SR.AllEnabled; },
                    delegate (bool __v) { SR.AllEnabled = __v; },
                    delegate { return SR.IgnoreModeLimit; },
                    delegate (string __s) { return SR.HasPage(__s); },
                    delegate (string __t4, string __x) { SR.NotifyTag(__t4, __x); },
                    delegate (string __t4, object[] __a) { return SR.Cat(__t4, __a); },
                    delegate (string __n) { return SR.EnumNameZh(__n); },
                    delegate { return SR.ControlHeight; },
                    delegate (float __v) { SR.ControlHeight = __v; },
                    delegate (Func<bool> __f) { SR.RegisterModeOverride(__f); },
                    delegate (Func<bool> __f) { SR.RegisterHostOverride(__f); },
                    delegate (Func<bool> __f) { SR.RegisterPauseProvider(__f); },
                    delegate (string __s, Action __d) { SR.RegisterTabPrefix(__s, __d); });
            });
                // API 通道自检：漏注入会让功能静默失效，必须报错。
                string[] __miss = SRApi.MissingSinks();
                List<string> __lateInjected = new List<string> {
                    "SRApi._wheelLayer", "SRApi._wheelTake", "SRApi._overlay", "SRApi._rounded", "SRApi._typing",
                    "Ctl._labeledRow", "Ctl._rowCombo", "Ctl._rowSlider", "Ctl._button", "Ctl._labelCol",
                    "Ctl._wheelFb", "Ctl._fillScroll", "Ctl._tableHighlight"
                };
                List<string> __real = new List<string>();
                for (int __i = 0; __i < __miss.Length; __i++) if (!__lateInjected.Contains(__miss[__i])) __real.Add(__miss[__i]);
                if (__real.Count > 0) ModLogger.LogError("[SR.Api] 未注入的 API 通道 (" + __real.Count + "): " + string.Join(", ", __real.ToArray()));
            if (ApiSinkFailures.Count > 0) ModLogger.LogError("[SR.Api] sink 注入失败的分组 (" + ApiSinkFailures.Count + "): " + string.Join(", ", ApiSinkFailures.ToArray()));
        }

        // 注入失败的分组名：一组失败不影响其它组。
        internal static readonly List<string> ApiSinkFailures = new List<string>();

        // 逐分组注入：一组抛异常只记录并继续。
        private static void SinkStep(string what, Action inject) {
            try { inject(); }
            catch (Exception __sx) {
                ApiSinkFailures.Add(what);
                try { SR.LogError("[SR.Api] sink 注入失败 " + what + ": " + __sx.Message); }
                catch { /* 静默：日志通道可能尚未就绪，失败可直接忽略 */ }
            }
        }


        // 功能 Id：优先 [SrFeature].Id，否则用类型全名。
        private static string FeatureIdOf(Type t) {
            FeatureInfo fi = Features.FromType(t);
            return fi != null && !fi.ManifestMissing ? fi.Id : t.FullName;
        }

        // 补扫用：只取名字以 SR_UCH 开头的程序集。
        private static Assembly[] PickUchAssemblies() {
            try {
                List<Assembly> keep = new List<Assembly>();
                Assembly[] all = AppDomain.CurrentDomain.GetAssemblies();
                for (int i = 0; i < all.Length; i++) {
                    try {
                        string n = all[i].GetName().Name ?? "";
                        if (n.StartsWith("SR_UCH", StringComparison.OrdinalIgnoreCase)) keep.Add(all[i]);
                    } catch { /* 静默：取不到名字的程序集跳过 */ }
                }
                return keep.ToArray();
            } catch (Exception __ex) { SR.LogWarn("枚举程序集失败: " + __ex.Message); return new Assembly[0]; }
        }

        // latePass = true 表示装配完成后补扫。幂等由 FeatureRuntime 保证，三条装载路径共用。
        // 注意：SR 必须最先 Initialize（旧 cfg 迁移要早于任何功能 Bind）。
        private void InitializeTweaks(bool latePass = false) {
            List<Type> __tweaks = new List<Type>();
            // 补扫只覆盖 SR_UCH* 程序集：扫全部 AppDomain 会白花上百毫秒。
            Assembly[] __asms = latePass ? PickUchAssemblies() : new Assembly[] { Assembly.GetExecutingAssembly() };
            for (int __ai = 0; __ai < __asms.Length; __ai++) {
                foreach (Type __t in GetTypesSafe(__asms[__ai])) {
                    if (!typeof(ITweak).IsAssignableFrom(__t) || __t.IsInterface || __t.IsAbstract) continue;
                    __tweaks.Add(__t);
                }
            }
            __tweaks.Sort(delegate(Type a, Type b) {
                int ra = a == typeof(SR_UCH.Tweaks.SR) ? 0 : 1;
                int rb = b == typeof(SR_UCH.Tweaks.SR) ? 0 : 1;
                if (ra != rb) return ra - rb;
                return string.Compare(a.FullName, b.FullName, StringComparison.Ordinal);
            });
            foreach (Type type in __tweaks) {
                try {
                    string id = FeatureIdOf(type);
                    bool ran = FeatureRuntime.TryInit(type, id, delegate {
                        var tweak = (ITweak)Activator.CreateInstance(type);
                        FeatureRuntime.SetInstance(tweak);
                        tweak.Initialize(this);
                    });
                    if (!ran) continue;
                } catch (Exception e) {
                    ModLogger.LogError("Failed to initialize " + type.Name + ": " + e);
                }
            }
        }

        // 功能清单登记 + 启动自检 + 自检日志。
        private void RebuildFeatureManifest() {
            // 功能清单：全部 ITweak 就位后统一登记，校验依赖与契约版本。
            try { Features.Rebuild(); if (Features.ProblemCount > 0) ModLogger.LogInfo(Features.Describe()); } catch (Exception __ft) { try { ModLogger.LogWarning("[SR.Feat] 功能清单登记失败: " + __ft.Message); } catch { /* 静默：非关键路径，失败可直接忽略 */ } }
            // 启动自检必须晚于全部功能与 EX 挂完。
            try { SR.RunStartupAudit(); } catch (Exception __ex) { try { ModLogger.LogWarning("[SR] 启动自检失败: " + __ex.Message); } catch { /* 静默：非关键路径，失败可直接忽略 */ } }
            // 补丁归因：推迟 3 秒，等其它插件打完补丁。
            try { SR.InitAttribution(); } catch (Exception __at) { try { ModLogger.LogWarning("[SR] 补丁归因初始化失败: " + __at.Message); } catch { /* 静默：非关键路径，失败可直接忽略 */ } }
            // 诊断浮层 + 冒烟测试标记（单行、固定格式、可被脚本 grep）。
            try {
                try { ModLogger.LogInfo("[SR] 游戏版本=" + UnityEngine.Application.version + " | 契约=v" + SRContract.Version); } catch { /* 静默：非关键路径，失败可直接忽略 */ }
                string[] __miss = SRApi.MissingSinks();
                int __bad = ApiSinkFailures.Count;
                string __gv = "?";
                try { __gv = UnityEngine.Application.version; } catch { /* 静默：非关键路径，失败可直接忽略 */ }
                // 自检行由健康快照生成：与诊断报告 / 支持包 / CI 基线共用同一份数据。
                HealthSnapshot __snap = Health.Capture(__gv);
                if (__miss.Length == 0 && __bad == 0 && Features.ProblemCount == 0)
                    ModLogger.LogInfo(__snap.ToSelfTestLine("OK"));
                else
                    ModLogger.LogError(__snap.ToSelfTestLine("FAIL") + " API通道缺失=" + __miss.Length + " 注入失败=" + __bad + " 功能表问题=" + Features.ProblemCount + " 缺失=" + string.Join(",", __miss) + (__bad > 0 ? " 失败分组=" + string.Join(",", ApiSinkFailures.ToArray()) : ""));
            } catch (Exception __st) { try { ModLogger.LogError("[SR.SelfTest] FAIL 自检异常: " + __st.Message); } catch { /* 静默：非关键路径，失败可直接忽略 */ } }
        }


        // 外部 DLL 实现 ITweak 或 ILanguagePack，只需引用 SR_UCH.dll。
        private void LoadExternal() {
            // 第三方 dll 进受信任目录即会被执行，故把加载来源与大小写进日志。
            string[] dirs = null;
            try {
                dirs = new[] { Paths.PluginPath, Path.Combine(Paths.BepInExRootPath, "modules") };
            } catch (Exception e) { ModLogger.LogWarning("[SR] 定位插件目录失败: " + e.Message); return; }
            try {
                foreach (string dir in dirs) {
                    if (string.IsNullOrEmpty(dir) || !Directory.Exists(dir)) continue;
                    string[] files;
                    try { files = Directory.GetFiles(dir, "*.dll"); } catch { continue; }
                    for (int i = 0; i < files.Length; i++) LoadOneExternal(files[i]);
                }
            } catch (Exception e) {
                ModLogger.LogError("[SR] 外部 DLL 扫描失败: " + e);
            }
        }

        // 外部模块一行摘要；永不抛异常。
        private void TryLogExternalModule(string dll, string name, bool loadedNow) {
            try {
                long size = -1; DateTime when = DateTime.MinValue;
                try { FileInfo fi = new FileInfo(dll); if (fi.Exists) { size = fi.Length; when = fi.LastWriteTime; } } catch { /* 静默：取不到元数据就只记路径 */ }
                ModLogger.LogInfo("[SR.Mod] 外部模块 " + name + (loadedNow ? "（本次加载）" : "（已在内存中）")
                    + " | 文件=" + dll + (size >= 0 ? " | 字节=" + size : "") + (when != DateTime.MinValue ? " | 修改=" + when.ToString("yyyy-MM-dd HH:mm") : ""));
            } catch { /* 静默：日志失败不影响加载流程 */ }
        }

        private void LoadOneExternal(string dll) {
            try {
                string name = Path.GetFileNameWithoutExtension(dll);
                
                if (name == "SR_UCH") return;
                // 已加载过则复用同一份程序集：LoadFile 会复制副本，Type 不再相同。
                Assembly asm = null;
                foreach (Assembly a in AppDomain.CurrentDomain.GetAssemblies()) {
                    try {
                        if (a.IsDynamic) continue;
                        string an = Path.GetFileNameWithoutExtension(a.Location);
                        if (string.Equals(an, name, StringComparison.OrdinalIgnoreCase)) { asm = a; break; }
                    } catch { /* 静默：非关键路径，失败可直接忽略 */ }
                }
                bool loadedNow = false;
                if (asm == null) { asm = Assembly.LoadFrom(dll); loadedNow = true; }
                if (asm == null) return;
                
                TryLogExternalModule(dll, name, loadedNow);

                // 同一份程序集只处理一次，否则 Initialize 与补丁都会跑两遍。
                string key = null;
                try { key = asm.FullName; } catch { /* 静默：非关键路径，失败可直接忽略 */ }
                if (string.IsNullOrEmpty(key)) key = dll;
                if (!_extSeen.Add(key)) return;

                Type[] types = GetTypesSafe(asm);
                // 按特性类型名判断，不写 typeof(BepInPluginAttribute)；特性打在类上须遍历类型。
                bool isBepInPlugin = false;
                for (int ti = 0; ti < types.Length && !isBepInPlugin; ti++) {
                    Type tCheck = types[ti];
                    if (tCheck == null) continue;
                    try {
                        object[] attrs = tCheck.GetCustomAttributes(false);
                        for (int ai = 0; ai < attrs.Length; ai++) {
                            if (attrs[ai] != null && attrs[ai].GetType().Name == "BepInPluginAttribute") { isBepInPlugin = true; break; }
                        }
                    } catch { /* 静默：非关键路径，失败可直接忽略 */ }
                }
                // 通用模块入口：不带 [BepInPlugin] 的 DLL 若有 public static Init(插件) 就调用一次。
                if (!isBepInPlugin) TryInvokeModuleEntry(types, name);
                for (int i = 0; i < types.Length; i++) {
                    Type t = types[i];
                    if (t == null || t.IsInterface || t.IsAbstract) continue;
                    try {
                        // 语言包：任何 DLL 形态都收
                        if (typeof(ILanguagePack).IsAssignableFrom(t)) {
                            var pack = (ILanguagePack)Activator.CreateInstance(t);
                            SR.RegisterLanguage(pack);
                            continue;
                        }
                        // 功能：只收没有 BepInPlugin 入口的 DLL。
                        if (isBepInPlugin) continue;
                        if (!typeof(ITweak).IsAssignableFrom(t)) continue;
                        // 要求的最低契约版本高于核心时拒绝加载。
                        FeatureInfo __fi = Features.FromType(t);
                        if (__fi != null && __fi.MinContract > SRContract.Version) {
                            ModLogger.LogError("[SR.Feat] 拒绝加载 " + __fi.Id + "：" + __fi.ToString());
                            continue;
                        }
                        var tweak = (ITweak)Activator.CreateInstance(t);
                        string fid = __fi != null ? __fi.Id : t.FullName;
                        bool ran = FeatureRuntime.TryInit(t, fid, delegate {
                            FeatureRuntime.SetInstance(tweak);
                            tweak.Initialize(this);
                        });
                        if (!ran) continue;
                        ModLogger.LogInfo("[SR] 已加载外部功能: " + t.Name + " (" + name + ".dll)");
                    } catch (Exception e) {
                        ModLogger.LogError("[SR] 外部 DLL 初始化失败 " + name + "/" + t.Name + ": " + e.Message);
                    }
                }
            } catch (Exception e) {
                
                ModLogger.LogWarning("[SR] 跳过外部 DLL " + Path.GetFileName(dll) + ": " + e.Message);
            }
        }

        // 通用外部模块入口：找 public static Init(本插件类型) 并调用一次。
        private void TryInvokeModuleEntry(Type[] types, string file) {
            try {
                for (int i = 0; i < types.Length; i++) {
                    Type t = types[i];
                    if (t == null) continue;
                    MethodInfo hit = null;
                    MethodInfo[] ms = t.GetMethods(BindingFlags.Public | BindingFlags.Static);
                    for (int k = 0; k < ms.Length; k++) {
                        if (ms[k].Name != "Init") continue;
                        ParameterInfo[] ps = ms[k].GetParameters();
                        if (ps.Length != 1) continue;
                        if (!ps[0].ParameterType.IsAssignableFrom(GetType())) continue;
                        hit = ms[k];
                        break;
                    }
                    if (hit == null) continue;
                    object r = hit.Invoke(null, new object[] { this });
                    bool ok = !(r is bool) || (bool)r;
                    if (ok) ModLogger.LogInfo("[SR] 外部模块入口已调用: " + file + " -> " + t.FullName + ".Init");
                    else ModLogger.LogWarning("[SR] 外部模块入口返回失败: " + file + " -> " + t.FullName + ".Init");
                    return;
                }
            } catch (Exception e) { ModLogger.LogError("[SR] 外部模块入口调用失败 " + file + ": " + e.Message); }
        }

        // GetTypes 遇缺失类型会抛异常：只取成功加载的类型。
        private static Type[] GetTypesSafe(Assembly asm) {
            try { return asm.GetTypes(); } catch (ReflectionTypeLoadException ex) {
                List<Type> ok = new List<Type>();
                Type[] ts = ex.Types;
                if (ts != null) {
                    for (int i = 0; i < ts.Length; i++) if (ts[i] != null) ok.Add(ts[i]);
                }
                return ok.ToArray();
            } catch { return new Type[0]; }
        }

    }
        // 只针对本插件：Bind 落到 SR_UCH_data.cfg。
        [HarmonyLib.HarmonyPatch(typeof(BepInEx.BaseUnityPlugin), "get_Config")]
        internal static class PatchOwnConfigFile {
            [HarmonyLib.HarmonyPrefix]
            private static bool Prefix(BepInEx.BaseUnityPlugin __instance, ref BepInEx.Configuration.ConfigFile __result) {
                try {
                    if (!(__instance is MainPlugin)) return true;
                    if (MainPlugin.Data == null) return true;
                    __result = MainPlugin.Data;
                    return false;
                } catch { return true; }
            }
        }

}
