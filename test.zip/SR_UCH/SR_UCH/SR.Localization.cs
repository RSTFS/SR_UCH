// 本地化：T() 查表入口、注册表、内置中英文词条、外部语言包，以及键名 / 关卡名 / 枚举名翻译。
using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Text;
using BepInEx;
using BepInEx.Bootstrap;
using BepInEx.Configuration;
using UnityEngine;
using UnityEngine.SceneManagement;

namespace SR_UCH.Tweaks {
public partial class SR {

// 分区：Localization（T() 入口 / 注册表 / 查表回退 / 键名·关卡名·枚举名）

        private static readonly Dictionary<string, string> _sectionZh = new Dictionary<string, string>();

        private static readonly Dictionary<string, string> _keyZh = new Dictionary<string, string>();

        // 界面文案自注册入口：LocSec / LocKey / LocDesc。
        public static void LocSec(string sec, string zh, string en = null) {
            if (sec == null) return;
            if (zh != null) _sectionZh[sec] = zh;
            if (en != null) _sectionEn[sec] = en;
        }

        public static void LocKey(string sec, string key, string zh, string en) {
            if (sec == null || key == null) return;
            string k = sec + "\t" + key;
            bool changed = false;
            string old;
            if (zh != null && (!_keyZh.TryGetValue(k, out old) || old != zh)) { _keyZh[k] = zh; changed = true; }
            if (en != null && (!_keyEn.TryGetValue(k, out old) || old != en)) { _keyEn[k] = en; changed = true; }
            if (changed) _nameCacheVer = -1; //名字缓存整体失效
        }

        public static void LocDesc(string sec, string key, string zh, string en) {
            if (sec == null || key == null) return;
            string k = sec + "\t" + key;
            bool changed = false;
            string old;
            if (zh != null && (!_descZh.TryGetValue(k, out old) || old != zh)) { _descZh[k] = zh; changed = true; }
            if (en != null && (!_descEn.TryGetValue(k, out old) || old != en)) { _descEn[k] = en; changed = true; }
            if (changed) _nameCacheVer = -1; //说明缓存整体失效
        }

        // 登记枚举成员中文名；英文模式仍显示原名。
        public static void LocEnum(string name, string zh) {
            if (string.IsNullOrEmpty(name) || zh == null) return;
            _enumZh[name] = zh;
        }

        private static string ZhSection(string sec) {
            string zh, en;
            _sectionZh.TryGetValue(sec, out zh);
            _sectionEn.TryGetValue(sec, out en);
            string ov = Pack(zh, en ?? sec);   //外部语言包覆盖
            if (ov != null) return ov;
            return UseEn ? (en ?? sec) : (zh ?? en ?? sec);
        }

        private static readonly Dictionary<string, string> _sectionEn = new Dictionary<string, string>();

        // 显示名 / 说明缓存：语言、条目版本或注册变化时整体失效。
        private static readonly Dictionary<ConfigEntryBase, string> _keyNameCache = new Dictionary<ConfigEntryBase, string>();
        private static readonly Dictionary<ConfigEntryBase, string> _descTextCache = new Dictionary<ConfigEntryBase, string>();
        private static readonly Dictionary<ConfigEntryBase, string> _defSuffix = new Dictionary<ConfigEntryBase, string>();
        private static readonly Dictionary<ConfigEntryBase, string> _rowTipCache = new Dictionary<ConfigEntryBase, string>();
        private static int _nameCacheLangVer = -1;   //缓存对应的语言版本
        private static int _nameCacheVer = -1;

        // LocDynamic：显示名随游戏语言变化时节流重注册；每帧可能被调用，只比语言版本与引用。
        private struct DynName { public string Zh, En; public int Lang; }
        private static readonly Dictionary<ConfigEntryBase, DynName> _dynNames = new Dictionary<ConfigEntryBase, DynName>();
        internal static void LocDynamic(ConfigEntryBase e, string zh, string en) {
            try {
                if (e == null) return;
                zh = zh ?? ""; en = en ?? "";
                DynName old;
                if (_dynNames.TryGetValue(e, out old) && old.Lang == _langVer
                    && string.Equals(old.Zh, zh) && string.Equals(old.En, en)) return;
                _dynNames[e] = new DynName { Zh = zh, En = en, Lang = _langVer };
                LocKey(e.Definition.Section, e.Definition.Key, zh, en);
            } catch (Exception __ld) { Guard.Log("动态条目名", __ld); }
        }

        private static bool NameCacheSync() {
            bool en = UseEn;
            if (_nameCacheLangVer != _langVer || _nameCacheVer != EntryVersion) {
                _nameCacheLangVer = _langVer;
                _nameCacheVer = EntryVersion;
                _keyNameCache.Clear();
                _descTextCache.Clear();
                _defSuffix.Clear();
                _rowTipCache.Clear();
            }
            return en;
        }

        private static string ZhKey(ConfigEntryBase e) {
            bool en = NameCacheSync();
            string cached;
            if (_keyNameCache.TryGetValue(e, out cached)) return cached;
            string key = e.Definition.Section + "\t" + e.Definition.Key;
            string zh, enName;
            _keyZh.TryGetValue(key, out zh);
            _keyEn.TryGetValue(key, out enName);
            string ov = Pack(zh, enName ?? e.Definition.Key);   //外部语言包覆盖
            if (ov != null) { _keyNameCache[e] = ov; return ov; }
            string v = en ? (enName ?? e.Definition.Key) : (zh ?? enName ?? e.Definition.Key);
            _keyNameCache[e] = v;
            return v;
        }

        private static readonly Dictionary<string, string> _keyEn = new Dictionary<string, string>();

        // 中文悬浮说明（null = 无说明）。
        private static readonly Dictionary<string, string> _descZh = new Dictionary<string, string>();

        private static readonly Dictionary<string, string> _descEn = new Dictionary<string, string>();

        private static string ZhDesc(ConfigEntryBase e) {
            bool en = NameCacheSync();
            string cached;
            if (_descTextCache.TryGetValue(e, out cached)) return cached;
            string key = e.Definition.Section + "\t" + e.Definition.Key;
            string zh, enDesc;
            _descZh.TryGetValue(key, out zh);
            _descEn.TryGetValue(key, out enDesc);
            string ov = Pack(zh, enDesc);   //外部语言包覆盖（zh/enDesc 可能为 null）
            if (ov != null) { _descTextCache[e] = ov; return ov; }
            string v = en ? (enDesc ?? zh ?? null) : (zh ?? enDesc ?? null);
            _descTextCache[e] = v;
            return v;
        }

        // 默认值后缀（"默认：X"），按 entry 缓存并经 T() 生成以便翻译；无默认值返回 ""。
        internal static string DefaultSuffix(ConfigEntryBase entry) {
            NameCacheSync();
            string cached;
            if (_defSuffix.TryGetValue(entry, out cached)) return cached;
            string dft = FormatDefaultValue(entry);
            cached = string.IsNullOrEmpty(dft) ? "" : T("默认：" + dft, "Default: " + dft);
            _defSuffix[entry] = cached;
            return cached;
        }


        // 名称列悬浮说明 = 说明本身（3 行）+ 核心追加的第 4 行。
        internal static string RowTip(ConfigEntryBase entry, string desc) {
            NameCacheSync();
            string cached;
            if (_rowTipCache.TryGetValue(entry, out cached)) return cached;
            string tip = ComposeTip(entry, desc, null);
            _rowTipCache[entry] = tip;
            return tip;
        }

        // ================= 悬浮条目：按语义组装（行号随参数变化） =================
        // 段落：是什么 / 做什么 / 注意（LocDesc 第 3 行起）/ 默认（由类型决定）/ 按键（仅绑定时）。
        internal static string ComposeTip(ConfigEntryBase entry, string desc, ConfigEntry<KeyCode> hk) {
            StringBuilder sb = new StringBuilder(180);
            string body = NormalizeTip(desc);
            try {
                if (!string.IsNullOrEmpty(body)) {
                    string[] bl = body.Split('\n');
                    // 第 3 行起全是"注意"：逐行加不可见标记，绘制时染醒目色。
                    for (int i = 2; i < bl.Length; i++) {
                        if (!bl[i].StartsWith("\u0002")) bl[i] = "\u0002" + bl[i];
                    }
                    body = string.Join("\n", bl);
                }
            } catch (Exception __nt) { Guard.Log("悬浮条目/注意标记", __nt); }
            if (body.Length > 0) sb.Append(body);
            if (entry != null) {
                string dft = DefaultSuffix(entry);
                if (!string.IsNullOrEmpty(dft)) { if (sb.Length > 0) sb.Append('\n'); sb.Append(dft); }
            }
            ConfigEntry<KeyCode> keyEntry = hk;
            if (keyEntry == null && entry is ConfigEntry<KeyCode>) keyEntry = (ConfigEntry<KeyCode>)entry;
            if (keyEntry != null) { if (sb.Length > 0) sb.Append('\n'); sb.Append(KeyTipLine(keyEntry)); }
            return sb.ToString();
        }

        internal static string NormalizeTip(string s) {
            if (string.IsNullOrEmpty(s)) return "";
            string[] lines = s.Replace("\r\n", "\n").Replace('\r', '\n').Split('\n');
            List<string> keep = new List<string>(lines.Length);
            for (int i = 0; i < lines.Length; i++) {
                string l = lines[i] != null ? lines[i].TrimEnd() : "";
                bool blank = l.Trim().Length == 0;
                if (blank && (keep.Count == 0 || keep[keep.Count - 1].Trim().Length == 0)) continue;  // 首行/连续空行丢弃
                keep.Add(l);
            }
            while (keep.Count > 0 && keep[keep.Count - 1].Trim().Length == 0) keep.RemoveAt(keep.Count - 1);
            return string.Join("\n", keep.ToArray());
        }

        // 按键行：未绑定时给"右键设置 / 删除"指引。
        internal static string KeyTipLine(ConfigEntry<KeyCode> hk) {
            if (hk == null) return "";
            KeyCode v = KeyCode.None;
            try { v = hk.Value; } catch (Exception __ex) { Guard.Log("按键提示行", __ex); return ""; }
            if (v == KeyCode.None) return Tid("9e9176d4aa", "按键：右键设置/删除快捷键", "Key: right-click to set/remove");
            return T("按键：" + ComboKeyDisplay(hk, v), "Key: " + ComboKeyDisplay(hk, v));
        }

        public static string KeyDisplayName(KeyCode k) {
            string en = k.ToString();
            string zh = KeyZh(k);
            string ov = Pack(zh, en);   //外部语言包覆盖
            if (ov != null) return ov;
            return en;   // 一律显示原始 KeyCode 名（Delete / Backspace / LeftAlt），不做中文翻译
        }

        private static string KeyZh(KeyCode k) {
            switch (k) {
                case KeyCode.None: return "未设置";
                case KeyCode.LeftAlt: return "左Alt";
                case KeyCode.RightAlt: return "右Alt";
                case KeyCode.LeftControl: return "左Ctrl";
                case KeyCode.RightControl: return "右Ctrl";
                case KeyCode.LeftShift: return "左Shift";
                case KeyCode.RightShift: return "右Shift";
                case KeyCode.Return: return "回车";
                case KeyCode.Escape: return "Esc";
                case KeyCode.Backspace: return "退格";
                case KeyCode.Delete: return "删除";
                case KeyCode.Space: return "空格";
                case KeyCode.UpArrow: return "上方向";
                case KeyCode.DownArrow: return "下方向";
                case KeyCode.LeftArrow: return "左方向";
                case KeyCode.RightArrow: return "右方向";
                case KeyCode.Mouse0: return "鼠标左键";
                case KeyCode.Mouse1: return "鼠标右键";
                case KeyCode.Mouse2: return "鼠标中键";
                case KeyCode.Mouse3: return "鼠标键4";
                case KeyCode.Mouse4: return "鼠标侧键1";
                case KeyCode.Mouse5: return "鼠标侧键2";
                case KeyCode.Mouse6: return "鼠标键7";
                default:
                    return null;
            }
        }

        public static string MapNameZh(string scene) {
            string zh = MapZh(scene);
            string ov = Pack(zh, scene);   //外部语言包覆盖
            if (ov != null) return ov;
            return UseEn ? scene : (zh ?? scene);
        }

        // 场景名转中文关卡名：查 _enumZh（大写匹配），其次树屋 / 大厅。
        private static string MapZh(string scene) {
            if (string.IsNullOrEmpty(scene)) return null;
            string zh;
            if (_enumZh.TryGetValue(scene.ToUpperInvariant(), out zh)) return zh;
            if (scene == "Treehouse") return "树屋";
            if (scene == "Lobby") return "大厅";
            return null;
        }

        // 页脚状态：当前模式 · 当前关卡；每帧全量算太重，故按 (场景, 模式, 快照名, 语言) 记忆化。
        private static string _modeLabelKey;
        private static string _modeLabelVal;
        private static string ModeLabel() {
            string key = null;
            try {
                string sc = "";
                try { sc = SceneManager.GetActiveScene().name; } catch (Exception __sc) { Guard.Log("ModeLabel 场景名(缓存键)", __sc); }
                string snap = "";
                try {
                    LevelSelectController.PlayedSnapshotInfo info = GameState.GetInstance().currentSnapshotInfo;
                    if (!string.IsNullOrEmpty(info.snapshotName)) snap = info.snapshotName;
                } catch (Exception __si) { Guard.Log("ModeLabel 快照名(缓存键)", __si); }
                // 模式读不到时不要把假值写进缓存键，否则缓存每帧不命中、文本反复闪烁。
                GameState.GameMode gmKey = GameState.GameMode.CREATIVE;
                bool __gmOk = false;
                try { gmKey = GameSettings.GetInstance().GameMode; __gmOk = true; }
                catch (Exception __gk) { Guard.Log("ModeLabel 模式(缓存键)", __gk); }
                if (!__gmOk) { key = null; return ModeLabelRaw(); }
                key = sc + "|" + (int)gmKey + "|" + snap + "|" + LangVer + "|" + (_forceZh ? 1 : 0) + "|" + (UseEn ? 1 : 0);
                if (key == _modeLabelKey && _modeLabelVal != null) return _modeLabelVal;
            } catch { LogWarn("ModeLabel 缓存键失败，退回直算"); }
            string computed = ModeLabelRaw();
            if (!string.IsNullOrEmpty(key)) { _modeLabelKey = key; _modeLabelVal = computed; }
            return computed;
        }

        private static string ModeLabelRaw() {
            string mode = Tid("5e1302f90c", "未知", "Unknown");
            try {
                GameState.GameMode gm = GameSettings.GetInstance().GameMode;
                string term = null;
                if (gm == GameState.GameMode.FREEPLAY) term = "RuleBook/FreePlayText";
                else if (gm == GameState.GameMode.CHALLENGE) term = "RuleBook/ChallengeModeText";
                else if (gm == GameState.GameMode.PARTY) term = "RuleBook/PartyModeText";
                else if (gm == GameState.GameMode.CREATIVE) term = "RuleBook/CreativeModeText";
                bool got = false;
                if (!string.IsNullOrEmpty(term)) {
                    try {
                        string loc = I2.Loc.LocalizationManager.GetTranslation(term);
                        if (!string.IsNullOrEmpty(loc) && loc.IndexOf('/') < 0) { mode = loc; got = true; }
                    } catch (Exception __gx) { Guard.Log("ModeLabel 模式本地化", __gx); }
                }
                if (!got) mode = gm.ToString();
            } catch (Exception __ex) { Guard.Log("ModeLabel", __ex); }
            string scene = "";
            try { scene = SceneManager.GetActiveScene().name; } catch (Exception __ex) { Guard.Log("ModeLabel 场景名", __ex); }
            string level = null;
            try {
                if (scene == "Treehouse") level = Tid("3f7114bae0", "树屋", "Treehouse");
                else if (scene == "Lobby") level = Tid("5ffed55f6c", "大厅", "Lobby");
                else if (scene == "BlankLevel") {
                    LevelSelectController.PlayedSnapshotInfo info = GameState.GetInstance().currentSnapshotInfo;
                    level = !string.IsNullOrEmpty(info.snapshotName) ? info.snapshotName : Tid("756f1de77d", "自定义关卡", "Custom level");
                } else if (!string.IsNullOrEmpty(scene)) {
                    foreach (GameState.LevelName lv in Enum.GetValues(typeof(GameState.LevelName))) {
                        if (GameState.GetLevelSceneName(lv) == scene) { level = GameState.GetLevelLocalizedName(lv); break; }
                    }
                }
            } catch (Exception __lx) { Guard.Log("ModeLabel 关卡本地化", __lx); }
            if (string.IsNullOrEmpty(level)) level = MapNameZh(scene);
            return mode + "·" + level;
        }

        private static bool _langEn = true; //默认英文
        private static bool _forceZh = false;
        private static ConfigEntry<string> _langEntry;

        // 语言标识：内置中文 / English，语言包用自己的 Id；文案先查语言包，未收录按 FallbackId 回退。
        public const string LangZh = "中文";
        
        public const string LangEn = "English";
        private static readonly Dictionary<string, ILanguagePack> _packs = new Dictionary<string, ILanguagePack>();
        private static ILanguagePack _pack;      //当前生效的外部语言包（内置中/英时为 null）
        private static bool _fallbackEn;         //外部语言未收录时回退英文（否则回退中文）
        private static string _langId = LangEn;
        private static int _langVer = 0;         //语言版本号：变化时显示名缓存整体失效

        public static void LanguageOptions(out string[] ids, out string[] names) {
            List<string> lIds = new List<string>();
            List<string> lNames = new List<string>();
            lIds.Add(LangZh); lNames.Add(LangZh);
            lIds.Add(LangEn); lNames.Add(LangEn);
            foreach (KeyValuePair<string, ILanguagePack> kv in _packs) {
                string nm = null;
                try { nm = kv.Value.DisplayName; } catch (Exception __ex) { Guard.Log("LanguageOptions", __ex); }
                lIds.Add(kv.Key);
                lNames.Add(string.IsNullOrEmpty(nm) ? kv.Key : nm);
            }
            ids = lIds.ToArray();
            names = lNames.ToArray();
        }

        // 注册外部语言包；id 重复则覆盖，与内置重名则忽略。
        public static void RegisterLanguage(ILanguagePack pack) {
            if (pack == null) return;
            string id;
            try { id = pack.Id; } catch { return; }
            if (string.IsNullOrEmpty(id)) return;
            if (id == LangZh || id == LangEn) {
                if (MainPlugin.ModLogger != null) SR.LogWarn("[SR] 语言包 id 与内置语言冲突，已忽略: " + id);
                return;
            }
            _packs[id] = pack;
            ApplyLanguage();   //cfg 里可能已经选了这门语言（上次装过 / 注册晚于 Bind）
            string nm = id;
            try { if (!string.IsNullOrEmpty(pack.DisplayName)) nm = pack.DisplayName; } catch (Exception __ex) { Guard.Log("RegisterLanguage", __ex); }
            if (MainPlugin.ModLogger != null) SR.LogInfo("[SR] 已注册语言包: " + nm + " (" + id + ")");
        }

        // 按 cfg 的语言 id 重新解析当前语言；语言包被删后回退内置英文。
        public static void ApplyLanguage() {
            string id = null;
            try { if (_langEntry != null) id = _langEntry.Value; } catch (Exception __ex) { Guard.Log("ApplyLanguage", __ex); }
            if (string.IsNullOrEmpty(id)) id = LangEn;
            ILanguagePack p;
            if (_packs.TryGetValue(id, out p)) {
                _pack = p;
                _langId = id;
                _langEn = false;                 //非内置英文
                bool fbZh = false;
                try { fbZh = string.Equals(p.FallbackId, LangZh, StringComparison.Ordinal); } catch (Exception __ex) { Guard.Log("ApplyLanguage", __ex); }
                _fallbackEn = !fbZh;
            } else {
                _pack = null;
                if (string.Equals(id, LangZh, StringComparison.Ordinal)) {
                    _langId = LangZh; _langEn = false; _fallbackEn = false;
                } else {
                    _langId = LangEn; _langEn = true; _fallbackEn = true;
                }
            }
            _langVer++;
        }

        // 当前语言 id，供功能做按语言的缓存失效。
        public static string CurrentLanguageId { get { return _langId; } }

        // 语言版本号：切语言或注册语言包时 +1；按语言缓存处须比较本值。
        public static int LangVer { get { return _langVer; } }

        private static bool UseEn {
            get { return (_langEn || _fallbackEn) && !_forceZh; }
        }

        // 动态文案的原文覆盖：按中文/英文原文查；静态词条一律走 Tid 的 @id 索引。
        private static IDictionary<string, string> _packMap;
        private static int _packMapVer = -1;

        private static string Pack(string zh, string en) {
            if (_pack == null || _forceZh) return null;
            if (_packMapVer != _langVer) {
                _packMapVer = _langVer;
                try { _packMap = _pack.Map; } catch { _packMap = null; }
            }
            IDictionary<string, string> map = _packMap;
            if (map == null) return null;
            // T() 每帧被调用上百次，语言包取词异常不得冒到 UI，取不到即整体回退内置语言。
            try {
                string ov;
                if (zh != null && map.TryGetValue(zh, out ov) && ov != null) return ov;
                if (en != null && map.TryGetValue(en, out ov) && ov != null) return ov;
            } catch (Exception __ex) { Guard.Log("Pack", __ex); }
            return null;
        }

        public static string T(string zh, string en) {
            string ov = Pack(zh, en);
            if (ov != null) return ov;
            return UseEn ? (en ?? zh) : zh;
        }

        // 稳定 ID 入口：语言包只按 @id 索引；未收录时用内置文案。
        // T(zh,en) 仅用于非字面量动态文案，不参与词条索引。
        public static string Tid(string id, string zh, string en) {
            if (_pack != null && !_forceZh && !string.IsNullOrEmpty(id)) {
                try {
                    IDictionary<string, string> map = _pack.Map;
                    string ov;
                    if (map != null && map.TryGetValue("@" + id, out ov) && ov != null) return ov;
                } catch (Exception __ex) { Guard.Log("Tid", __ex); }
            }
            return UseEn ? (en ?? zh) : zh;
        }
        private static readonly Dictionary<string, string> _enumZh = new Dictionary<string, string> {
            { "PUBLIC", "公开" }, { "FRIENDS", "仅限朋友" }, { "PRIVATE", "仅邀请" }, { "INVISIBLE", "隐身" },
            { "Fun", "好玩" }, { "Competitive", "竞技" }, { "Beginner", "新手" }, { "CustomLevels", "自定义关卡" },
            { "win", "获胜" }, { "winDead", "死后" }, { "soloWin", "独行" }, { "first", "第一" },
            { "trap", "陷阱" }, { "suicide", "自杀" }, { "comeback", "逆转" }, { "coin", "金币" },
            { "second", "第二" }, { "third", "第三" }, { "fourth", "第四" },
            { "NONE", "无" }, { "None", "无" }, { "Shift", "Shift" }, { "Ctrl", "Ctrl" }, { "Alt", "Alt" },
            { "CHICKEN", "鸡" }, { "HORSE", "马" }, { "SHEEP", "羊" }, { "RACCOON", "浣熊" },
            { "Placement", "放置顺序" }, { "Distance", "距离" }, { "Normal", "普通" }, { "Advanced", "进阶" },
            { "NoTrack", "不追踪" }, { "P1", "#1" }, { "P2", "#2" }, { "P3", "#3" }, { "P4", "#4" },
            { "KeepScore", "保留方块和分数" }, { "KeepBlocksOnly", "仅保留方块" },
            { "CHAMELEON", "变色龙" }, { "SQUIRREL", "松鼠" }, { "ROBOT", "机器兔子" }, { "ELEPHANT", "大象" },
            { "MONKEY", "猴子" }, { "SNAKE", "蛇" }, { "HIPPO", "河马" }, { "TURTLE", "乌龟" },
            { "PANDA", "熊猫" }, { "FOX", "狐狸" }, { "PLATYPUS", "鸭嘴兽" },
            { "FARM", "农场" }, { "ROOFTOPS", "屋顶" }, { "OLDMANSION", "旧房子" }, { "WATERFALL", "瀑布" },
            { "PYRAMID", "金字塔" }, { "WINDMILL", "风车" }, { "METALPLANT", "冶炼厂" }, { "ICEBERG", "冰山" },
            { "DANCEPARTY", "舞会" }, { "PIER", "码头" }, { "BLANKLEVEL", "空白" }, { "JUNGLETEMPLE", "丛林神庙" },
            { "VOLCANO", "火山" }, { "CRUMBLINGBRIDGE", "碎碎桥" }, { "NUCLEARPLANT", "核工厂" }, { "TRONLEVEL", "主机架" },
            { "SPACELEVEL", "太空" }, { "BALLROOM", "宴会厅" }, { "ROLLERCOASTER", "过山车" }, { "METRO", "地铁站" },
            { "WATERTOWER", "毒塔" }, { "RAFT", "岛屿" }, { "PICTUREFRAME", "画框" }, { "SPACESTATION", "空间站" },
            { "RANDOM", "随机" },
            { "MAINMENU", "主菜单" }, { "TREEHOUSE", "树屋" }, { "LOBBY", "大厅" }, { "TUTORIAL", "教程" },
            { "Wins", "胜场" }, { "Success", "成功" }, { "Deaths", "死亡" }, { "Coins", "金币" },
            { "LevelsPlayed", "关卡数" }, { "Rounds", "回合数" }, { "TimePlayed", "总时间" },
        };

        private static string EnumDisplayName(string n) {
            return EnumNameZh(n);
        }

        public static string EnumNameZh(string n) {
            string zh;
            _enumZh.TryGetValue(n, out zh);
            string ov = Pack(zh, n);   //外部语言包覆盖
            if (ov != null) return ov;
            if (UseEn) return n; //英文系直接显示原名
            return zh ?? n;
        }

        // ---------- 外置 JSON 语言包（config/SR_UCH/lang/*.json） ----------
        // JSON 写 {id, displayName, fallback, map} 即可，无需编译 DLL；失败只写日志并跳过该文件。

        private const long MaxLangPackFileBytes = 2L * 1024L * 1024L; // 单文件 2MB 上限
        private const int MaxLangPackEntries = 20000;                // map 最多 2 万条

        // JSON 语言包实现：Map 返回解析出的字典，语言下拉自动多出一项。
        private sealed class JsonLanguagePack : ILanguagePack {
            private readonly string _id;
            private readonly string _displayName;
            private readonly string _fallbackId;
            private readonly Dictionary<string, string> _map;

            public JsonLanguagePack(string id, string displayName, string fallbackId, Dictionary<string, string> map) {
                _id = id;
                _displayName = displayName;
                _fallbackId = fallbackId;
                _map = map;
            }

            public string Id { get { return _id; } }
            public string DisplayName { get { return _displayName; } }
            public string FallbackId { get { return _fallbackId; } }
            public IDictionary<string, string> Map { get { return _map; } }
        }

        // 扫描并注册 config/SR_UCH/lang/*.json；目录不存在属正常情况。
        internal static void LoadJsonLanguagePacks() {
            try {
                string dir;
                try { dir = Path.Combine(Paths.ConfigPath, "SR_UCH", "lang"); }
                catch (Exception __ex) { Guard.Log("语言包/定位目录", __ex); return; }
                try { if (!Directory.Exists(dir)) return; }
                catch (Exception __ex) { Guard.Log("语言包/检查目录", __ex); return; }
                string[] files;
                try { files = Directory.GetFiles(dir, "*.json"); }
                catch (Exception __ex) { Guard.Log("语言包/枚举文件", __ex); return; }
                try { Array.Sort(files, StringComparer.OrdinalIgnoreCase); }
                catch (Exception __ex) { Guard.Log("语言包/排序文件", __ex); }
                int loaded = 0;
                int skipped = 0;
                // 已加载的 id -> 来源文件名，同名覆盖时记一条日志。
                Dictionary<string, string> seenIds = new Dictionary<string, string>(StringComparer.Ordinal);
                for (int i = 0; i < files.Length; i++) {
                    if (LoadOneJsonLanguagePack(files[i], seenIds)) loaded++;
                    else skipped++;
                }
                if (loaded > 0) {
                    SR.LogInfo("[SR] 已从 " + dir + " 加载 " + loaded + " 个 JSON 语言包"
                        + (skipped > 0 ? "（跳过 " + skipped + " 个无效文件）" : ""));
                } else if (skipped > 0) {
                    SR.LogWarn("[SR] " + dir + " 下的 " + skipped + " 个 JSON 语言包全部无效，已跳过");
                }
            } catch (Exception __ex) {
                Guard.Log("语言包/批量加载", __ex);
            }
        }

        // 加载单个 JSON 语言包；返回 false 表示已记日志并跳过。
        private static bool LoadOneJsonLanguagePack(string path, Dictionary<string, string> seenIds) {
            string fileName = "<unknown>";
            try {
                fileName = Path.GetFileName(path);
                long length;
                try { length = new FileInfo(path).Length; }
                catch (Exception __ex) { Guard.Log("语言包/读取文件大小 " + fileName, __ex); return false; }
                if (length <= 0) {
                    SR.LogWarn("[SR] 语言包文件为空，已跳过: " + fileName);
                    return false;
                }
                if (length > MaxLangPackFileBytes) {
                    SR.LogWarn("[SR] 语言包文件超过 2MB 上限，已跳过: " + fileName + "（" + length + " 字节）");
                    return false;
                }
                string text;
                try { text = File.ReadAllText(path, Encoding.UTF8); } // 兼容 BOM（StreamReader 自动识别）
                catch (Exception __ex) { Guard.Log("语言包/读取文件 " + fileName, __ex); return false; }
                string id;
                string displayName;
                string fallbackId;
                string err;
                Dictionary<string, string> map;
                if (!JsonLanguagePackParser.TryParse(text, out id, out displayName, out fallbackId, out map, out err)) {
                    SR.LogWarn("[SR] JSON 语言包无效，已跳过: " + fileName + "（" + err + "）");
                    return false;
                }
                // 与内置语言 id 冲突：提前跳过。
                if (id == LangZh || id == LangEn) {
                    SR.LogWarn("[SR] JSON 语言包 id 与内置语言冲突，已跳过: " + fileName + "（id=" + id + "）");
                    return false;
                }
                if (seenIds != null) {
                    string prev;
                    if (seenIds.TryGetValue(id, out prev)) {
                        SR.LogWarn("[SR] JSON 语言包 id 重复，后加载覆盖: " + id + "（" + fileName + " 覆盖 " + prev + "）");
                    }
                    seenIds[id] = fileName;
                }
                if (string.IsNullOrEmpty(displayName)) displayName = id;
                if (string.IsNullOrEmpty(fallbackId)) fallbackId = LangEn;
                RegisterLanguage(new JsonLanguagePack(id, displayName, fallbackId, map));
                SR.LogInfo("[SR] 已加载 JSON 语言包: " + displayName + " (" + id + "，" + map.Count + " 条) <- " + fileName);
                return true;
            } catch (Exception __ex) {
                Guard.Log("语言包/加载 " + fileName, __ex);
                return false;
            }
        }

        // 最小 JSON 解析器：只取顶层字段与 map，其余只做语法跳过。
        private sealed class JsonLanguagePackParser {
            private string _s;
            private int _i;

            public static bool TryParse(string text, out string id, out string displayName, out string fallbackId,
                out Dictionary<string, string> map, out string err) {
                id = null;
                displayName = null;
                fallbackId = null;
                map = null;
                err = null;
                JsonLanguagePackParser p = new JsonLanguagePackParser();
                p._s = text ?? "";
                p._i = 0;
                try {
                    p.SkipWs();
                    if (!p.TryConsume('{')) return p.Fail("根节点必须是对象", out err);
                    Dictionary<string, string> m = new Dictionary<string, string>(StringComparer.Ordinal);
                    bool hasMap = false;
                    p.SkipWs();
                    if (!p.TryConsume('}')) {
                        while (true) {
                            p.SkipWs();
                            string key;
                            if (!p.TryReadString(out key)) return p.Fail("对象键必须是字符串", out err);
                            p.SkipWs();
                            if (!p.TryConsume(':')) return p.Fail("字段 " + key + " 后缺少冒号", out err);
                            p.SkipWs();
                            if (key == "id" || key == "displayName" || key == "fallback") {
                                string v;
                                if (!p.TryReadString(out v)) {
                                    if (!p.SkipValue()) return p.Fail("字段 " + key + " 的值语法错误", out err);
                                    return p.Fail("字段 " + key + " 必须是字符串", out err);
                                }
                                if (key == "id") id = v;
                                else if (key == "displayName") displayName = v;
                                else fallbackId = v;
                            } else if (key == "map") {
                                if (!p.TryReadStringMap(out m, out err)) return false;
                                hasMap = true;
                            } else {
                                if (!p.SkipValue()) return p.Fail("字段 " + key + " 的值语法错误", out err);
                            }
                            p.SkipWs();
                            if (p.TryConsume(',')) continue;
                            if (p.TryConsume('}')) break;
                            return p.Fail("对象成员之间缺少逗号", out err);
                        }
                    }
                    p.SkipWs();
                    if (p._i != p._s.Length) return p.Fail("根对象之后有多余内容", out err);
                    if (string.IsNullOrEmpty(id)) return p.Fail("缺少 id 字段或 id 为空", out err);
                    if (!hasMap || m.Count == 0) return p.Fail("缺少 map 字段或 map 为空", out err);
                    map = m;
                    return true;
                } catch (Exception __ex) {
                    err = __ex.GetType().Name;
                    return false;
                }
            }

            private bool Fail(string msg, out string err) { err = msg; return false; }

            private void SkipWs() {
                while (_i < _s.Length) {
                    char c = _s[_i];
                    if (c == ' ' || c == '\t' || c == '\r' || c == '\n') { _i++; continue; }
                    break;
                }
            }

            private bool TryConsume(char c) {
                if (_i < _s.Length && _s[_i] == c) { _i++; return true; }
                return false;
            }

            // JSON 字符串：支持标准转义与 \uXXXX（代理对由两个转义拼成）。
            private bool TryReadString(out string value) {
                value = null;
                SkipWs();
                if (!TryConsume('"')) return false;
                StringBuilder sb = new StringBuilder();
                while (_i < _s.Length) {
                    char c = _s[_i++];
                    if (c == '"') { value = sb.ToString(); return true; }
                    if (c != '\\') { sb.Append(c); continue; }
                    if (_i >= _s.Length) return false;
                    char e = _s[_i++];
                    switch (e) {
                        case '"': sb.Append('"'); break;
                        case '\\': sb.Append('\\'); break;
                        case '/': sb.Append('/'); break;
                        case 'b': sb.Append('\b'); break;
                        case 'f': sb.Append('\f'); break;
                        case 'n': sb.Append('\n'); break;
                        case 'r': sb.Append('\r'); break;
                        case 't': sb.Append('\t'); break;
                        case 'u':
                            if (_i + 4 > _s.Length) return false;
                            int cp;
                            if (!int.TryParse(_s.Substring(_i, 4), NumberStyles.HexNumber, CultureInfo.InvariantCulture, out cp)) return false;
                            sb.Append((char)cp);
                            _i += 4;
                            break;
                        default: return false;
                    }
                }
                return false;
            }

            // map 必须是对象，键值均字符串；其他类型跳过而不整文件作废。
            private bool TryReadStringMap(out Dictionary<string, string> map, out string err) {
                map = new Dictionary<string, string>(StringComparer.Ordinal);
                err = null;
                SkipWs();
                if (!TryConsume('{')) { err = "map 必须是对象"; return false; }
                SkipWs();
                if (TryConsume('}')) return true;
                while (true) {
                    SkipWs();
                    string key;
                    if (!TryReadString(out key)) { err = "map 的键必须是字符串"; return false; }
                    SkipWs();
                    if (!TryConsume(':')) { err = "map 成员 " + key + " 后缺少冒号"; return false; }
                    SkipWs();
                    string val;
                    if (TryReadString(out val)) {
                        if (map.Count >= MaxLangPackEntries) { err = "map 超过 " + MaxLangPackEntries + " 条上限"; return false; }
                        map[key] = val; // 同键重复：后者覆盖
                    } else {
                        if (!SkipValue()) { err = "map 成员 " + key + " 的值语法错误"; return false; }
                    }
                    SkipWs();
                    if (TryConsume(',')) continue;
                    if (TryConsume('}')) return true;
                    err = "map 成员之间缺少逗号";
                    return false;
                }
            }

            private bool SkipValue() {
                SkipWs();
                if (_i >= _s.Length) return false;
                char c = _s[_i];
                if (c == '"') {
                    string tmp;
                    return TryReadString(out tmp);
                }
                if (c == '{') {
                    _i++;
                    SkipWs();
                    if (TryConsume('}')) return true;
                    while (true) {
                        SkipWs();
                        string k;
                        if (!TryReadString(out k)) return false;
                        SkipWs();
                        if (!TryConsume(':')) return false;
                        if (!SkipValue()) return false;
                        SkipWs();
                        if (TryConsume(',')) continue;
                        return TryConsume('}');
                    }
                }
                if (c == '[') {
                    _i++;
                    SkipWs();
                    if (TryConsume(']')) return true;
                    while (true) {
                        if (!SkipValue()) return false;
                        SkipWs();
                        if (TryConsume(',')) continue;
                        return TryConsume(']');
                    }
                }
                int start = _i;
                while (_i < _s.Length) {
                    char d = _s[_i];
                    if (d == ',' || d == '}' || d == ']' || d == ' ' || d == '\t' || d == '\r' || d == '\n') break;
                    _i++;
                }
                return _i > start;
            }
        }

    }
}
