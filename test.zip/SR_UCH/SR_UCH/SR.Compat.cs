// 第三方插件兼容性自检：列出 BepInEx\plugins 下已加载的其它插件，并给出已知冲突/注意事项。
// 数据来源：AppDomain 已加载程序集的位置；规则为本机插件静态分析后手工登记，不做自动推断。
using System;
using System.Collections.Generic;
using System.Reflection;
using System.Text;
using UnityEngine;

namespace SR_UCH.Tweaks {
public partial class SR {

    // 一条已知兼容性规则：匹配程序集简单名（不区分大小写）。
    private sealed class CompatRule {
        public readonly string Id;
        public readonly int Level;   // 0 = 无已知冲突；1 = 注意；2 = 冲突
        public readonly string Zh, En;
        public CompatRule(string id, int level, string zh, string en) { Id = id; Level = level; Zh = zh; En = en; }
    }

    private sealed class CompatPlugin {
        public string Name, Version;
        public int Level;
        public bool Known;
        public string Zh, En;
    }

    private static readonly CompatRule[] CompatRules = new CompatRule[] {
        new CompatRule("CamHog", 1,
            "与「视觉辅助」目标相同：CamHog 在时 SR 的视觉辅助自动让位；两者保留一个即可。",
            "Same goal as Visual Aid: SR's Visual Aid yields while CamHog is loaded; keep only one."),
        new CompatRule("WalljumpBugFix", 0,
            "输入时序修复，补丁目标（Controller.Notify / Character.ReceiveEvent）与 SR 无重叠。",
            "Input timing fix; its patch targets do not overlap SR."),
        new CompatRule("LevelLibrary", 1,
            "往树屋电脑注入本地关卡库/筛选 UI；与 UCH Map Packs 同装时两边都要改电脑界面，可能互相干扰。与 SR 的布局预设共享 .snapshot 目录（只读）。",
            "Injects a local level library/filter UI into the treehouse computer; it can fight UCH Map Packs for that UI. Shares the .snapshot folder with SR presets (read-only)."),
        new CompatRule("UCHMapPacks", 1,
            "地图包/挑战模式大 mod：挑战计时与 SR 的 HUD 计时会重复显示（建议关掉一个）；与 Level Library 抢树屋电脑 UI。",
            "Big map-pack/challenge mod: its challenge timer duplicates SR's HUD timer (turn one off); competes with Level Library for the computer UI."),
        new CompatRule("EvenMoreMaps", 1,
            "自定义地图/机关大 mod。当前实例里它是 .ccc（未加载）；启用后与 SR 关卡功能的组合未实测。",
            "Custom maps/mechanics mod. Currently disabled here (.ccc); combinations with SR level features are untested."),
        new CompatRule("LevelLoadingOptimizer", 0,
            "只给 Placeable.Place 加加速前缀，与 SR 补丁无重叠。",
            "Only adds a speed-up prefix to Placeable.Place; no overlap with SR patches."),
        new CompatRule("BetterNightBG", 0,
            "只改夜间背景颜色（Level.SetBackground 后缀），纯视觉。",
            "Only recolors the night background (Level.SetBackground postfix); purely visual."),
        new CompatRule("UCHSoundScout", 1,
            "声音相关插件；SR 不改音频，但界面/按键可能重叠（未实测）。",
            "Audio-related plugin; SR does not touch audio, but UI/hotkeys may overlap (untested)."),
        new CompatRule("UCHSounds", 1,
            "声音相关插件；SR 不改音频，但界面/按键可能重叠（未实测）。",
            "Audio-related plugin; SR does not touch audio, but UI/hotkeys may overlap (untested)."),
        new CompatRule("Barnyard", 1,
            "动物/模型相关插件；与 SR 无补丁重叠，但同类目功能（角色自动选择等）可能互相覆盖状态。",
            "Animal/cosmetic plugin; no patch overlap, but similar features may overwrite each other's state."),
    };

    private static List<CompatPlugin> _compatPlugins;

    private static bool InPluginsDir(string loc) {
        if (string.IsNullOrEmpty(loc)) return false;
        return loc.IndexOf("BepInEx", StringComparison.OrdinalIgnoreCase) >= 0
            && loc.IndexOf("plugins", StringComparison.OrdinalIgnoreCase) >= 0;
    }

    private static CompatRule FindCompatRule(string name) {
        for (int i = 0; i < CompatRules.Length; i++)
            if (string.Equals(CompatRules[i].Id, name, StringComparison.OrdinalIgnoreCase)) return CompatRules[i];
        return null;
    }

    private static void ScanCompatPlugins() {
        List<CompatPlugin> rows = new List<CompatPlugin>();
        try {
            Assembly[] all = AppDomain.CurrentDomain.GetAssemblies();
            for (int i = 0; i < all.Length; i++) {
                Assembly asm = all[i];
                if (asm == null || asm.IsDynamic) continue;
                AssemblyName an = asm.GetName();
                string name = an != null ? an.Name : null;
                if (string.IsNullOrEmpty(name)) continue;
                if (name == "SR_UCH") continue;
                if (!InPluginsDir(asm.Location)) continue;
                CompatRule rule = FindCompatRule(name);
                CompatPlugin row = new CompatPlugin();
                row.Name = name;
                row.Version = an.Version != null ? an.Version.ToString() : "";
                row.Known = rule != null;
                row.Level = rule != null ? rule.Level : 0;
                row.Zh = rule != null ? rule.Zh : "未测试：SR 没有分析过这个插件（不等于有冲突）。";
                row.En = rule != null ? rule.En : "Untested: SR has not analysed this plugin (not the same as broken).";
                rows.Add(row);
            }
            rows.Sort(delegate (CompatPlugin a, CompatPlugin b) { return string.Compare(a.Name, b.Name, StringComparison.OrdinalIgnoreCase); });
        } catch (Exception __ex) { Guard.Log("兼容性/扫描插件", __ex); }
        _compatPlugins = rows;
    }

    private static void EnsureCompat() {
        if (_compatPlugins == null) ScanCompatPlugins();
    }

    internal static string CompatSummary() {
        try {
            EnsureCompat();
            int conflict = 0, note = 0, other = 0;
            for (int i = 0; i < _compatPlugins.Count; i++) {
                CompatPlugin p = _compatPlugins[i];
                if (p.Level >= 2) conflict++;
                else if (p.Level == 1) note++;
                else other++;
            }
            return _compatPlugins.Count + Tid("fea3102b30", " 个（冲突 ", " detected (conflict ") + conflict + Tid("77167b8f24", " · 注意 ", " · note ")
                + note + Tid("d2b65d3a2a", " · 无已知冲突/未测试 ", " · clear/untested ") + other + "）";
        } catch (Exception __ex) { Guard.Log("兼容性/摘要", __ex); return "?"; }
    }

    private static string CompatVerdict(CompatPlugin p) {
        if (p.Level >= 2) return Tid("07f284b4af", "冲突", "conflict");
        if (p.Level == 1) return Tid("2159ceab95", "注意", "note");
        return p.Known ? Tid("ea54e524e8", "无已知冲突", "clear") : Tid("0d86b7a418", "未测试", "untested");
    }

}
}
