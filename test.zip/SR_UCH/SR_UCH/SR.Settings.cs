// 设置页：条目行与控件渲染、滑块、下拉框、侧栏顺序、CM 排序与隐藏。
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Reflection;
using BepInEx;
using BepInEx.Bootstrap;
using BepInEx.Configuration;
using UnityEngine;

namespace SR_UCH.Tweaks {
public partial class SR {

// 分区：Settings（设置页 / 条目行 / 控件 / 滑块 / 下拉框）

        // 让 CM 条目顺序与 SR 一致：反射替换 Description 标签；仅改标签，值保留。
        private static int _cmOrderVer = -1;   //上次应用排序时的条目版本
        // Description 后备字段名随 BepInEx 版本不同，故按"名字含 escription"探测。
        private static readonly FieldInfo _fEntryDesc = ProbeEntryDescField();
        private static FieldInfo ProbeEntryDescField() {
            try {
                FieldInfo[] fs = typeof(ConfigEntryBase).GetFields(BindingFlags.Instance | BindingFlags.NonPublic | BindingFlags.Public);
                for (int i = 0; i < fs.Length; i++) {
                    if (fs[i].FieldType != typeof(ConfigDescription)) continue;
                    if (fs[i].Name.IndexOf("escription", StringComparison.Ordinal) >= 0) return fs[i];
                }
                // 探测不到就带版本号明确报错，不要静默跳过排序 / 隐藏。
                string ver = "?";
                try { ver = typeof(ConfigFile).Assembly.GetName().Version.ToString(); } catch { /* 版本号取不到就写 ? */ }
                SR.LogWarn("[设置] 未找到 ConfigEntryBase 的 Description 后备字段（BepInEx " + ver
                    + "），Configuration Manager 里的条目将不排序/不隐藏");
            } catch (Exception __ex) { Guard.Log("探测 Description 字段", __ex); }
            return null;
        }

        internal static void ApplyCmOrder() {
            if (_internalConfig == null) return;
            if (_cmOrderVer == _entryVersion) return;   //条目表没变：直接返回
            _cmOrderVer = _entryVersion;
            try {
                // CM 为 OrderByDescending：栏目内倒序编号，先绑定的条目 Order 最大。
                Dictionary<string, int> secRank = new Dictionary<string, int>();
                // Order 大的在前，故侧栏第一个栏目 rank 取 总数-1-i。
                for (int i = 0; i < _internalSections.Count; i++) secRank[_internalSections[i]] = _internalSections.Count - 1 - i;
                // 先按栏目分组，取得每栏条目数后才能倒序编号
                Dictionary<string, List<ConfigEntryBase>> bySec = new Dictionary<string, List<ConfigEntryBase>>();
                foreach (ConfigEntryBase e in AllEntries(_internalConfig)) {
                    if (e == null) continue;
                    string sec = e.Definition.Section;
                    if (string.IsNullOrEmpty(sec)) sec = "(General)";
                    List<ConfigEntryBase> list;
                    if (!bySec.TryGetValue(sec, out list)) { list = new List<ConfigEntryBase>(); bySec[sec] = list; }
                    list.Add(e);
                }
                foreach (KeyValuePair<string, List<ConfigEntryBase>> kv in bySec) {
                    int r; if (!secRank.TryGetValue(kv.Key, out r)) r = -1; //未注册为栏目的段 Order 最小，排最后
                    List<ConfigEntryBase> list = kv.Value;
                    for (int k = 0; k < list.Count; k++) {
                        ConfigEntryBase e = list[k];
                        int order = r * 1000 + (list.Count - 1 - k); //倒序编号：第 1 个绑定的排最前
                        try {
                            ConfigDescription d = e.Description;
                            if (_fEntryDesc != null) {
                                // SR 自带界面，CM 中不再列出这些条目。
                                object[] tags = new object[] { new ConfigurationManagerAttributes { Order = order, Browsable = false, HideSetting = true } };
                                _fEntryDesc.SetValue(e, new ConfigDescription(d != null ? d.Description : "", d != null ? d.AcceptableValues : null, tags));
                            }
                        } catch (Exception __ex) { Guard.Log("设置条目显示顺序(单条)", __ex); }
                    }
                }
            } catch (Exception __ex) { Guard.Log("Configuration Manager 排序", __ex); }
        }

        // 枚举下拉选项缓存：键为 entry（RowEnumAllowed 依赖 entry，按 Type 会串台）。
    internal static readonly Dictionary<ConfigEntryBase, object[]> _enumOptions = new Dictionary<ConfigEntryBase, object[]>();
    internal static int _enumOptionsVersion = -1;   // 上次清空时的 _entryVersion
    internal static int EnumOptionsVersion { get { return _enumOptionsVersion; } set { _enumOptionsVersion = value; } }

        private static void SetValue(ConfigEntryBase entry, object value) {
            try {
                // 类型归一化：int 条目必须收到 int，否则 BepInEx 抛异常导致滑块无效
                if (value != null) {
                    Type st = entry.SettingType;
                    if (st == typeof(int) && !(value is int)) value = Mathf.RoundToInt(Convert.ToSingle(value));
                    else if (st == typeof(float) && !(value is float)) value = Convert.ToSingle(value);
                }
                entry.BoxedValue = value;
                if (entry == _blockInputEntry) {
                    BlockInput = value is bool bv && bv;
                    ApplyEventSystemGate();
                }
                MarkConfigDirty(entry.ConfigFile);
                // 外部改值时清编辑框缓存；编辑框自身提交的那一帧不清，否则会吃掉小数点。
                if (_editSelfFrame != Time.frameCount) _editText.Remove(entry);
            } catch (Exception ex) {
                SR.LogWarn("配置修改失败: " + ex.Message);
            }
        }

        private static List<ConfigEntryBase> InternalSectionEntries() {
            return SectionEntries(_selectedInternalSection);
        }

        // 设置页条目分组顺序，与 config 绑定顺序一致，插件组最后。
        private static readonly string[][] _settingsGroups = new string[][] {
            new[] { "按键", Keys.OpenKey, Keys.BlockInput },
            new[] { "界面", Keys.UiScale, Keys.WinWidth, Keys.WinHeight, Keys.WinX, Keys.WinY, Keys.Language },
            new[] { "插件", Keys.DisabledPlugins },
        };

        private static string SettingsGroup(string key) {
            foreach (string[] g in _settingsGroups) {
                for (int i = 1; i < g.Length; i++) {
                    if (g[i] == key) return g[0];
                }
            }
            return null;
        }

        internal static void RenderSettingsPage(float colWidth) {
            try {
                // 必须显式关页面滚动：NoPageScrollBars 用后清零，否则设置页会被当成不滚动。
                SRApi.NoPageScrollBars = false;
                GUILayout.Space(Sc(4));
                RenderSettingsEntries(colWidth);
            } catch (Exception __ex) { Guard.Log("设置页", __ex); }
        }

        private static void RenderSettingsEntries(float colWidth) {
            string lastGroup = null;
            bool any = false;
            bool pluginListDrawn = false;
            foreach (ConfigEntryBase entry in SettingsEntries()) {
                any = true;
                // Tick Profiling 只在自检页显示，通用页重复会让两个勾选框打架。
                if (entry.Definition.Key == "Tick Profiling") continue;
                if (entry.Definition.Key == Keys.SidebarWidth) { RenderSidebarWidthRow(); continue; }
                string g = SettingsGroup(entry.Definition.Key);
                // 外部插件清单排在"界面"分组之后
                if (!pluginListDrawn && lastGroup == "界面" && (g == null || g != "界面")) {
                    pluginListDrawn = true;
                    GUILayout.Space(Sc(4));
                    RenderSidebarOrder();
                    RenderPluginList();
                }
                if (g != null && g != lastGroup) {
                    lastGroup = g;
                    GUILayout.Label("- " + T(g, g == "按键" ? "Keys" : g == "界面" ? "UI" : "Plugins") + " -", _secHeader);
                }
                RenderEntryRow(entry, true, colWidth);
            }
            if (!pluginListDrawn) {
                GUILayout.Space(Sc(4));
                RenderSidebarOrder();
                RenderPluginList();
            }
            if (!any) GUILayout.Label(Tid("2be7d7a6da", "（无匹配条目）", "(no matching entries)"), _label);
        }


        private static void RenderSidebarWidthRow() {
            int cur = _sidebarWEntry != null ? Mathf.Clamp(_sidebarWEntry.Value, Ui.SidebarWMin, Ui.SidebarWMax) : 0;
            GUILayout.BeginHorizontal();
            GUILayout.Label(new GUIContent(Tid("7c099386bd", "栏目宽度", "Sidebar Width"), Tid("74e251460f", "左侧栏目栏宽度（0 = 自动，100-320）", "Left sidebar width (0 = auto, 100-320)")), _label, GUILayout.Width(Sc(140)), GUILayout.Height(Sc(26)));
            if (GUILayout.Button("-", _btn, GUILayout.Width(Sc(30)), GUILayout.Height(Sc(26)))) SetSidebarWidth(cur - 16);
            Rect sr = GUILayoutUtility.GetRect(Sc(150), CtlH(), GUILayout.Width(SliderTrackWidth()));
            float nv = DrawSlider(sr, cur, (float)Ui.SidebarWMin, (float)Ui.SidebarWMax, true);
            if (Mathf.Abs(nv - cur) > 0.0001f) SetSidebarWidth(Mathf.RoundToInt(nv)); //值变化即写
            if (GUILayout.Button("+", _btn, GUILayout.Width(Sc(30)), GUILayout.Height(Sc(26)))) SetSidebarWidth(cur + 16);
            GUILayout.Label(cur + " px", _label, GUILayout.Width(Sc(70)), GUILayout.Height(Sc(26)));
            GUILayout.FlexibleSpace();
            GUILayout.EndHorizontal();
        }

        // 同时更新即时值与配置项。
        private static void SetSidebarWidth(int px) {
            // 上限跟窗口走：自定义宽度不能把内容区挤没。
            float cap = Mathf.Clamp(SRApi.ContentArea.width * 0.55f, 100f, 320f);
            px = Mathf.Clamp(px, 0, Mathf.RoundToInt(cap));
            _sidebarW = px;
            if (_sidebarWEntry != null) _sidebarWEntry.Value = px;
        }

        // 设置页条目列表：按版本缓存；比 SectionEntries 多一条组合键过滤。
        private static List<ConfigEntryBase> _settingsCache;
        private static int _settingsCacheVer = -1;
        private static List<ConfigEntryBase> SettingsEntries() {
            if (_settingsCache != null && _settingsCacheVer == _entryVersion) return _settingsCache;
            List<ConfigEntryBase> result = new List<ConfigEntryBase>();
            if (_internalConfig != null) {
                foreach (ConfigEntryBase e in AllEntries(_internalConfig)) {
                    if (e.Definition.Section != "Settings") continue;
                    // 会话页 / 搜索栏已有开关的项不在此渲染（可见性经 SRApi.RowFilters 注册）
                    if (!SR.RowVisible(e)) continue;
                    if (e.Definition.Key.StartsWith(Keys.ComboPrefix)) continue;
                    if (e.Definition.Key == Keys.SidebarOrder) continue; //侧栏顺序由拖动维护
                    result.Add(e);
                }
            }
            _settingsCache = result;
            _settingsCacheVer = _entryVersion;
            return result;
        }

        // 可点击标签：左键恢复默认值，右键绑定快捷键；hotkey 为 null 时仅 bool 条目接入自动快捷键。
        private static void RestoreLabel(GUIContent content, ConfigEntryBase entry, float w, float h, ConfigEntry<KeyCode> hotkey = null) {
            GUIContent c2 = content;
            ConfigEntry<KeyCode> hk = hotkey; //只认功能显式传入的键
            try {
                string tip = content.tooltip != null ? content.tooltip : "";
                // 提示顺序：是什么 → 做什么 → 注意 → 默认值 → 按键。
                tip = ComposeTip(entry, tip, hk);
                if (hk != null) {
                    string txt = content.text + KeySuffix(hk);
                    c2 = new GUIContent(txt, tip);
                } else if (tip != content.tooltip) {
                    c2 = new GUIContent(content.text, tip);
                }
                // 宽度只按文字宽 + 内边距，只收缩不放大；带键位后缀时放宽到可用宽度。
                float need = _label.CalcSize(c2).x + Sc(8);
                if (need < w) w = Mathf.Max(Sc(24), need);
                else if (hk != null) w = Mathf.Min(need, Mathf.Max(w, _winWidth - SidebarWidth() - Sc(24)));
            } catch (Exception __ex) { Guard.Log("条目默认值处理", __ex); }
            if (GUILayout.Button(c2, _label, GUILayout.Width(w), GUILayout.Height(h))) {
                Event evLbl = Event.current;
                if (evLbl == null || evLbl.button == 0) {
                    if (entry != null) {
                        try {
                            // 编辑框（字符串）点标签 = 清空，其余条目 = 恢复默认值
                            entry.BoxedValue = entry.SettingType == typeof(string) ? (object)"" : entry.DefaultValue;
                        } catch (Exception __ex) { Guard.Log("恢复条目默认值", __ex); }
                    }
                    MarkKeyChanged();   //重置可能改动键位，令序列监听列表失效
                    _editText.Remove(entry);
                    _editOpen.Remove(entry);
                    if (_capturing == entry) _capturing = null;
                }
            }
            if (hk != null) RegisterRowHotkey(hk);
        }

        private static ConfigFile _visCfg;
        private static int _visVer = -1;
        private static List<ConfigEntryBase> _visCache;
        private static List<ConfigEntryBase> VisibleEntries(ConfigFile config) {
            if (config == null) return new List<ConfigEntryBase>();
            // 按条目版本缓存（外部插件页每个 OnGUI 事件都会调用）。
            if (_visCache != null && _visCfg == config && _visVer == _entryVersion) return _visCache;
            List<ConfigEntryBase> result = new List<ConfigEntryBase>();
            foreach (ConfigEntryBase e in AllEntries(config)) {
                result.Add(e);
            }
            _visCfg = config; _visVer = _entryVersion; _visCache = result;
            return result;
        }

        // 取条目优先用 ConfigFile 显式实现的 IDictionary.Values（GetConfigEntries 已过时）。
        private static readonly ConfigEntryBase[] NoEntries = new ConfigEntryBase[0];
        private static IEnumerable<ConfigEntryBase> AllEntries(ConfigFile config) {
            if (config == null) return NoEntries;
            IDictionary<ConfigDefinition, ConfigEntryBase> dict = config as IDictionary<ConfigDefinition, ConfigEntryBase>;
            if (dict != null) return dict.Values;
#pragma warning disable CS0618 //旧版 BepInEx 兜底
            return config.GetConfigEntries();
#pragma warning restore CS0618
        }

        // 侧栏宽度：0 = 自动，>0 = 用户拖动设定值。
        private static float _sidebarW = 0f;
        internal static float SidebarW { get { return _sidebarW; } set { _sidebarW = value; } }
        private static bool _sidebarResizing;
        internal static bool SidebarResizing { get { return _sidebarResizing; } set { _sidebarResizing = value; } }
        private static ConfigEntry<int> _sidebarWEntry; //设置页栏目宽度滑块（0 = 自动）
        internal static ConfigEntry<int> SidebarWEntry { get { return _sidebarWEntry; } set { _sidebarWEntry = value; } }
        private static ConfigEntry<string> _sidebarOrderEntry; //侧栏自定义顺序（逗号分隔），拖动列头时写回
        internal static ConfigEntry<string> SidebarOrderEntry { get { return _sidebarOrderEntry; } set { _sidebarOrderEntry = value; } }
        // 栏目拖拽排序不做坐标命中（条目在滚动区内），改用 hotControl + 鼠标纵向位移判目标行。

        // 按配置的自定义顺序重排侧栏栏目（新栏目排末尾）；本方法唯一产出三份栏目列表。
        private static void ApplyCustomSidebarOrder() {
            try {
                string ord = _sidebarOrderEntry != null ? _sidebarOrderEntry.Value : null;
                List<string> all = new List<string>();
                HashSet<string> hid = new HashSet<string>();
                // 先按改名映射改写段名，再做死条目判定。
                if (!string.IsNullOrEmpty(ord)) ord = RemapSidebarOrderNames(ord);
                if (!string.IsNullOrEmpty(ord)) ord = DropDeadSidebarOrderNames(ord);
                // 纯字母序的 Sidebar Order 视为非自定义并忽略，避免永久覆盖默认 rank 顺序。
                if (!string.IsNullOrEmpty(ord)) {
                    List<string> probe = new List<string>();
                    foreach (string raw0 in ord.Split(',')) {
                        string n0 = raw0.Trim();
                        if (n0.Length == 0) continue;
                        if (n0[0] == '!') n0 = n0.Substring(1).Trim();
                        if (n0.Length > 0 && !probe.Contains(n0)) probe.Add(n0);
                    }
                    List<string> sorted = new List<string>(probe);
                    sorted.Sort(delegate(string a, string b) { return string.Compare(a, b, StringComparison.OrdinalIgnoreCase); });
                    bool alphabetical = probe.Count > 1;
                    for (int i = 0; alphabetical && i < probe.Count; i++)
                        if (string.Compare(probe[i], sorted[i], StringComparison.OrdinalIgnoreCase) != 0) alphabetical = false;
                    if (alphabetical) ord = null;   //视为"无自定义"-> 回到默认 rank 顺序
                }
                if (!string.IsNullOrEmpty(ord)) {
                    foreach (string raw in ord.Split(',')) {
                        string n = raw.Trim();
                        if (n.Length == 0) continue;
                        bool h = n[0] == '!';
                        if (h) n = n.Substring(1).Trim();
                        if (n.Length == 0 || all.Contains(n)) continue;
                        all.Add(n);
                        if (h) hid.Add(n);
                    }
                }
                // 不按字母序补位：默认顺序已由各功能注册的 SR.Nav 排好。
                for (int i = 0; i < _internalSections.Count; i++) {
                    string s2 = _internalSections[i];
                    if (!all.Contains(s2)) all.Add(s2);
                }
                _allSections.Clear();
                for (int i = 0; i < all.Count; i++) _allSections.Add(all[i]);
                _userHiddenSections.Clear();
                foreach (string h2 in hid) _userHiddenSections.Add(h2);
                _internalSections.Clear();
                for (int i = 0; i < all.Count; i++) if (!_userHiddenSections.Contains(all[i])) _internalSections.Add(all[i]);
                // 清洗结果与默认值一致时落盘清除，避免每帧重演。
                string cleaned = string.Join(",", _internalSections.ToArray());
                if (_sidebarOrderEntry != null && !string.IsNullOrEmpty(ord)
                    && _sidebarOrderEntry.Value != null && _sidebarOrderEntry.Value != cleaned
                    && DropDeadSidebarOrderNames(_sidebarOrderEntry.Value) == cleaned)
                    _sidebarOrderEntry.Value = cleaned;
            } catch (Exception __ex) { Guard.Log("应用侧栏自定义顺序", __ex); }
        }

        // 侧栏顺序串的段名改名映射；与 ConfigMigration.SectionMap（迁移 cfg 段名）不同。
        private static readonly Dictionary<string, string> SidebarOrderRenames = new Dictionary<string, string> {
            { "建造增强", "build" },
            { "Builder Enhancements", "build" },
        };

        // 按映射改写 Sidebar Order 的旧段名，保留 ! 前缀与原顺序。
        private static string RemapSidebarOrderNames(string ord) {
            if (string.IsNullOrEmpty(ord)) return ord;
            List<string> parts = new List<string>();
            bool changed = false;
            foreach (string raw in ord.Split(',')) {
                string n = raw.Trim();
                if (n.Length == 0) continue;
                bool h = n[0] == '!';
                if (h) n = n.Substring(1).Trim();
                if (n.Length == 0) continue;
                string mapped;
                if (SidebarOrderRenames.TryGetValue(n, out mapped) && mapped != n) {
                    n = mapped;
                    changed = true;
                }
                parts.Add(h ? ("!" + n) : n);
            }
            return changed ? string.Join(",", parts.ToArray()) : ord;
        }

        // 剔除匹配不到真实栏目的死条目，判定依据为 _internalSections。
        private static string DropDeadSidebarOrderNames(string ord) {
            if (string.IsNullOrEmpty(ord)) return ord;
            HashSet<string> live = new HashSet<string>(_internalSections);
            if (live.Count == 0) return ord;   //还没算出真实栏目，别贸然清洗
            List<string> parts = new List<string>();
            foreach (string raw in ord.Split(',')) {
                string n = raw.Trim();
                if (n.Length == 0) continue;
                bool h = n[0] == '!';
                if (h) n = n.Substring(1).Trim();
                if (n.Length == 0) continue;
                if (!live.Contains(n)) continue;   //死条目：直接丢掉，不占位
                parts.Add(h ? ("!" + n) : n);
            }
            return string.Join(",", parts.ToArray());
        }

        // 设置页栏目顺序块：按住列头拖动调序；状态由 SRApi.TableArgs 持有。

        // 自定义栏目 = 无数据行的 SR 列表，只用表头：拖动改序，右键隐藏，Shift+右键还原。
        private static readonly List<int> _ordVis = new List<int>();
        private static readonly HashSet<int> _ordHidden = new HashSet<int>();
        private static SRApi.TableArgs _ordArgs;
        private static int _ordN = -1;
        private static float[] _ordColW;
        private static float[] _ordDefaultColW() { int n = Mathf.Max(1, _ordN); float[] d = new float[n]; for (int i = 0; i < n; i++) d[i] = 64f; return d; }
        private static int[] _ordOrder;   //显示顺序（数据列下标）
        private static void EnsureOrdArgs(int n) {
            if (_ordArgs != null && _ordN == n) return;
            _ordN = n;
            _ordArgs = new SRApi.TableArgs();
            _ordColW = new float[n];
            for (int i = 0; i < n; i++) _ordColW[i] = 64f;   //表头默认宽度 64px（可拖分隔线拉宽）
            _ordArgs.colW = _ordColW;
            _ordArgs.defaultColW = _ordDefaultColW();   //Shift+右键还原列宽用
            _ordArgs.rowCount = 0;        //无数据行，只用表头
            _ordArgs.emptyHint = null;
            _ordArgs.headerH = Sc(22); _ordArgs.rowH = Sc(22); _ordArgs.rowsH = 0f;
            _ordArgs.vertical = false;
            _ordArgs.hideable = true; _ordArgs.reorderable = true; _ordArgs.resizable = true;
            _ordArgs.vis = _ordVis; _ordArgs.hidden = _ordHidden;
            _ordOrder = new int[n];
            for (int i = 0; i < n; i++) _ordOrder[i] = i;
            _ordArgs.order = _ordOrder;
            _ordArgs.allCols = new List<int>();
            _ordArgs.headerCols = new List<int>();
            for (int i = 0; i < n; i++) { _ordArgs.allCols.Add(i); _ordArgs.headerCols.Add(i); }
            _ordArgs.title = delegate(int ci) { return (ci >= 0 && ci < _ordN) ? ZhSection(SR._allSections[ci]) : ""; };
            _ordArgs.applyOrder = delegate(int[] o) {
                try {
                    if (o == null || o.Length != _ordN || SR._sidebarOrderEntry == null) return;
                    // 核心重建后按当前顺序回调归一化，相同则跳过，避免把显示顺序固化进配置。
                    bool same = _ordOrder != null && _ordOrder.Length == o.Length;
                    for (int i = 0; same && i < o.Length; i++) if (_ordOrder[i] != o[i]) same = false;
                    if (same) return;
                    string[] names = new string[_ordN];
                    for (int i = 0; i < _ordN; i++) names[i] = SR._allSections[o[i]];
                    SR._sidebarOrderEntry.Value = string.Join(",", names);
                    // o 是列下标置换，保留旧置换会让下一帧用过期的列映射，故置空待重建。
                    _ordOrder = null;   //置空 -> EnsureOrdArgs/下一次绘制时重建为恒等序
                    SR.RebuildSectionsPublic(false);
                } catch (Exception __ex) { Guard.Log("保存栏目顺序", __ex); }
                };
            _ordArgs.resetAll = delegate { SR.ResetSidebarOrder(); };   //Shift+右键 = 还原全部（排序 + 隐藏）
            _ordArgs.saveWidths = delegate { };   //列宽由静态 _ordColW 跨帧保留
        }

        private static void RenderSidebarOrder() {
            try {
                if (SR._allSections.Count <= 1) return;
                GUILayout.Label(Tid("1987a57ec0", "- 自定义栏目 -", "- Custom sections -"), _secHeader);
                SR.WrapLabel(Tid("be661445db", "拖动列头调整侧栏顺序；右键列头隐藏栏目；Shift+右键还原。", "Drag a header to reorder; right-click a header to hide a section; Shift+right-click to restore."));
                int n = SR._allSections.Count;
                EnsureOrdArgs(n);
                GUILayout.BeginVertical(GUILayout.Height(Sc(30)));
                SRApi.TableArgs a = _ordArgs;
                _ordHidden.Clear(); _ordVis.Clear();
                for (int i = 0; i < n; i++) {
                    if (SR._userHiddenSections.Contains(SR._allSections[i])) _ordHidden.Add(i); else _ordVis.Add(i);
                }
                float sum = 0f; for (int i = 0; i < _ordVis.Count; i++) sum += SR.Ctl.Sc(_ordColW[_ordVis[i]]);
                if (sum < Sc(60)) sum = Sc(60);
                GUILayout.Space(Sc(2));
                // 不套内层滚动区：嵌套 BeginScrollView 会让设置页排版错位。
                a.box = GUILayoutUtility.GetRect(sum, Sc(24));   //横向列头：高度固定 24px
                a.stripW = sum;
                if (_ordOrder == null) { _ordOrder = new int[n]; for (int i = 0; i < n; i++) _ordOrder[i] = i; a.order = _ordOrder; }   //恒等序兜底
                a.mp = Event.current != null ? Event.current.mousePosition : Vector2.zero;
                SR.TableDraw(a);
                for (int i = 0; i < n; i++) {
                    bool hid = _ordHidden.Contains(i);
                    if (hid != SR._userHiddenSections.Contains(SR._allSections[i])) SR.SetSectionHidden(SR._allSections[i], hid);
                }
                GUILayout.EndVertical();
                GUILayout.Space(Sc(4));
            } catch (Exception __ex) { Guard.Log("自定义栏目", __ex); }
        }
        private static float SidebarWidth() {
            // 拖动中读即时值，否则读配置项
            float w = 0f;
            if (_sidebarResizing) w = _sidebarW;
            if (w <= 0f && _sidebarWEntry != null) w = _sidebarWEntry.Value;
            if (w <= 0f) w = _sidebarW;
            // 先判 w 再算自动宽度：CalcAutoSidebarWidth 需逐项 CalcSize，而本方法每帧调用十几次。
            float cap = Mathf.Clamp(SRApi.ContentArea.width * 0.55f, 100f, 320f);
            if (w > 0f) return Mathf.Clamp(w, 100f, cap);
            return Mathf.Min(CalcAutoSidebarWidth(), cap);
        }

        private static int _autoSbKey;
        private static float _autoSbW = -1f;
        private static float CalcAutoSidebarWidth() {
            // 按集合 / 语言 / 缩放缓存，键用哈希折叠以免每帧重建长字符串。
            int key = 17;
            key = key * 31 + _internalSections.Count;
            for (int i = 0; i < _internalSections.Count; i++) key = key * 31 + _internalSections[i].GetHashCode();
            key = key * 31 + _externalPlugins.Count;
            for (int i = 0; i < _externalPlugins.Count; i++) key = key * 31 + _externalPlugins[i].name.GetHashCode();
            key = key * 31 + SR.LangVer;
            key = key * 31 + Mathf.RoundToInt(_scaled * 100f);
            if (key == _autoSbKey) return _autoSbW;
            float maxW = 0f;
            foreach (string s in _internalSections) {
                maxW = Mathf.Max(maxW, _label.CalcSize(new GUIContent(ZhSection(s))).x);
            }
            foreach (PluginEntry p in _externalPlugins) {
                maxW = Mathf.Max(maxW, _label.CalcSize(new GUIContent(p.name)).x);
            }
            _autoSbKey = key;
            _autoSbW = Mathf.Clamp(maxW + 26f, 110f, 260f);
            return _autoSbW;
        }

    internal static bool _curIsInternal = true;
    internal static bool CurIsInternal { get { return _curIsInternal; } set { _curIsInternal = value; } }
        // 同行附加控件的本帧已绘制记录（条目 + 帧号）。
        private static ConfigEntryBase _followDoneEntry;
        private static int _followDoneFrame = -1;

        private static float EntryNameWidth() {
            // 列宽按 模式 / 分区 / 语言版本 / 条目版本 / 缩放 / 外部插件 哈希缓存；必须含 LangVer 与 _entryVersion。
            PluginEntry __pe = CurrentExternalPlugin();
            int key = 17;
            key = key * 31 + _mode.GetHashCode();
            key = key * 31 + _selectedInternalSection.GetHashCode();
            key = key * 31 + SR.LangVer;
            key = key * 31 + _entryVersion;
            key = key * 31 + Mathf.RoundToInt(_scaled * 100f);
            key = key * 31 + (__pe != null ? __pe.guid.GetHashCode() : 0);
            if (key == _nameWKey) return _nameWCached;
            _nameWKey = key;
            float maxW = 60f;
            if (_mode == Mode.Internal) {
                foreach (ConfigEntryBase e in InternalSectionEntries()) maxW = Mathf.Max(maxW, _nameLabel.CalcSize(new GUIContent(ZhKey(e))).x);
            } else if (_mode == Mode.Settings) {
                foreach (ConfigEntryBase e in SettingsEntries()) maxW = Mathf.Max(maxW, _nameLabel.CalcSize(new GUIContent(ZhKey(e))).x);
            } else {
                ConfigFile cfg = CurrentExternalPlugin() != null ? CurrentExternalPlugin().config : null;
                foreach (ConfigEntryBase e in VisibleEntries(cfg)) maxW = Mathf.Max(maxW, _nameLabel.CalcSize(new GUIContent(e.Definition.Key)).x);
            }
            _nameWCached = Mathf.Clamp(maxW + 16f, 90f, 240f);
            return _nameWCached;
        }

        private static readonly Dictionary<ConfigEntryBase, float> _nameTextW = new Dictionary<ConfigEntryBase, float>();
        private static int _nameTextWVer = -1;
        private static float NameTextWidth(ConfigEntryBase entry, string name) {
            int ver = LangVer * 1000 + Mathf.RoundToInt(_scaled * 100f);
            if (_nameTextWVer != ver) { _nameTextW.Clear(); _nameTextWVer = ver; }
            float w;
            if (_nameTextW.TryGetValue(entry, out w)) return w;
            w = _nameLabel.CalcSize(new GUIContent(name)).x;
            _nameTextW[entry] = w;
            return w;
        }

        // 某 section 的可见条目；按 section 缓存，条目版本变化即失效。
        private static readonly Dictionary<string, List<ConfigEntryBase>> _secCache = new Dictionary<string, List<ConfigEntryBase>>();
        private static readonly Dictionary<string, int> _secCacheVer = new Dictionary<string, int>();
        // 兜底：每 30 帧抽查条目总数，变化即让按版本缓存的表失效。
        private static int _cfgCountSeen = -1;
        private static int _cfgCountAtFrame = -9999;
        private static void SyncEntryVersionFromConfig() {
            try {
                ConfigFile cfg = _internalConfig;
                if (cfg == null) return;
                if (Time.frameCount - _cfgCountAtFrame < 30) return;
                _cfgCountAtFrame = Time.frameCount;
                IDictionary<ConfigDefinition, ConfigEntryBase> d = cfg as IDictionary<ConfigDefinition, ConfigEntryBase>;
                if (d == null) return;
                int n = d.Count;
                if (n == _cfgCountSeen) return;
                bool first = _cfgCountSeen < 0;
                _cfgCountSeen = n;
                if (!first) _entryVersion++;   //首次仅记录基线
            } catch { /* 静默：非关键路径，失败可直接忽略 */ }
        }

        // public：功能按段取条目表以渲染自己的页面。
        public static List<ConfigEntryBase> SectionEntries(string section) {
            SyncEntryVersionFromConfig();
            int ver = _entryVersion;
            List<ConfigEntryBase> cached;
            int oldVer;
            bool haveCache = _secCache.TryGetValue(section, out cached);
            bool haveVer = _secCacheVer.TryGetValue(section, out oldVer);
            if (haveCache && haveVer && oldVer == ver && cached != null) return cached;
            cached = new List<ConfigEntryBase>();
            ConfigFile cfg = SR.Ctl.InternalConfig;
            if (cfg == null) return cached;
            foreach (ConfigEntryBase e in AllEntries(cfg)) {
                if (e.Definition.Section != section) continue;
                if (!SR.RowVisible(e)) continue;
                cached.Add(e);
            }
            _secCache[section] = cached;
            _secCacheVer[section] = ver;
            return cached;
        }

        // 条目表版本号与按 "段\t键" 的查找缓存。
        private static readonly Dictionary<string, ConfigEntryBase> _entryCache = new Dictionary<string, ConfigEntryBase>();
    internal static int _entryVersion ;
    internal static int EntryVersion { get { return _entryVersion; } set { _entryVersion = value; } }

        // public：惰性 Bind 出新条目后调用以使缓存失效。

        public static void NoteEntryBound() { _entryVersion++; }

        internal static void ClearEntryCache() {
            _entryCache.Clear();
            _secCache.Clear();
            _secCacheVer.Clear();
            _entryVersion++;
        }

        private static ConfigEntryBase FindInternalEntry(string section, string key) {
            if (_internalConfig == null) return null;
            string k = section + "\t" + key;
            ConfigEntryBase hit;
            if (_entryCache.TryGetValue(k, out hit)) return hit;
            foreach (ConfigEntryBase e in AllEntries(_internalConfig)) {
                if (e.Definition.Section == section && e.Definition.Key == key) {
                    _entryCache[k] = e;   //只缓存命中
                    return e;
                }
            }
            // 未命中也缓存 null，否则错键每帧全表扫描。
            _entryCache[k] = null;
            return null;
        }

        private static string FormatDefaultValue(ConfigEntryBase entry) {
            try {
                if (entry == null || entry.DefaultValue == null) return "";
                object dv = entry.DefaultValue;
                string range = "";
                try {
                    object av = entry.Description != null ? entry.Description.AcceptableValues : null;
                    if (av != null) {
                        // 反射登记：BepInEx 公共 API，改名后自检会报出来
                        SRApi.Ref.Override("AcceptableValueRange`1.Min", "悬浮条目：显示数值范围");
                        SRApi.Ref.Override("AcceptableValueRange`1.Max", "悬浮条目：显示数值范围");
                        System.Reflection.PropertyInfo pmin = RefCache.PropertyOf(av.GetType(), "Min");
                        System.Reflection.PropertyInfo pmax = RefCache.PropertyOf(av.GetType(), "Max");
                        if (pmin != null && pmax != null) {
                            object mn = pmin.GetValue(av, null), mx = pmax.GetValue(av, null);
                            if (mn != null && mx != null)
                                range = "（" + Convert.ToString(mn, System.Globalization.CultureInfo.InvariantCulture)
                                      + "–" + Convert.ToString(mx, System.Globalization.CultureInfo.InvariantCulture) + "）";
                        }
                    }
                } catch { /* 静默：非关键路径，失败可直接忽略 */ }
                // 开关文本须用 UseEn：语言包下 _langEn 为 false，写死会中英混排。
                if (dv is bool) return ((bool)dv) ? (UseEn ? "ON" : "开") : (UseEn ? "OFF" : "关");
                if (dv is float) return ((float)dv).ToString("0.##", System.Globalization.CultureInfo.InvariantCulture) + range;
                if (dv is int) return ((int)dv).ToString() + range;
                // KeyCode 也是 Enum 须先判；未绑定（None）视为无默认值，不追加默认行。
                if (dv is KeyCode) { KeyCode kc = (KeyCode)dv; return kc == KeyCode.None ? "" : KeyDisplayName(kc); }
                if (dv is System.Enum) return EnumDisplayName(dv.ToString());
                return Convert.ToString(dv, System.Globalization.CultureInfo.InvariantCulture);
            } catch { return ""; }
        }

        // 渲染某栏目的通用设置条目。
        public static void RenderSectionEntries(string section, System.Func<ConfigEntryBase, bool> filter = null) {
            try {
                float colWidth = EntryNameWidth();
                List<ConfigEntryBase> list = SectionEntries(section);
                for (int i = 0; i < list.Count; i++) {
                    if (filter != null && !filter(list[i])) continue;   //排除属于其它子页的条目
                    RenderEntryRow(list[i], true, colWidth);
                }
            } catch (Exception __ex) { Guard.Log("渲染栏目设置(" + section + ")", __ex); }
        }


        // 紧凑行判定：任一 RowCompact 钩子命中即算。
        private static bool CompactRow(ConfigEntryBase entry) {
            List<Func<ConfigEntryBase, bool>> hooks = SRApi.RowCompact;
            if (hooks == null || hooks.Count == 0) return false;
            for (int i = 0; i < hooks.Count; i++) {
                try { if (hooks[i] != null && hooks[i](entry)) return true; }
                catch (Exception __ex) { Guard.Log("紧凑行判定", __ex); }
            }
            return false;
        }

        private static void RenderEntryRow(ConfigEntryBase entry, bool isInternal, float colWidth) {
            // 条目可能因功能未初始化 / 键改名而取不到，null 时直接返回。
            if (entry == null) return;
            string name = isInternal ? ZhKey(entry) : entry.Definition.Key;
            string desc;
            if (UseEn) {
                desc = isInternal ? ZhDesc(entry) : null;
                // 仅外部条目回退自带 ConfigDescription（英文）；内部条目不可回退中文说明。
                if (desc == null && !isInternal && entry.Description != null) desc = entry.Description.Description;
                if (desc == null) desc = "";
            } else {
                string zhDesc = isInternal ? ZhDesc(entry) : null;
                desc = zhDesc != null ? zhDesc
                    : (entry.Description != null && entry.Description.Description != null ? entry.Description.Description : "");
            }
            // 按本行控件占宽扣除，供名称列自适应（复选框约 34，键位 / 下拉约 170）。
            float reserve = Sc(180);
            object cval = entry.BoxedValue;
            if (cval is bool) reserve = Sc(34);
            else {
                float hookW = SR.RowComboWidth(entry);
                if (hookW > 0f) reserve = Sc(hookW + 8);
            }
            float avail = Mathf.Max(Sc(140), _winWidth - SidebarWidth() - Sc(24));
            float textW = NameTextWidth(entry, name);
            float cap = Mathf.Max(Sc(50), avail - reserve);
            float nameW = Mathf.Min(Mathf.Max(colWidth, Sc(50)), cap);
            // 标签列默认统一宽度（同栏目控件左缘对齐）；RowCompact 行标签宽 = 文字宽 + 小间距。
            float nameTw = CompactRow(entry) ? Mathf.Min(textW, nameW) : nameW;
            // 名称列须包在垂直组内才获得完整高度，否则 CJK 字形下沉 / 换行会被裁。
            GUILayout.BeginHorizontal();
            try {
                GUILayout.BeginVertical(GUILayout.Width(nameTw));
                try {
                    string tip = RowTip(entry, desc);
                    if (GUILayout.Button(new GUIContent(name, tip),
                        _nameLabel, GUILayout.Width(nameTw), GUILayout.Height(TextHeight(name, nameTw)))) {
                        Event evName = Event.current;
                        if (evName == null || evName.button == 0) {
                            try { entry.BoxedValue = entry.DefaultValue; } catch (Exception __ex) { Guard.Log("恢复条目默认值(点击名称)", __ex); }
                            //复位可能改动键位，须使序列监听的 watch 列表失效。
                            MarkKeyChanged();   //重置可能改动键位，令序列监听列表失效
                            _editText.Remove(entry);
                            _editOpen.Remove(entry);
                        }
                    }
                } finally { GUILayout.EndVertical(); }
                GUILayout.Space(Sc(6));
                RenderControl(entry);
                RenderFollowUp(entry, isInternal);
            } finally { GUILayout.EndHorizontal(); }
            GUILayout.Space(Sc(2));
        }

        // 绘制同一行的同伴键位与附加控件；滑块路径会先 EndHorizontal，故须在自己的水平组内调用。
        private static void RenderFollowUp(ConfigEntryBase entry, bool isInternal) {
            try {
                if (_followDoneEntry == entry && _followDoneFrame == Time.frameCount) return;
                _followDoneEntry = entry; _followDoneFrame = Time.frameCount;
                string companionKey = isInternal ? SR.RowCompanion(entry) : null;
                if (companionKey != null) {
                    GUILayout.Space(Sc(2));
                    ConfigEntryBase ck = FindInternalEntry(entry.Definition.Section, companionKey);
                    if (ck != null) RenderControl(ck);
                }
                if (!isInternal) return;
                string extraKey = SR.RowExtra(entry);
                if (extraKey == null) return;
                GUILayout.Space(Sc(2));
                ConfigEntryBase ex = FindInternalEntry(entry.Definition.Section, extraKey);
                if (ex != null) RenderControl(ex);
            } catch (Exception __ex) { Guard.Log("同行附加控件", __ex); }
        }

        // 文本高度 + CJK 下沉余量；两层字典缓存。
        private static float TextHeight(string text, float width) {
            try {
                List<float[]> list;
                if (!_heightCache.TryGetValue(text, out list)) { list = new List<float[]>(2); _heightCache[text] = list; }
                for (int i = 0; i < list.Count; i++) {
                    float[] e = list[i];
                    if (Mathf.Approximately(e[0], width) && Mathf.Approximately(e[1], _scaled)) return e[2];
                }
                float v = Mathf.Max(Sc(32), _nameLabel.CalcHeight(new GUIContent(text), width) + Sc(16));
                if (_heightCache.Count > 800) _heightCache.Clear(); //防膨胀
                list.Add(new[] { width, _scaled, v });
                return v;
            } catch {
                return Sc(32);
            }
        }

        // ImGui 风格水平滑块：轨道 + 填充段 + 圆形把手（三态）；输入与热区交给 GUI.HorizontalSlider，外观自绘。

    internal static GUIStyle _sliderNative ;
    internal static GUIStyle SliderNative { get { return _sliderNative; } set { _sliderNative = value; } }
    internal static GUIStyle _sliderNativeThumb ;
    internal static GUIStyle SliderNativeThumb { get { return _sliderNativeThumb; } set { _sliderNativeThumb = value; } }
        // 上次提交给配置的值（抑制未变化时的重复写盘）
    internal static readonly System.Collections.Generic.Dictionary<ConfigEntryBase, float> _sliderLastWritten =
            new System.Collections.Generic.Dictionary<ConfigEntryBase, float>();

















        // 下拉框（全 mod 唯一实现）：按钮与列表同一纵向组；展开当帧不绘制列表（无 Layout 记录）。
    internal static readonly Dictionary<ConfigEntryBase, int> _comboSkipFrame = new Dictionary<ConfigEntryBase, int>();

    internal static readonly Dictionary<ConfigEntryBase, int> _comboScroll = new Dictionary<ConfigEntryBase, int>();
        // 编辑框自身提交配置的帧号（该帧不清 _editText，避免吃掉小数点）
    internal static int _editSelfFrame = -1;
    internal static int EditSelfFrame { get { return _editSelfFrame; } set { _editSelfFrame = value; } }
        // 点外面关闭：不靠坐标，MouseDown 帧无下拉框认领则帧尾全部收起。
        internal static int _comboSeenFrame = -1;
        internal static int ComboSeenFrame { get { return _comboSeenFrame; } set { _comboSeenFrame = value; } }



        // 滚轮所有权与 hover 裁决：一帧内只有第一个判定通过的控件算 hovered；滚动容器先于控件提交，故读上一帧。
        //控件高度（设计像素）：0 = 默认 26；功能可覆盖自己页面的控件高度
        public static float ControlHeight;
        //内容区原点偏移，供事件坐标与内容坐标换算
        internal static Vector2 AreaOffset;
        internal static bool WheelShieldHit;








        // 本帧内 ComboBox 的调用序号（每帧第一趟从 0 开始）。
    internal static int _comboSeqFrame = -1;
    internal static int ComboSeqFrame { get { return _comboSeqFrame; } set { _comboSeqFrame = value; } }
    internal static int _comboSeq ;
    internal static int ComboSeq { get { return _comboSeq; } set { _comboSeq = value; } }




    }
}
